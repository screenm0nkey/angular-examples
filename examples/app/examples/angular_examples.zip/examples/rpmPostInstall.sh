#!/bin/bash
echo "RPM Post installation"

mkdir -p /app/web/dyn/config/instances/drm/htdocs
ln -sf /app/drm-dashboard/public /app/web/dyn/config/instances/drm/htdocs/dashboard