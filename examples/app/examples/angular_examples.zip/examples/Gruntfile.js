'use strict';

module.exports = function (grunt) {
    grunt.initConfig({

        browserify: {
            dev: {
                files: {
                    'public/js/app.js': ['ui/src/app.js']
                },
                options: {
                    bundleOptions: {
                        debug: true
                    }
                }
            }
        },

        clean: {
            postBuild: ['version.txt'],
            preBuild: ['dist/target'],
            templates : ['public/templates']
        },

        copy: {
            templates: {
                files: [
                    // includes files within path
                    {expand: true, src: ['**/*.html'], dest: 'public/templates/', cwd: 'ui/src/'}
                ]
            }
        },

        jshint: {
            options: {
                jshintrc: 'jshintrc.json'
            },
            angular: ['ui/src/**/*.js', 'ui/tests/unit/**/*.js']
        },

        karma: {
            unit: {
                configFile: 'ui/tests/config/karma.conf.js'
            },
            // used by the ci server
            continuous: {
                configFile: 'ui/tests/config/karma.conf.js',
                singleRun: true,
                browsers:['PhantomJS'],
                reporters: ['progress', 'coverage', 'html'],
                plugins: [
                    'karma-chrome-launcher',
                    'karma-jasmine',
                    'karma-phantomjs-launcher',
                    'karma-html-reporter',
                    'karma-ng-html2js-preprocessor',
                    'karma-coverage'
                ],
                preprocessors: {
                    '../../public/templates/**/*.html': 'ng-html2js',
                    '../../public/js/app.js': ['coverage', 'html']
                },
                coverageReporter: {
                    type:'html',
                    dir: 'coverage/'
                },
                htmlReporter: {
                    outputDir: __dirname+'/ui/tests/karma_html',
                    templatePath: __dirname+'/node_modules/karma-html-reporter/jasmine_template.html'
                }
            }
        },

        less: {
            dev: {
                options: {
                    paths:['ui/less'],
                    sourceMap: true
                },
                files: {
                    'public/css/drm.css': ['ui/src/app.less']
                }
            }
        },

        // the version environment variable is set in the config for 'Prepare Release Candidate' in Team City
        // export drm_dashboard_short_sha=`echo %build.vcs.number% |cut -c 1-7`
        rpm: {
            options: {
                destination: 'dist/target/rpm',
                name: 'ubs-drm-dashboard',
                version: '1.' + process.env.build_number +'.'+ process.env.drm_dashboard_short_sha,
                vendor: 'UBS',
                group: 'DRM',
                release: true,
                summary: 'DRM Dashboard front end project',
                description: 'Contains all necessary files to run DRM Dashboard',
                preInstall: {
                    src: 'rpmPreInstall.sh'
                },
                postInstall: {
                    src: 'rpmPostInstall.sh'
                }
            },

            files: {
                src: [
                    'public/**',
                    'version.txt'
                ],
                dest: '/app/drm-dashboard'
            }
        },

        watch: {
            scripts: {
                files: ['ui/src/**/*.js'],
                tasks: ['browserify', 'jshint'],
                options: {
                    spawn: false
                }
            },
            styles: {
                files: ['ui/src/**/*.less'],
                tasks: ['less']
            },
            templates: {
                files: ['ui/src/**/*.html'],
                tasks: ['clean:templates', 'copy:templates']
            }
        }
    });

    grunt.loadNpmTasks('grunt-browserify');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-karma');
    grunt.loadNpmTasks('grunt-rpm');

    grunt.registerTask('start', ['copy:templates', 'browserify', 'less', 'watch']);
    grunt.registerTask('default', ['jshint', 'browserify', 'less', 'copy']);
    // Tasks below are used by Team City CI Server. See TeamCity config page.
    grunt.registerTask('test', ['browserify', 'copy', 'jshint', 'karma:continuous']);
    grunt.registerTask('pack', ['clean:preBuild','less','browserify','copy','rpm', 'clean:postBuild']);
};