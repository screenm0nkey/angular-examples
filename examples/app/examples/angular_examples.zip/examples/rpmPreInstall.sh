#!/bin/sh
echo "RPM Pre install"
