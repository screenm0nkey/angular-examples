'use strict';

// This is the fixtures module used in the tests.
angular.module('drmDashboard.fixtures', []);

// we have to set the drmDashboard as a fixture. it's not ideal but it
// causes lots of issue with the tests if we load the real module into the
// the tests
var drmDashboard = angular.module('drmDashboard', []);
drmDashboard.config(function($controllerProvider, $compileProvider, $filterProvider, $provide) {
    drmDashboard.$controller = $controllerProvider;
    drmDashboard.$compile = $compileProvider;
    drmDashboard.$filter = $filterProvider;
    drmDashboard.$provide = $provide;
});