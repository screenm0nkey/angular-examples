/*jshint maxparams:8*/

'use strict';
// TODO - Controller needs unit tests
var RequestEditorController = function ($scope, $routeParams, requestDetailsService, requestCreatorService) {

    $scope.form = {};
    $scope.editRequest =  requestDetailsService.update;

    $scope.form  = {
        id: $routeParams.id
    };

    requestDetailsService.query($routeParams.id).then(function (requestDetails) {
        angular.extend($scope.form, requestDetails.entity);
    });

    requestCreatorService.getMetadata().then(function (schema) {
        $scope.createRequestSchema = schema;
    });
};

module.exports = ['$scope', '$routeParams', 'RequestDetailsService', 'RequestCreatorService', RequestEditorController];