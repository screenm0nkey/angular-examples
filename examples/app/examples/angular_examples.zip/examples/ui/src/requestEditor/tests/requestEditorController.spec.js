/*jshint maxparams:8*/
'use strict';

describe('RequestEditorController', function () {
    var $scope;
    var $rootScope;
    var $httpBackend;
    var $controller;
    var fixture;
    var $routeParams = {
        id: 7
    };
    var endpoints = {
        createMetadata: 'crateMetadataUrl',
        create:'createUrl'
    };
    var RequestEditorCtrl;
    var RequestDetailsService;
    var schema;

    beforeEach(module(function($provide){
        $provide.value('endpoints', endpoints);
    }));
    beforeEach(module('drmDashboard.requestDetails'));
    beforeEach(module('drmDashboard.requestCreator'));
    beforeEach(module('drmDashboard.requestEditor'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(inject(function (_$httpBackend_, _$rootScope_, _$controller_, _RequestDetailsService_, _requestDetails_, _RequestCreatorService_, _createRequestPostSchema_) {
        $rootScope = _$rootScope_;
        $controller = _$controller_;
        $httpBackend = _$httpBackend_;
        RequestDetailsService = _RequestDetailsService_;
        fixture = _requestDetails_;
        schema = _createRequestPostSchema_.enhancedSchema;
        $scope = _$rootScope_.$new();

        RequestEditorCtrl = $controller('RequestEditorCtrl', {
            $scope: $scope,
            $routeParams: $routeParams,
            RequestDetailsService: RequestDetailsService,
            RequestCreatorService: _RequestCreatorService_
        });

        $httpBackend.expect('GET','/approvals/requests/' + $routeParams.id).respond(fixture.query);
        $httpBackend.expect('GET', endpoints.createMetadata).respond(_createRequestPostSchema_.schema);
        $httpBackend.flush();
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('default values', function () {
        it('requestDetails id', function () {
            expect($scope.form).toEqual(fixture.query.entity);
            expect($scope.createRequestSchema).toEqual(schema);
        });
    });

    describe('editRequest method', function () {
        it('should send the data back to server', function () {
            $scope.form = {
                foo: 'bar',
                dox_id: '09890'
            };
            var expectedDataSentToServer = {
                foo: 'bar',
                dox_id: 9890
            };

            $scope.editRequest($scope.form);

            $httpBackend.expect('PUT', '/approvals/requests/edit', expectedDataSentToServer).respond(200);
            $httpBackend.flush();
        });
    });

    describe('schema values', function () {

    });
});