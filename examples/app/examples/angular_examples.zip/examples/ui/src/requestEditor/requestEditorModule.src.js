'use strict';

var RequestEditorController = require('./requestEditorController.src.js');

angular.module('drmDashboard.requestEditor', [])
    .controller('RequestEditorCtrl', RequestEditorController);