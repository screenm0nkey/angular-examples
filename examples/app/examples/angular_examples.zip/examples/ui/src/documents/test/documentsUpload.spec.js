'use strict';


describe('Documents Service', function () {
    var uploadSpy;
    var promiseForAll;
    var qSpy = {};
    var Promise;
    var documentsService;
    var uploadUrl = 'url';
    var files = ['file1', 'file2'];
    var promises = [];
    var endpoints = { files: '/approvals/files' };

    beforeEach(function () {
        promiseForAll = {};
        Promise = function () {
        };

        qSpy = {
            all: sinon.spy(function () {
                return promiseForAll;
            })
        };

        uploadSpy = {
            upload: sinon.spy(function () {
                var promise = new Promise();
                promises.push(promise);
                return promise;
            })
        };

        module(function ($provide) {
            $provide.value('$upload', uploadSpy);
            $provide.value('$q', qSpy);
            $provide.value('pathExtractor', {});
            $provide.value('endpoints', endpoints);
        });

        module('drmDashboard.documents');

        inject(function (_documentsService_) {
            documentsService = _documentsService_;
        });
    });

    describe('upload method', function () {
        it('should send the data to http service', function () {
            /* WHEN */
            var expectedPromise = documentsService.upload(uploadUrl, files);

            /* THEN */
            expect(uploadSpy.upload.calledTwice).toBe(true);

            files.forEach(function (file, fileIndex) {
                var firstCallArguments = uploadSpy.upload.getCall(fileIndex).args;

                expect(firstCallArguments[0]).toEqual({
                    url: uploadUrl,
                    method: 'POST',
                    file: files[fileIndex],
                    fileFormDataName: 'file'
                });
            });

            var qAllArguments = qSpy.all.getCall(0).args;
            expect(qSpy.all.called).toBe(true);
            expect(qAllArguments[0]).toEqual(promises);
            expect(expectedPromise).toBe(promiseForAll);
        });
    });
});