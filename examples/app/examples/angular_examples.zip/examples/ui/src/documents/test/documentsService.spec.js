'use strict';

describe('Documents Service', function () {
    var $httpBackend;
    var documentsService;
    var pathExtractor;
    var endpoints = { files: '/approvals/files' };
    var documentsFixtures;

    beforeEach(function () {
        pathExtractor = {
            extract: sinon.spy(function (url) {
                return  url;
            })
        };

        module(function ($provide) {
            $provide.value('pathExtractor', pathExtractor);
            $provide.value('endpoints', endpoints);
            $provide.value('$upload', {});
        });
        module('drmDashboard.fixtures');
        module('drmDashboard.documents');

        inject(function (_documentsService_, _$httpBackend_, _documentsFixtures_) {
            documentsService = _documentsService_;
            $httpBackend = _$httpBackend_;
            documentsFixtures = _documentsFixtures_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });


    describe('query method', function () {
        it('should fetch the list of documents and from the list should fetch the details of each document', function () {
            /* GIVEN */
            var expectedDocumentList = {
                links: [
                    { url: '/foo/bar1' },
                    { url: '/foo/bar2' }
                ]
            };
            var url = 'documentsUrl';

            /* WHEN */
            var documentsPromise = documentsService.query(url);

            // THEN
            $httpBackend.expectGET(url).respond(expectedDocumentList);
            $httpBackend.expectGET('/foo/bar1').respond(documentsFixtures.documentObject);
            $httpBackend.expectGET('/foo/bar2').respond(documentsFixtures.documentObject);

            documentsPromise.then(function (documents) {
                expect(documents.length).toBe(2);
                expect(documents[0]).toEqual(documentsFixtures.formattedDocumentObject);
                expect(pathExtractor.extract.callCount).toBe(6);
            });

            $httpBackend.flush();
        });
    });

    describe('getVersions method', function () {
        it('should use http service to get files from url', function () {
            /* WHEN */
            var versionsPromise = documentsService.getVersions('someUrl');

            /* THEN */
            $httpBackend.expectGET('someUrl').respond(documentsFixtures.documentVersionObject);

            versionsPromise.then(function (versions) {
                expect(versions).toEqual(documentsFixtures.formattedDocumentVersionArray);
            });

            $httpBackend.flush();
        });
    });
});