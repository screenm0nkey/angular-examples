angular.module('drmDashboard.fixtures')
    .value('documentsFixtures',
    {
        documentObject : {
            createdAt: 11,
            downloadLink: {
                media_type: 'application/octet-stream',
                rel: 'download',
                url: '/somelink1'
            },
            fileName: 'untitled.js',
            versionCount: 1,
            versionsLink: {
                media_type: 'application/vnd.drm.dox+json',
                rel: 'versions',
                url: '/somelink2'
            }
        },

        formattedDocumentObject : {
            createdAt: 11,
            downloadLink: '/somelink1',
            fileName: 'untitled.js',
            versionCount: 1,
            versionsLink: '/somelink2'
        },

        documentVersionObject : {
            fileName: 'untitled.txt',
            items : [{
                createdAt: 1402919728276,
                createdBy: 'some user',
                downloadLink: {
                    media_type: 'application/octet-stream',
                    rel: 'download',
                    url: '/somelink1'
                }
            } ]
        },

        formattedDocumentVersionArray : [{
            createdAt: 1402919728276,
            createdBy: 'some user',
            downloadLink: '/somelink1',
            fileName: 'untitled.txt'
        }]
    });