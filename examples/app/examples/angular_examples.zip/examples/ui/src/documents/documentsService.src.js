'use strict';

var DocumentsService = function ($http, $q, $upload, pathExtractor) {

    // returns an array of different versions of the  requested file
    var getVersions = function (url) {
        var deferred = $q.defer();

        $http({
            url: url,
            method: 'GET'
        }).success(function(response) {
            var versions = [];
            var items = response.items;

            for (var i = 0; i < items.length; i++) {
                versions.push({
                    createdAt: items[i].createdAt,
                    createdBy: items[i].createdBy,
                    fileName: response.fileName,
                    downloadLink: pathExtractor.extract(items[i].downloadLink.url)
                });
            }
            deferred.resolve(versions);
        });
        return deferred.promise;
    };

    // returns an array of objects containing document link information.
    var query = function (url) {
        var fetchDocs = $http({
            url: url,
            method: 'GET'
        });

        return fetchDocs.then(fetchDocumentsFromList).then(formatDocumentObject);
    };


    // loops through link object array contained in the response and makes a request for each of the documents
    var fetchDocumentsFromList = function (response) {
        var links = response.data.links;
        var documentsPromises = [];
        var deferred = $q.defer();

        if (links) {
            for(var linkIndex = 0; linkIndex < links.length; linkIndex ++) {
                documentsPromises.push($http({
                    url: pathExtractor.extract(links[linkIndex].url),
                    method: 'GET'
                }));
            }
        }

        $q.all(documentsPromises).then(createAllPromisesSuccessHandler(deferred));
        return deferred.promise;
    };


    // this request handler is called when all the requests for fetchDocumentsFromList() are resolved.
    var createAllPromisesSuccessHandler = function (deferred) {
        return function(responses){
            var result = [];
            for(var i = 0; i < responses.length; i++) {
                result.push(responses[i].data);
            }
            deferred.resolve(result);
        };
    };

    // takes an unformatted document object and generates a reduced document object. accepts single object or array
    var formatDocumentObject = function (response) {
        var deferred = $q.defer();
        var documents = [];

        if (!angular.isArray(response)) {
            response = [response];
        }

        response.forEach(function (doc) {
            if(angular.isObject(doc)) {
                documents.push({
                    createdAt: doc.createdAt,
                    fileName: doc.fileName,
                    versionCount: doc.versionCount,
                    versionsLink: pathExtractor.extract(doc.versionsLink.url),
                    downloadLink: pathExtractor.extract(doc.downloadLink.url)
                });
            }
        });
        // we use an deferred here so we can chain the logic in query()
        deferred.resolve(documents);
        return deferred.promise;
    };



    var upload = function (url, files) {
        var fileUploadPromises =[];

        for (var fileIndex = 0; fileIndex < files.length; fileIndex++) {
            var uploadPromise = $upload.upload({
                url: url,
                method: 'POST',
                file: files[fileIndex],
                fileFormDataName: 'file'
            });

            fileUploadPromises.push(uploadPromise);
        }

        var combinedPromise =  $q.all(fileUploadPromises);
        return combinedPromise;
    };


    return {
        query: query,
        upload : upload,
        formatDocumentObject : formatDocumentObject,
        getVersions : getVersions
    };
};

module.exports =['$http', '$q', '$upload', 'pathExtractor', DocumentsService];