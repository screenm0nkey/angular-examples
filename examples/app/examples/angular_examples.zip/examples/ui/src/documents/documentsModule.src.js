var DocumentsService = require('./documentsService.src.js');

 angular.module('drmDashboard.documents', [])
    .factory('documentsService', DocumentsService);