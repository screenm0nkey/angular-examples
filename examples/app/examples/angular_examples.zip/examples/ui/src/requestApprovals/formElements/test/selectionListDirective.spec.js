'use strict';

describe('SelectionList Directive', function () {

    var $rootScope;
    var $scope;
    var $compile;
    var fixtures;
    var formElement;
    var directiveElement;

    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.requestApprovals'));
    beforeEach(module('/templates/requestApprovals/formElements/selectionList.html'));

    beforeEach(inject(function (_$rootScope_, _$compile_, _selectionListFixtures_) {
        $rootScope = _$rootScope_;
        $compile = _$compile_;
        fixtures = angular.copy(_selectionListFixtures_);
        $scope = $rootScope.$new();
    }));

    afterEach(function(){
        formElement.remove();
    });

    var renderDirective = function (classificationOptions, classificationModel) {
        $scope.staticModel = classificationOptions;
        $scope.classificationModel = classificationModel || fixtures.classificationModel;
        formElement = angular.element('<form name="testForm"><div drm-selection-list data-static-model="staticModel" data-classification-model="classificationModel" ></div></form>');
        $compile(formElement)($scope);
        $('body').append(formElement);
        $rootScope.$digest();
        directiveElement = formElement.find('[drm-selection-list]');
    };

    var getStaticData = function (index) {
        return fixtures.classificationOptions[index];
    };


    describe('List', function () {
        it('should add a disabled class if select menu is not editable', function () {
            renderDirective(getStaticData(0));
            expect(formElement.find('div[drm-selection-list]').hasClass('disabled')).toEqual(true);
        });
    });

    describe('List title', function () {
        it('should place a name of the list inside list-heading div', function () {
            var classificationOption = getStaticData(0);
            renderDirective(classificationOption);
            var $listHeader = $(formElement).find('.list-heading');
            expect($listHeader.text().indexOf(classificationOption.name) >= 0).toBe(true);
        });

        it('should display min and maximum options for multi select', function () {
            renderDirective(getStaticData(0));
            var $listHeader = $(formElement).find('.list-heading');
            expect($listHeader.text().trim().replace('\n', '').replace(/\s+/g, ' ')).toEqual('Type Please select between 1 and 3 options');
        });

        it('should display minimum option for single select', function () {
            renderDirective(getStaticData(2));
            var $listHeader = $(formElement).find('.list-heading');
            expect($listHeader.text().trim().replace('\n', '').replace(/\s+/g, ' ')).toEqual('Client Type Please select 1 option');
        });
    });


    describe('List body', function () {
        var classificationOption;

        beforeEach(function(){
            classificationOption = getStaticData(0);
        });

        it('should display list items', function () {
            renderDirective(classificationOption);
            expect(formElement.find('ul li').length).toEqual(4);
        });

        it('should put option text into input label', function () {
            var classificationOption = getStaticData(0);
            renderDirective(classificationOption);
            var map = _.map(classificationOption.options, function(item){
                return item.text;
            });
            expect(formElement.find('ul li label').text().replace('\n', '').replace(/\s+/g, ' ')).toEqual(' ' + map.join(' ') + ' ');
        });
    });

    describe('List body checkboxes', function () {
        var classificationOption;
        var optionCount;

        beforeEach(function(){
            classificationOption = getStaticData(0);
            optionCount = classificationOption.options.length;
        });

        it('should display checkboxes if it is a multi-select. Element "ids" and "fors" should match', function () {
            renderDirective(classificationOption);
            var $checkboxes = formElement.find('ul li label input[type="checkbox"]');
            var $labels = formElement.find('ul li label');
            var ids = $.map($checkboxes, function (item) {
                return $(item).attr('id');
            });
            var fors = $.map($labels, function (item) {
                return $(item).attr('for');
            });

            var expectedIds = _.map(classificationOption.options, function (item) {
                return classificationOption.category + '_' + item.id;
            });

            expect($checkboxes.length).toEqual(optionCount);
            expect(ids).toEqual(expectedIds);
            expect(fors).toEqual(expectedIds);
        });

        it('should add a disabled attribute to all checkboxes if editable:false', function () {
            renderDirective(classificationOption);
            expect(formElement.find('input[disabled]').length).toEqual(optionCount);
        });

        it('should add a "checked" class to the form label if model value is true', function () {
            renderDirective(classificationOption);
            expect(formElement.find('label').eq(0).hasClass('checked')).toEqual(true);
            expect(formElement.find('label').eq(1).hasClass('checked')).toEqual(true);
            expect(formElement.find('label').eq(2).hasClass('checked')).toEqual(false);
        });
    });


    describe('List body radio', function () {
        var classificationOption;
        var optionCount;

        beforeEach(function(){
            classificationOption = getStaticData(3);
            optionCount = classificationOption.options.length;
        });

        it('should display radio buttons if it is a single-select. Element "ids" and "fors" should match', function () {
            renderDirective(classificationOption);
            var $checkboxes = formElement.find('ul li label input[type="radio"]');
            var $labels = formElement.find('ul li label');
            var ids = $.map($checkboxes, function (item) {
                return $(item).attr('id');
            });
            var fors = $.map($labels, function (item) {
                return $(item).attr('for');
            });

            var expectedIds = _.map(classificationOption.options, function (item) {
                return classificationOption.category + '_' + item.id;
            });

            expect($checkboxes.length).toEqual(5);
            expect(ids).toEqual(expectedIds);
            expect(fors).toEqual(expectedIds);
        });

        it('should add a disabled attribute to all radio buttons if editable:false', function () {
            renderDirective(classificationOption);
            expect(formElement.find('input[disabled]').length).toEqual(optionCount);
        });

        it('should add a "checked" class to the form label if model value is true', function () {
            renderDirective(classificationOption);
            expect(formElement.find('label:first').hasClass('checked')).toEqual(true);
            expect(formElement.find('label').eq(1).hasClass('checked')).toEqual(false);
            expect(formElement.find('label').eq(2).hasClass('checked')).toEqual(false);
            expect(formElement.find('label').eq(3).hasClass('checked')).toEqual(false);
            expect(formElement.find('label:last').hasClass('checked')).toEqual(false);
        });
    });


    describe('Check model values are updated when selecting form elements', function () {
        describe('checkboxes', function () {
            var classificationOption;

            beforeEach(function(){
                classificationOption = getStaticData(1);
            });

            it('should update scope model values when element is selected', function () {
                renderDirective(classificationOption);
                var input = formElement.find('input[type="checkbox"]:first');
                input.click();
                expect($scope.classificationModel.ISSUE_TYPE).toEqual({1:true, 3:true,4:true});

                input = formElement.find('input[type="checkbox"]').eq(2);
                input.click();
                expect($scope.classificationModel.ISSUE_TYPE).toEqual({1:true, 3:false,4:true});
            });
        });

        describe('radio buttons', function () {
            var classificationOption;

            beforeEach(function(){
                classificationOption = getStaticData(2);
            });

            it('should update scope model values when element is selected', function () {
                renderDirective(classificationOption);
                $scope.classificationModel.CLIENT_TYPE = '15';
                $scope.$apply();
                var input = formElement.find('input[type="radio"]:first');
                expect(input.is(':checked')).toBe(true);
            });
        });
    });

    describe('validation of the selection List', function () {
        describe('radio button', function () {
            it('should be valid if one option is selected', function () {
                renderDirective(getStaticData(2), { CLIENT_TYPE: '15'});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-valid').length).toBe(1);
                expect(formElement.hasClass('ng-valid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(false);
            });

            it('should be invalid if no option is selected', function () {
                renderDirective(getStaticData(2), { CLIENT_TYPE: ''});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-invalid').length).toBe(1);
                expect(formElement.hasClass('ng-invalid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(true);
            });

            it('should be invalid if initial data is not a valid option', function () {
                renderDirective(getStaticData(2), { CLIENT_TYPE: '100'});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-invalid').length).toBe(1);
                expect(formElement.hasClass('ng-invalid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(true);
            });

            it('should be valid if initial data is not a valid option but the element is NOT editable', function () {
                renderDirective(getStaticData(3), { CLIENT_TYPE: '13'});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-valid').length).toBe(1);
                expect(formElement.hasClass('ng-valid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(false);
            });
        });

        describe('checkbox', function () {
            var classificationOption;

            beforeEach(function(){
                classificationOption = getStaticData(1);
            });

            it('should have a hidden element which will reflect validity of this directive', function () {
                renderDirective(classificationOption);
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-valid').length).toBe(1);
                expect(formElement.hasClass('ng-valid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(false);
            });

            it('should stay valid if it is not editable even if it does not meet validation criteria', function () {
                renderDirective( getStaticData(0), { ISDA_TYPE: {
                    1 : true,
                    2 : true,
                    3 : true,
                    4 : true
                }});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-valid').length).toBe(1);
                expect(formElement.hasClass('ng-valid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(false);
            });

            it('should become invalid if it does not meet validation criteria and is editable', function () {
                renderDirective( classificationOption, { ISSUE_TYPE: {
                    1 : true,
                    2 : true,
                    3 : true,
                    4 : true
                }});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-invalid').length).toBe(1);
                expect(formElement.hasClass('ng-invalid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(true);
            });

            it('should become valid if user unselects an option', function () {
                renderDirective( classificationOption, { ISSUE_TYPE: {
                    1 : true,
                    2 : true,
                    3 : true,
                    4 : false
                }});
                expect(formElement.find('input[type="hidden"].ng-pristine.ng-valid').length).toBe(1);
                expect(formElement.hasClass('ng-valid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(false);
            });

            it('should become invalid if user selects less than min of options', function () {
                renderDirective( classificationOption, { ISSUE_TYPE : {
                    3:false,
                    4:false
                }});

                expect(formElement.find('input[type="hidden"].ng-invalid').length).toBe(1);
                expect(formElement.hasClass('ng-invalid')).toBe(true);
                expect(directiveElement.hasClass('ng-invalid')).toBe(true);
            });
        });

        describe('sub options', function () {
            describe('when initialising the selection list and an item contains sub options', function () {
                it('should emit an event', function () {
                    var spy = sinon.spy();
                    $scope.$on('drmSelectionList:subOption', spy);
                    renderDirective(getStaticData(1));
                    expect(spy.callCount).toBe(1);
                    expect(spy.args[0][1].text).toBe('CSA Excluded Products');
                    expect(spy.args[0][1].suboptions.length).toBe(1);
                    expect(spy.args[0][2]).toBe(true);
                });
            });

            describe('when selecting a menu option which contains a sub option', function () {
                it('should emit an event containing the selected option and radio/checkbox state', function () {
                    $scope.$on('drmSelectionList:subOption', function(evt, option, state){
                        expect(option.text).toBe('CSA Excluded Products');
                        expect(option.suboptions.length).toBe(1);
                        expect(option.suboptions[0].name).toBe('CSA Excluded Products');
                        expect(state).toBe(true);
                    });

                    renderDirective(getStaticData(1));
                    directiveElement.find('label').eq(3).click();
                });
            });

            describe('when selecting a menu option which does not contain a sub option', function () {
                it('should not emit an event', function () {
                    var spy = sinon.spy();
                    renderDirective(getStaticData(1));
                    $scope.$on('drmSelectionList:subOption', spy);
                    directiveElement.find('label').eq(2).click();
                    expect(spy.callCount).toBe(0);
                });
            });


        });

    });
});