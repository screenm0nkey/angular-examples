'use strict';

var DrmClassificationDirective = function ($timeout, classificationService) {
    return {
        restrict: 'A',
        replace : true,
        templateUrl: '/templates/requestApprovals/classification.html',
        controllerAs : 'ClassifactionDirective',
        controller: function ($scope, $element) {
            var $submitButton = $element.find('button[type="submit"]');
            var $summary = $element.find('.alert-summary');

            // scope values used in classification directive
            $scope.showClassificationForm = false;
            $scope.isClassified = false;
            $scope.isSubmitted = false;
            $scope.staticFormData = null;
            $scope.modelFormData = null;
            $scope.modelFormDataSaved = {};


            var formHasBeenSubmitted = function () {
                // if the form is valid when the directive loads, means it must have been submitted.
                // check after timeout as form is always $valid when directive initiates.
                // $timeout doesn't seem to work with karma
                setTimeout(function () {
                    if ($scope.classificationForm.$valid) {
                        $scope.isSubmitted = true;
                        $scope.$apply();
                    }
                },0);
            };

            // used to display form selection summary which have been unchecked.
            var storeSavedFormData = function () {
                $scope.modelFormDataSaved = {};

                _.each($scope.modelFormData, function(value, key) {
                    $scope.modelFormDataSaved[key] =  classificationService.getSelectedValuesAsArray(value);
                });
            };

            // only show form if any of the form elements are editable.
            var showFormItems = function () {
                var editableItems = _.compact(_.pluck($scope.staticFormData, 'editable'));
                $scope.showClassificationForm = editableItems.length > 0;
            };

//            //TODO: Tests are done selection list directive emitting event. This directive needs tests.
//            var showSubOptions = function () {};
            var showSubOptions = function (evt, option, state) {
                if($scope.featureEnabled('DRM-197')) {
                    if (option.text === 'CSA Excluded Products') {
                        $scope.staticExcludedProducts = state ? option.suboptions[0] : null;
                    }
                }
                if($scope.featureEnabled('DRM-198')) {
                    if (option.text === 'Ratings Contingency') {
                        $scope.staticRatingsContingency = state ? option.suboptions[0] : null;
                    }
                }
            };


            var disableSubmitButton = function () {
                if ($element.hasClass('ng-valid')) {
                    $submitButton.removeAttr('disabled');
                } else {
                    $submitButton.attr('disabled', 'disabled');
                }
            };

            // INIT
           classificationService.getFormData($scope.requestDetails.links.classifications).then(function(formData){
                $scope.staticFormData = formData.staticFormData;
                $scope.modelFormData = formData.modelFormData;

                showFormItems();
                storeSavedFormData();
                formHasBeenSubmitted();
            });


            this.submit = function () {
                classificationService.update({
                    url : $scope.requestDetails.links.classifications,
                    modelFormData : $scope.modelFormData,
                    staticFormData :  $scope.staticFormData
                }).then(function() {
                    $submitButton.attr('disabled', 'disabled');
                    $summary.removeClass('alert-summary').addClass('alert-success');

                    formHasBeenSubmitted();
                    storeSavedFormData();

                    setTimeout(function(){
                        $summary.removeClass('alert-success').addClass('alert-summary');
                    }, 1000);
                });
            };


            var binding1 = $scope.$on('drmSelectionList:subOption', showSubOptions);

            // sets the 'isClassified' state of the form. 'isClassified' is true as
            // soon as a user selects a form option, even if it hasn't been saved.
            var watch1 = $scope.$watch(function checkFormModelValues () {
                var size = 0;
                _.each($scope.modelFormData, function(item){
                    size += _.size(item);
                });
               $scope.isClassified = size > 0;
            });

            var watch2 = $scope.$watch('modelFormData', function (newVal, oldVal) {
                if (newVal !== oldVal && !!oldVal) {
                    // we disable/enable the submit on changes to the form.
                    setTimeout(disableSubmitButton, 10);
                }
            }, true);

            $scope.$on('$destroy', function () {
                // remove watchers
                watch1();
                watch2();
                binding1();
            });
        }
    };
};

module.exports = ['$timeout', 'classificationService', DrmClassificationDirective];