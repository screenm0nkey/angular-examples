angular.module('drmDashboard.fixtures').value('classificationSummaryFixtures', {
    modelFormDataSaved : {
        CLIENT_TYPE : {},
        TYPE: {
            1 : true,
            2 : true,
            3 : true
        },
        ISSUE_TYPE: {
            21: true,
            22: true,
            23: true,
            24: true,
            27: true
        },
        ISSUE_TYPE__23__CSA_Excluded_Products: {
            31: true,
            33: true
        }
    },

    modelFormData : {
        CLIENT_TYPE : {},
        TYPE: {
            1 : true,
            3 : true,
            5 : true
        },
        ISSUE_TYPE: {
            23: true,
            24: true,
            27: true
        },
        ISSUE_TYPE__23__CSA_Excluded_Products: {
            31: true,
            32: true
        }
    },

    summaryOptionsNameMap : {
        1: 'Amending ISDA',
        2: 'Amending CSA',
        3: 'New CSA',
        4: 'New ISDA',
        5: 'New document - not CSA or ISDA',
        21: 'Collateralisation of Existing Trades',
        22: 'Cross-Default Threshold',
        23: 'CSA Excluded Products',
        24: 'High MTA - 5 million and above',
        25: 'Initial Margin - UBS Posting',
        26: 'No Rehypothecation',
        27: 'Non Standard Collateral',
        31: '<span class=\'sub\'>(FX)</span>',
        32: '<span class=\'sub\'>(FX Spot)</span>',
        33: '<span class=\'sub\'>(Commodities)</span>',
        TYPE: 'Type',
        CLIENT_TYPE: 'Client Type',
        ISSUE_TYPE: 'Issue'
    }
});