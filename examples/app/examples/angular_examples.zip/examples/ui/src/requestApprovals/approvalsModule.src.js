'use strict';
var ApprovalsService = require('./approvalsService.src.js');
var ApprovalsDirective = require('./approvalsDirective.src.js');
var ClassificationService = require('./classificationService.src.js');
var DrmClassificationDirective = require('./classificationDirective.src.js');
var SelectionListDirective = require('./formElements/selectionListDirective.src.js');
var DrmSummaryDirective = require('./classificationSummaryDirective.src');

angular.module('drmDashboard.requestApprovals', [])
    .factory('approvalsService', ApprovalsService)
    .directive('drmApprovals', ApprovalsDirective)
    .factory('classificationService', ClassificationService)
    .directive('drmClassification', DrmClassificationDirective)
    .directive('drmSelectionList', SelectionListDirective)
    .directive('drmSummary', DrmSummaryDirective);
