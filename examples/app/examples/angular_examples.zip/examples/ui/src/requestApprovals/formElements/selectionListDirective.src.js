'use strict';

var DrmSelectionListDirective = function () {
    return {
        restrict: 'A',
        replace : true,
        scope : {
            staticModel: '=',
            classificationModel: '='
        },
        templateUrl: '/templates/requestApprovals/formElements/selectionList.html',
        link: function (scope, element) {
            if (!scope.staticModel || !scope.classificationModel) {
                return;
            }

            var watchable = 'classificationModel.' + scope.staticModel.category;
            var ngModelCtrl = element.find('.hidden[type="hidden"]').controller('ngModel');
            var isEditable = scope.staticModel.editable;
            var isMultiSelect = scope.staticModel.multiselect;
            
            scope.isSelected = function (staticModel, option) {
                if (scope.classificationModel) {
                    return scope.classificationModel[staticModel.category][option.id];
                }
                return false;
            };

            scope.showSubOption = function (option, state, evt) {
                // check for INPUT as LABEL also triggers click event
                var validTagName = !evt ? true : evt.target.tagName === 'INPUT';
                var hasSubOptions = option && option.suboptions && option.suboptions.length;

                if (hasSubOptions && validTagName) {
                    scope.$emit('drmSelectionList:subOption', option, !!state);
                }
            };

            var watch = scope.$watch(watchable, function (newVal) {
                if (isMultiSelect) {
                    // checkbox list
                    var numberOfSelectedItems = _.compact(_.values(newVal)).length;
                    var lessThanRequired = numberOfSelectedItems < scope.staticModel.min;
                    var moreThanAllowed = numberOfSelectedItems > scope.staticModel.max;

                    if( ( lessThanRequired || moreThanAllowed) && isEditable) {
                        ngModelCtrl.$setValidity('', false);
                        element.addClass('ng-invalid');
                    } else {
                        ngModelCtrl.$setValidity('', true);
                        element.removeClass('ng-invalid');
                    }
                }
                // radio button list
                else if (!isMultiSelect) {
                    var inputValue = parseInt(newVal, 10);
                    var inputIdArray = _.map(scope.staticModel.options, function(item) {
                        return item.id;
                    });

                    var isNotValidOption = _.indexOf(inputIdArray, inputValue)<0;

                    if (isNotValidOption && isEditable) {
                        ngModelCtrl.$setValidity('', false);
                        element.addClass('ng-invalid');
                    } else {
                        ngModelCtrl.$setValidity('', true);
                        element.removeClass('ng-invalid');
                    }
                }
            }, true);

            scope.$on('$destroy', watch);
        }
    };
};

module.exports = [DrmSelectionListDirective];


