'use strict';


var DrmSummaryDirective = function (classificationService) {
    return {
        restrict: 'A',
        replace : true,
        link : function (scope, el) {
            var $summaryDirective = $(el);
            // this maps the form list option names to their ids
            // i.e. {1: "Amending ISDA", 2: "Amending CSA"}, and is
            // used to display the summary
            scope.summaryOptionsNameMap = {};

            $summaryDirective.addClass('alert alert-summary');

            var createOptionsNameMap = (function () {
                return function traverse (staticFormData, suboption) {
                    _.each(staticFormData, function(formItem){
                        if (!suboption) {
                            scope.summaryOptionsNameMap[formItem.category] = formItem.name;
                        }

                        _.each(formItem.options, function(option) {
                            if (suboption) {
                                scope.summaryOptionsNameMap[option.id] = '<span class="sub">(' + option.text + ')</span>';
                            } else {
                                scope.summaryOptionsNameMap[option.id] = option.text;
                            }

                            if (option.suboptions) {
                                traverse(option.suboptions, true);
                            }
                        });
                    });
                };
            }());


            var getSubObject = function (modelFormData, subKeyName){
                var subObject;

                _.each(modelFormData, function(value, key){
                    var regex = new RegExp('__' + subKeyName + '__');
                    if (regex.test(key)) {
                        subObject = {
                            keyName : key,
                            value : modelFormData[key]
                        };
                    }
                });

                return subObject;
            };


            var generateSummaryMessageHTML = function () {
                if (!scope.modelFormData|| !scope.modelFormDataSaved) {
                    return;
                }

                var html = '<strong><h4>Classification Summary</h4></strong><hr>';

                _.each(scope.modelFormData, function(value, key){
                    var selectedArray = classificationService.getSelectedValuesAsArray(value);
                    var savedSelectedArray = classificationService.getSelectedValuesAsArray(scope.modelFormDataSaved[key]);
                    var deletedArray = _.difference(savedSelectedArray, selectedArray);

                    if (scope.summaryOptionsNameMap[key] && (selectedArray.length || deletedArray.length)) {
                        var optionsArr = [];

                        html += ('<div class="clearfix"><div class="type">' + scope.summaryOptionsNameMap[key] + ' : </div><div class="options">');

                        _.each(selectedArray, function(id){
                            optionsArr.push(scope.summaryOptionsNameMap[id]);
                            var subObject =  getSubObject(scope.modelFormData, id);

                            if (subObject) {
                                var subSelectedArray = classificationService.getSelectedValuesAsArray(subObject.value);
                                var subSavedSelectedArray = classificationService.getSelectedValuesAsArray(scope.modelFormDataSaved[subObject.keyName]);
                                var subDeletedArray = _.difference(subSavedSelectedArray, subSelectedArray);

                                _.each(subSelectedArray, function(subId){
                                    optionsArr.push(scope.summaryOptionsNameMap[subId]);
                                });

                                _.each(subDeletedArray, function(delSubId){
                                    optionsArr.push('<span class="removed">' + scope.summaryOptionsNameMap[delSubId] + '</span>');
                                });
                            }
                        });

                        _.each(deletedArray, function(delId){
                            optionsArr.push('<span class="removed">' + scope.summaryOptionsNameMap[delId] + '</span>');
                        });

                        html += (optionsArr.join(', ') + '</div></div>');
                    }
                });

                $summaryDirective.html(html);
            };

            var watch1 = scope.$watch('staticFormData', function(newVal){
                if (newVal) {
                    createOptionsNameMap(scope.staticFormData);
                    generateSummaryMessageHTML();
                    watch1();
                }
            });

            var watch2 = scope.$watch('modelFormData', function(){
                generateSummaryMessageHTML();
            }, true);

            scope.$on('destroy', watch2);
        }


    };
};

module.exports = ['classificationService', DrmSummaryDirective];