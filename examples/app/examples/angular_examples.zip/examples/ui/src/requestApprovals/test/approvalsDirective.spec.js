'use strict';

describe('Approvals Directive', function () {

    var $directiveElement;
    var $scope;
    var $rootScope;
    var $compile;
    var approvalFixtures;
    var $httpBackend;
    var staticFormData;
    var modelFormData;
    var classificationFixtures;
    var URL = 'approvals-url';

    beforeEach(module('ngSanitize'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.requestApprovals'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('/templates/requestApprovals/approvals.html'));
    beforeEach(module('/templates/requestApprovals/classification.html'));
    beforeEach(module('/templates/requestApprovals/formElements/selectionList.html'));

    beforeEach(module(function ($provide) {
        $provide.value('endpoints', {
            classifications : '/approvals/classification/static'
        });
    }));

    beforeEach(inject(function (_$rootScope_, _$compile_, _$httpBackend_, _requestApprovalFixtures_, _classificationFixtures_) {
        classificationFixtures = angular.copy(_classificationFixtures_);
        staticFormData = classificationFixtures.getStaticFormData.classificationOptions;
        modelFormData = classificationFixtures.get;
        approvalFixtures = angular.copy(_requestApprovalFixtures_);
        $rootScope = _$rootScope_;
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        $scope = $rootScope.$new();
        $scope.resetRequest= sinon.spy(function() {});
        $scope.featureEnabled = function(){
            return true;
        };
    }));

    afterEach(function () {
        $directiveElement.remove();
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    var renderDirective = function () {
        // the approvals directive renders the classification directive which calls these two endpoints
        $httpBackend.expect('GET', URL).respond(approvalFixtures.query);
        $httpBackend.expect('GET', classificationFixtures.endpoints.staticFormDataUrl).respond(200, staticFormData);
        $httpBackend.expect('GET', classificationFixtures.endpoints.formModelDataUrl).respond(200, modelFormData);

        $scope.requestDetails = {};
        $scope.requestDetails.links = {
            classifications : classificationFixtures.endpoints.formModelDataUrl,
            approvals: URL
        };

        $directiveElement = angular.element('<div drm-approvals></div>');
        $compile($directiveElement)($scope);
        $('body').append($directiveElement);

        $scope.$digest();
        $httpBackend.flush();
    };


    it('should render ng-repeat directive on approvals array and display all approvals', function () {
        renderDirective();
        expect($($directiveElement).find('tr').length).toBe(approvalFixtures.query.approvals.length + 1);
        expect($($directiveElement).find('.glyphicon').eq(0).hasClass('glyphicon-ok approved')).toBe(true);
        $($directiveElement).remove();
    });


    it('should display reset button and hide textarea when the scope links object contains reset link', function () {
        /*GIVEN*/
        approvalFixtures.query.links = [{
            'media_type':'application/vnd.drm.approvals+json',
            'rel':'approval/reset',
            'url':'http://drmlocal/approvals/approvals/1/group'
        }];

        /*WHEN*/
        renderDirective();

        /*THEN*/
        //Should show reset button
        var resetButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.reset)"]');
        expect(resetButton.is(':visible')).toBe(true);

        //Should hide approval form
        var approvalForm = $directiveElement.find('form');
        expect(approvalForm.hasClass('ng-hide')).toBe(true);

        //On click should call appropriate endpoint and emit an event once the status of the approval changes
        var emitHandler = sinon.spy();
        $scope.$on('approvalsStatus:changed', emitHandler);
        $httpBackend.expect('GET', approvalFixtures.query.links[0].url).respond(200);
        $httpBackend.expect('GET', URL).respond(approvalFixtures.query);
        resetButton[0].click();
        $httpBackend.flush();
        expect(emitHandler.called).toBe(true);
        $($directiveElement).remove();
    });

    it('should show and error if there was a problem updating approval status', function () {
        /*GIVEN*/
        approvalFixtures.query.links = [{
            'media_type':'application/vnd.drm.approvals+json',
            'rel':'approval/reset',
            'url':'http://drmlocal/approvals/approvals/1/group'
        }];

        expect($($directiveElement).find('.alert-warning').is(':visible')).toBe(false);

        /*WHEN*/
        renderDirective();

        /*THEN*/
        $httpBackend.expect('GET', 'http://drmlocal/approvals/approvals/1/group').respond(403, {message: 'foo'});
        var resetButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.reset)"]');
        resetButton[0].click();
        $httpBackend.flush();
        var alertBox = $($directiveElement).find('.approval.alert-warning');
        expect(alertBox.is(':visible')).toBe(true);
        expect(alertBox.text().trim()).toBe('There was an error processing the approval, as the status of the request was changed by another user. Please refresh the page to see the updated status.');
        $($directiveElement).remove();
    });


    describe('Approve, Reject and "Not required" buttons', function () {

        it('should show all buttons in a disabled state', function () {
            /* GIVEN */
            renderDirective();
            var approveButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.approve, comment)"]');
            var rejectButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.reject, comment)"]');
            var approvalNotRequired = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.notrequired, comment)"]');

            /* THEN */
            expect(approveButton.is(':visible')).toBe(true);
            expect(rejectButton.is(':visible')).toBe(true);
            expect(approvalNotRequired.is(':visible')).toBe(true);

            expect(approveButton.is(':disabled')).toBe(true);
            expect(rejectButton.is(':disabled')).toBe(true);
            expect(approvalNotRequired.is(':disabled')).toBe(true);
            $($directiveElement).remove();
        });


        it('should enable all buttons once a user enters a comment, the classification form has been submitted and it is in a valid state', function () {
            /* GIVEN */
            renderDirective();
            var approveButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.approve, comment)"]');
            var rejectButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.reject, comment)"]');
            var approvalNotRequired = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.notrequired, comment)"]');

            /* THEN */
            expect(approveButton.is(':disabled')).toBe(true);
            expect(rejectButton.is(':disabled')).toBe(true);
            expect(approvalNotRequired.is(':disabled')).toBe(true);

            $scope.$$childTail.classificationForm.$valid = true;
            $scope.$$childTail.isSubmitted = true;
            $scope.comment = 'foo';
            $scope.$digest();

            expect(approveButton.is(':disabled')).toBe(false);
            expect(rejectButton.is(':disabled')).toBe(false);
            expect(approvalNotRequired.is(':disabled')).toBe(false);
            $($directiveElement).remove();
        });


        it('should disable the approve and reject buttons if the classification form is in an invalid state', function () {
            /* GIVEN */
            renderDirective();
            $scope.$$childTail.classificationForm.$valid = false;
            $scope.$digest();

            var $approveButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.approve, comment)"]');
            var $rejectButton = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.reject, comment)"]');

            /* THEN */
            expect($approveButton.is(':disabled')).toBe(true);
            expect($rejectButton.is(':disabled')).toBe(true);

            $scope.comment = 'foo';
            $scope.$digest();

            expect($approveButton.is(':disabled')).toBe(true);
            expect($rejectButton.is(':disabled')).toBe(true);
            $($directiveElement).remove();
        });


        it('should NOT disable the "Approval not required" button is the  form is in an invalid state', function () {
            renderDirective();
            $scope.$$childTail.classificationForm.$valid = false;
            $scope.comment = 'foo';
            $scope.$digest();

            var $approvalNotRequired = $($directiveElement).find('button[ng-click="ApprovalsController.updateApprovalStatus(links.notrequired, comment)"]');

            expect($approvalNotRequired.is(':disabled')).toBe(false);
            $($directiveElement).remove();
        });

    });










});