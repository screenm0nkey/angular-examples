'use strict';

describe('Classification Directive', function () {

    var $directiveFormElement;
    var $button;
    var $scope;
    var $rootScope;
    var $compile;
    var $httpBackend;
    var fixtures;
    var staticFormData;
    // selectedFormData is the data from the api which has not been formatted
    var selectedFormData;
    // modelFormData is the angular formatted selectedFormData
    var modelFormData;
    var validForm;

    beforeEach(module('ngSanitize'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.requestApprovals'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('/templates/requestApprovals/classification.html'));
    beforeEach(module('/templates/requestApprovals/formElements/selectionList.html'));

    beforeEach(module(function ($provide) {
        $provide.value('endpoints', {
            classifications : '/approvals/classification/static'
        });
    }));

    beforeEach(inject(function (_$rootScope_, _$compile_, _$httpBackend_, _classificationFixtures_) {
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
        $scope.featureEnabled = function () {return true;};
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        fixtures = angular.copy(_classificationFixtures_);
        staticFormData = fixtures.getStaticFormData.classificationOptions;
        selectedFormData = fixtures.get;
        modelFormData = fixtures.classificationModel;
        validForm = fixtures.validForm;
    }));

    afterEach(function () {
        $directiveFormElement.remove();
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    var renderDirective = function (selectedData, staticData) {
        staticData = staticData || staticFormData;
        selectedData = selectedData || selectedFormData;

        $scope.requestDetails = {
            links : {
                classifications: fixtures.endpoints.formModelDataUrl
            }
        };

        $httpBackend.expect('GET', '/approvals/classification/static').respond(200, staticData);
        $httpBackend.expect('GET', fixtures.endpoints.formModelDataUrl).respond(200, selectedData);

        $directiveFormElement = angular.element('<div drm-classification></div>');
        $compile($directiveFormElement)($scope);
        $('body').append($directiveFormElement);
        $scope.$digest();
        $button = $directiveFormElement.find('button[type="submit"]');
        $httpBackend.flush();
    };


    var saveButtonIsEnabled = function () {
        return !$button.attr('disabled');
    };

    var formIsValid = function () {
        return $directiveFormElement.hasClass('ng-valid') && !$directiveFormElement.hasClass('ng-invalid');
    };

    // jasmine.waitsFor delay helper
    var delay = function(ms) {
        var flag = false;
        setTimeout(function () {
            flag = true;
        }, ms);
        return function(){
            return flag;
        };
    };

    describe('initialisation of directive', function () {
        it('should assign valid model data and static form data onto the scope', function () {
            renderDirective(validForm.selectedData, validForm.staticData);
            // the directive used the data in ng-repeat which adds an $hashkey property so we cant compare easily
            expect($scope.staticFormData.length).toEqual(validForm.staticData.length);
            expect($scope.staticFormData[0].options.length).toEqual(validForm.staticData[0].options.length);
            expect($scope.modelFormData).toEqual({ ISDA_TYPE : { 1 : true, 2 : true } });
            expect($scope.modelFormDataSaved).toEqual({ ISDA_TYPE : [ 1, 2 ]});
        });

        it('should set "showClassificationForm" to true if any of the form items are editable', function () {
            renderDirective();
            expect($scope.showClassificationForm).toBe(true);
        });

        it('should set "isClassified" to true if form has been previously classified.', function () {
            renderDirective();
            expect($scope.isClassified).toBe(true);
        });

        it('should set the form state as submitted if valid has been previously submitted', function () {
            renderDirective(validForm.selectedData, validForm.staticData);
            expect($scope.isSubmitted).toBe(false);

            waitsFor(delay(20));
            runs(function () {
                expect($scope.isSubmitted).toBe(true);
            });
        });

        it('should render drm selection list directives based on static form data', function () {
            renderDirective();
            expect($directiveFormElement.find('[data-type="classifications"] [drm-selection-list]').length).toEqual(staticFormData.length);
        });

        it('should contain valid HTML to render the drm-selection directive', function () {
            renderDirective();
            var $el = $directiveFormElement.find('[drm-selection-list]');
            expect(!!$el[0]).toBe(true);
            expect($el.data('static-model')).toBe('item');
            expect($el.data('classification-model')).toBe('modelFormData');
        });
    });


    describe('Add "unclassified" class to directive root element' , function () {
        it('should add class if form has not been classified.', function () {
            renderDirective();
            // default form data contains classification
            expect($directiveFormElement.hasClass('unclassified')).toBe(false);

            selectedFormData = [];
            renderDirective();
            expect($directiveFormElement.hasClass('unclassified')).toBe(true);
        });

        it('should remove class if user makes selection on unclassified form', function () {
            selectedFormData = [];
            renderDirective();
            expect($directiveFormElement.hasClass('unclassified')).toBe(true);

            $scope.modelFormData.CLIENT_TYPE = '5';
            $scope.$digest();
            waitsFor(delay(20));
            runs(function () {
                expect($directiveFormElement.hasClass('unclassified')).toBe(false);
            });
        });
    });

    describe('enabling/disabling save button', function () {
        it('should display a disabled save button by default', function () {
            renderDirective();
            expect($button.length).toEqual(1);
            expect($button.text()).toEqual('Save Classification');
            expect(saveButtonIsEnabled()).toBe(false);
        });

        it('should, on load, display a disabled save button even if the classification form is in a valid state', function () {
            renderDirective(validForm.selectedData, validForm.staticData);
            waitsFor(delay(20));

            runs(function () {
                expect(formIsValid()).toBe(true);
                expect(saveButtonIsEnabled()).toBe(false);
            });
        });

        it('should be enabled if classification has changed and the form is in a valid state', function () {
            renderDirective(validForm.selectedData, validForm.staticData);
            $scope.modelFormData.ISDA_TYPE[3] = true;
            $scope.$digest();
            waitsFor(delay(20));

            runs(function () {
                expect(formIsValid()).toBe(true);
                expect(saveButtonIsEnabled()).toBe(true);
            });
        });

        it('should be disabled if request classification changes and the form is in an invalid state', function () {
            renderDirective();
            $scope.modelFormData.ISSUE_TYPE[1] = true;
            $scope.modelFormData.ISSUE_TYPE[2] = true;
            $scope.$digest();
            waitsFor(delay(20));

            runs(function () {
                expect(formIsValid()).toBe(false);
                expect(saveButtonIsEnabled()).toBe(false);
            });
        });

        xit('should return to a disabled state after a successful submit and make summary box take success colour (green)', function () {
            renderDirective();
            $scope.modelFormData.ISDA_TYPE[3] = true;
            $scope.$digest();
            waitsFor(delay(20));

            runs(function () {
                expect(saveButtonIsEnabled()).toBe(true);
                $httpBackend.expect('PUT', '/approvals/classification').respond(200);
                $button.click();
                $httpBackend.flush();
                expect(saveButtonIsEnabled()).toBe(false);
                expect(!!$directiveFormElement.find('.alert-success')[0]).toBe(true);
            });
        });
    });

    describe('hiding/showing of the classification form items', function () {
        it('should be displayed if any of the form elements are editable', function () {
            renderDirective();
            expect($directiveFormElement.find('[data-type="classifications"]').is(':visible')).toBe(true);
            expect($directiveFormElement.find('.submit-classification').is(':visible')).toBe(true);
        });

        it('should not be displayed if all of the form elements are not editable', function () {
            _.each(staticFormData, function(item){
                item.editable = false;
            });
            renderDirective();
            expect($directiveFormElement.find('[data-type="classifications"]').is(':visible')).toBe(false);
            expect($directiveFormElement.find('.submit-classification').is(':visible')).toBe(false);
        });
    });

    describe('display "This request has not been classified" form messages', function () {
        it('should contain correct text message', function () {
            renderDirective();
            var messageText = $directiveFormElement.find('.alert-warning').text();
            expect(messageText).toBe('This request has not yet been classified.');
        });

        it('should not display message if form items have been selected', function () {
            renderDirective();
            expect($directiveFormElement.find('.alert-warning').is(':visible')).toBe(false);
        });

        it('should display message if no forms items have been selected', function () {
            _.each(selectedFormData, function(item){
                item.selected = [];
            });
            renderDirective();
            expect($directiveFormElement.find('.alert-warning').is(':visible')).toBe(true);
            expect($directiveFormElement.find('.alert-danger').is(':visible')).toBe(false);

            selectedFormData = [];
            renderDirective();
            expect($directiveFormElement.find('.alert-warning').is(':visible')).toBe(true);
            expect($directiveFormElement.find('.alert-danger').is(':visible')).toBe(false);
        });
    });


    describe('display "selection error" form message', function () {
        var messageClass = '.alert-danger';

        it('should contain correct text message', function () {
            renderDirective();
            var messageText = $directiveFormElement.find(messageClass).text().replace('\n', '').replace(/\s+/g, ' ').trim();
            expect(messageText).toBe('You cannot approve or reject this request until the correct options are selected.');
        });

        it('should display message if form is in an invalid state and user has made selection', function () {
            renderDirective(validForm.selectedData, validForm.staticData);

            var $message = $directiveFormElement.find(messageClass);
            expect($directiveFormElement.hasClass('ng-valid')).toBe(true);
            expect($message.is(':visible')).toBe(false);

            $scope.modelFormData.ISDA_TYPE[3] = true;
            $scope.modelFormData.ISDA_TYPE[4] = true;
            $scope.$digest();
            waitsFor(delay(20));

            runs(function () {
                expect($message.is(':visible')).toBe(true);
            });
        });

        it('should not display message if form is invalid but no selection has been made', function () {
            _.each(selectedFormData, function(item){
                item.selected = [];
            });
            renderDirective();
            var $message = $directiveFormElement.find(messageClass);
            expect($message.is(':visible')).toBe(false);
        });
    });


    describe('displaying sub options', function () {
        xdescribe('CSA Excluded Products', function () {
            describe('when classification form is valid and user selects the option in the menu', function () {
                it('should listen for "drmSelectionList:subOption" event and show sub menu', function () {
                    renderDirective();
//                    expect($scope.staticExcludedProducts.name).toBe('CSA Excluded Products');
//                    expect($directiveFormElement.find('[data-type="csa-excluded-products"]').length).toEqual(1);
                });

                it('should put form into invalid state until at least one option is selected', function () {
                    renderDirective();
                });
            });

            describe('when classification form is valid and user de-selects option in menu', function () {
                it('should listen for "drmSelectionList:subOption" and hide sub menu', function () {
                    renderDirective();
                });

                it('should return form to valid state even if the user has failed to select the correct options from sub menu', function () {
                    renderDirective();
                });
            });
        });

        describe('Rating Contingency', function () {
            xit('should show rating contingency submenu', function () {
                renderDirective();

                var $ratingsContingencySubformHeading = $directiveFormElement.find('.list-heading:contains("Ratings")');
                expect($ratingsContingencySubformHeading.is(':visible')).toBe(true);

                $directiveFormElement.find('#ISSUE_TYPE_9').click();
                $scope.$digest();
                waitsFor(delay(10));

                runs(function () {
                    expect($ratingsContingencySubformHeading.length).toBe(0);
                });
            });
        });
    });
});