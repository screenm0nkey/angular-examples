angular.module('drmDashboard.fixtures').value('requestApprovalFixtures', {
    expectedLinks : {
        approve: 'http://drmlocal/approvals/approvals/approve',
        reject: 'http://drmlocal/approvals/approvals/reject',
        notrequired:'http://drmlocal/approvals/approvals/1/group/user'
    },

    query : {
        'approvals':[
            {
                'id':0,
                'request_id':0,
                'group': {
                    'id':3,
                    'code':'DRM_Global_Treasury',
                    'name':'Global Treasury',
                    'role':'APPROVER'
                },
                'status':'Approved',
                'approved_by':null,
                'approved_at':null,
                'comment':null,
                'required':true,
                'candidate':true,
                'approved':false,
                'assignee':''
            },
            {
                'id':0,
                'request_id':0,
                'group':{
                    'id':8,
                    'code':'DRM_TALM',
                    'name':'TALM',
                    'role':'APPROVER'
                },
                'status':'Awaiting Approval',
                'approved_by':null,
                'approved_at':null,
                'comment':null,
                'required':true,
                'candidate':true,
                'approved':false,
                'assignee':''
            }
        ],
        'links':[
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'approval/approve',
                'url':'http://drmlocal/approvals/approvals/approve'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'approval/reject',
                'url':'http://drmlocal/approvals/approvals/reject'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'approval/notrequired',
                'url':'http://drmlocal/approvals/approvals/1/group/user'
            }
        ]
    }
});
