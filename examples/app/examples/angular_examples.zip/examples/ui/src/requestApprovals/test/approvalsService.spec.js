'use strict';


describe('Approvals Service', function () {
    var approvalsService;
    var requestId;
    var $httpBackend;
    var pathExtractor;
    var fixtures;
    var URL = '/approvals-url';


    beforeEach( function () {
        requestId = 7;

        pathExtractor = {
            extract: sinon.spy(function (url) {
                return  url;
            })
        };

        module(function ($provide) {
            $provide.value('pathExtractor', pathExtractor);
        });

        module('drmDashboard.requestApprovals');
        module('drmDashboard.fixtures');

        inject(function (_approvalsService_, _$httpBackend_, _requestApprovalFixtures_) {
            fixtures = angular.copy(_requestApprovalFixtures_);
            approvalsService = _approvalsService_;
            $httpBackend = _$httpBackend_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('query method', function () {
        it('should call http service and return a promise', function () {
            /* GIVEN */
            var expectedObject = {};
            expectedObject.approvals = fixtures.query.approvals;
            expectedObject.links = fixtures.expectedLinks;

            /* WHEN */
            var approvalsPromise = approvalsService.query(URL);

            /* THEN */
            $httpBackend.expect('GET', URL).respond(fixtures.query);

            approvalsPromise.then(function (response) {
                expect(response).toEqual(expectedObject);
            });

            $httpBackend.flush();
        });
    });


    describe('updateApprovalStatus method', function () {
        it('should call provided link and post the message as object with property comment', function () {
            /* GIVEN */
            var processLink = 'someURL';
            var messageText = 'messageText';
            var expectedMessage = {
                comment: messageText
            };

            /* WHEN */
            approvalsService.updateApprovalStatus(processLink, messageText);

            /* THEN */
            $httpBackend.expect('POST',processLink, expectedMessage).respond(200);
            $httpBackend.flush();
        });

        it('should call', function () {
            /* GIVEN */
            var processLink = 'someURL';

            /* WHEN */
            approvalsService.updateApprovalStatus(processLink);

            /* THEN */
            $httpBackend.expect('GET', processLink).respond(200);
            $httpBackend.flush();
        });
    });
});