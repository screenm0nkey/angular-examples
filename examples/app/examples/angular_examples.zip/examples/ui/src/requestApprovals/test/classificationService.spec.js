'use strict';

describe('Classification Service', function () {
    var $httpBackend;
    var fixtures;
    var service;
    var staticFormData;
    var processedStaticFormData;
    var selectedFormData;
    var formModelData;
    var endpoints;

    beforeEach(module('ngSanitize'));
    beforeEach(module('drmDashboard.requestApprovals'));
    beforeEach(module('drmDashboard.fixtures'));

    beforeEach(module(function ($provide) {
        $provide.value('endpoints', {
            classifications : '/approvals/classification/static'
        });
    }));

    beforeEach( function () {
        inject(function (_$httpBackend_, _classificationService_, _classificationFixtures_) {
            fixtures = angular.copy(_classificationFixtures_);
            $httpBackend = _$httpBackend_;
            service = _classificationService_;
            staticFormData = fixtures.getStaticFormData.classificationOptions;
            processedStaticFormData = fixtures.getStaticFormData.processedClassificationOptions;
            selectedFormData = fixtures.get;
            formModelData = fixtures.classificationModel;
            endpoints = fixtures.endpoints;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });



    describe('getFormData() method', function () {
        it('should...', function () {
            $httpBackend.expect('GET', endpoints.staticFormDataUrl).respond(200, staticFormData);
            $httpBackend.expect('GET', endpoints.formModelDataUrl).respond(200, selectedFormData);

            service.getFormData(endpoints.formModelDataUrl).then(function(formData){
                expect(formData.modelFormData).toEqual(formModelData);
                expect(formData.staticFormData).toEqual(processedStaticFormData);
            });

            $httpBackend.flush();
        });
    });

    describe('update() method', function () {
        it('should send filtered array of form objects to api using PUT - test case 1', function () {
            service.update({
                url : endpoints.formModelDataUrl,
                modelFormData : formModelData,
                staticFormData :  staticFormData
            });

            $httpBackend.expect('PUT', endpoints.formModelDataUrl, fixtures.put).respond(200);
            $httpBackend.flush();
        });

        it('should send filtered array of form objects to api using PUT - test case 2', function () {

            var modelFormData = angular.copy(formModelData);
            var expectedPutData = angular.copy(fixtures.put);

            modelFormData.ISSUE_TYPE__comment__foo  = 'bar';

            expectedPutData[0].comments = [{comment_name: 'foo', comment_value: 'bar'}];

            service.update({
                url : endpoints.formModelDataUrl,
                modelFormData : modelFormData,
                staticFormData :  staticFormData
            });

            $httpBackend.expect('PUT', endpoints.formModelDataUrl, expectedPutData).respond(200);
            $httpBackend.flush();
        });

        it('should send filtered array of form objects to api using PUT - test case 3', function () {

            var modelFormData = angular.copy(formModelData);
            var expectedPutData = angular.copy(fixtures.put);

            modelFormData.ISSUE_TYPE__9__Ratings_Contingency__comment__foo  = 'bar';

            expectedPutData[0]['9'][0].comments.push({comment_name: 'foo', comment_value: 'bar'});

            service.update({
                url : endpoints.formModelDataUrl,
                modelFormData : modelFormData,
                staticFormData :  staticFormData
            });

            $httpBackend.expect('PUT', endpoints.formModelDataUrl, expectedPutData).respond(200);
            $httpBackend.flush();
        });
    });

    describe('removeNonEditableValues() method', function () {
        it('should remove any form objects from array which are not editable by user', function () {
            var filteredArray = service.removeNonEditableValues(fixtures.unfilteredPut, staticFormData);

            expect(fixtures.unfilteredPut.length).toBe(5);
            expect(filteredArray.length).toBe(2);
            expect(filteredArray[0].category).toBe('ISSUE_TYPE');
            expect(filteredArray[1].category).toBe('CLIENT_TYPE');
        });
    });

    describe('getStatic() method', function () {
        it('should GET all static data from api required to render the classification form items', function () {
            var promise = service.getStaticFormData(endpoints.staticFormDataUrl);
            $httpBackend.expect('GET', fixtures.endpoints.staticFormDataUrl).respond(200, staticFormData);

            promise.then(function (response) {
                expect(response).toEqual(staticFormData);
            });

            $httpBackend.flush();
        });
    });

    describe('getSelected() method', function () {
        it('should GET only user selected form data from api and convert structure to angular form model structure', function () {
            var promise = service.getSelectedFormData(endpoints.formModelDataUrl);
            $httpBackend.expect('GET', fixtures.endpoints.formModelDataUrl).respond(200, selectedFormData);

            promise.then(function (response) {
                expect(response).toEqual(selectedFormData);
            });

            $httpBackend.flush();
        });
    });

    describe('addStaticDataKeys() method', function () {
        it('should compare static form and form model data and add missing keys and subkeys to form model data', function () {
            var formModelData = { ISDA_TYPE:'1' };
            service.addStaticDataKeys(processedStaticFormData, formModelData);
            expect(formModelData).toEqual({
                ISDA_TYPE : '1',
                ISSUE_TYPE : {},
                ISSUE_TYPE__3__CSA_Excluded_Products : {},
                ISSUE_TYPE__9__Ratings_Contingency : {},
                CLIENT_TYPE : {}
            });
        });
    });


    describe('getSelectedValuesAsArray() method', function () {
        it('should convert form model data options from an object into an array', function () {
            expect(service.getSelectedValuesAsArray(21)).toEqual([21]);
            expect(service.getSelectedValuesAsArray('25')).toEqual([25]);
            expect(service.getSelectedValuesAsArray({1:true, 3:true})).toEqual([1,3]);
        });

        it('should return an compacted array if argument is an array', function () {
            expect(service.getSelectedValuesAsArray([0, 1,3, null])).toEqual([1,3]);
        });

        it('should remove any falsy values from array', function () {
            expect(service.getSelectedValuesAsArray({1:true, 2:false, 3:true})).toEqual([1,3]);
        });
    });

    describe('getSelectedValuesAsString() method', function () {
        it('should match array values to static form data and convert values to comma separated string', function () {
            var result, options = staticFormData[1].options;

            result = service.getSelectedValuesAsString(options, [1]);
            expect(result).toEqual('Collateral Threshold');

            result = service.getSelectedValuesAsString(options, ['2']);
            expect(result).toEqual('');

            result = service.getSelectedValuesAsString(options, [1, 9]);
            expect(result).toEqual('Collateral Threshold, Ratings Contingency');

            result = service.getSelectedValuesAsString(options, ['a', 1, 10000, 9]);
            expect(result).toEqual('Collateral Threshold, Ratings Contingency');
        });

        it('should wrap values in html tag and class', function () {
            var result, options = staticFormData[1].options;

            result = service.getSelectedValuesAsString(options, [1], 'span');
            expect(result).toEqual('<span>Collateral Threshold</span>');

            result = service.getSelectedValuesAsString(options, [1], 'span', 'hello');
            expect(result).toEqual('<span class="hello">Collateral Threshold</span>');

            result = service.getSelectedValuesAsString(options, [1, 9],  'span', 'hello');
            expect(result).toEqual('<span class="hello">Collateral Threshold</span>, <span class="hello">Ratings Contingency</span>');
        });
    });

    describe('getSubOption()', function () {
        it('should return a sub object from an an array of static form data', function () {
            var name = 'CSA Excluded Products';
            var subOption = service.getSubOption(staticFormData, name);
            expect(typeof service.getSubOption).toBe('function');
            expect(subOption.name).toBe(name);
        });
    });

    describe('convertToFormObj() method', function () {
        it('should convert multi-select form item object into angular form item object', function () {
            var formItem = { category:'ISDA_TYPE', multiselect : true, selected : [1, 2]};
            var expected = { ISDA_TYPE : { 1 : true, 2 : true }};
            expect(service.convertToFormObj(formItem)).toEqual(expected);
        });

        it('should convert single-select form item object into angular form item object', function () {
            var formItem = { category:'ISDA_TYPE', multiselect : false, selected : [1]};
            var expected =  { ISDA_TYPE : '1' };
            expect(service.convertToFormObj(formItem)).toEqual(expected);
        });
    });

    describe('extractSubSelections()', function () {
        it('should...', function () {
            var formItem = selectedFormData[1];
            var expected = [{
                category : 'ISSUE_TYPE__3__CSA_Excluded_Products',
                multiselect : true,
                selected : [ 1, 2 ]
            },{
                category : 'ISSUE_TYPE__9__Ratings_Contingency',
                multiselect : false,
                selected : [1],
                comments : [ { comment_name : 'other_ate', comment_value : 'some other ate' } ]
        }];

            expect(service.extractSubSelections(formItem)).toEqual(expected);
        });
    });
});