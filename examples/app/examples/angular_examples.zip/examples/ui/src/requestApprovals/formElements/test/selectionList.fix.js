
angular.module('drmDashboard.fixtures').value('selectionListFixtures', {
        classificationOptions : [
            {
                category : 'ISDA_TYPE',
                name : 'Type',
                multiselect : true,
                editable: false,
                min : 1,
                max : 3,
                options : [
                    { id : 21, text : 'Amending ISDA' },
                    { id : 22, text : 'Amending CSA' },
                    { id : 23, text : 'New ISDA' },
                    { id : 24, text : 'New CSA' }
                ]
            },
            {
                category : 'ISSUE_TYPE',
                name : 'Issue',
                multiselect : true,
                editable: true,
                min : 1,
                max : 3,
                options : [
                    { id : 1, text : 'Collateral' },
                    { id : 2, text : 'Cross-Default' },
                    { id : 3, text : 'CSA' },
                    { id : 4, text : 'CSA Excluded Products', suboptions : [
                        {
                            category : 'CSA_Excluded_Products',
                            name : 'CSA Excluded Products',
                            multiselect : true,
                            editable: true,
                            min : 1,
                            max : 3,
                            options : [
                                { id : 5, text : 'Option 1' },
                                { id : 6, text : 'Option 2' },
                                { id : 7, text : 'Option 3' },
                                { id : 8, text : 'Option 4' }
                            ]
                        }
                    ] }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: true,
                min : 1,
                max : 1,
                options : [
                    { id : 15, text : 'Central' },
                    { id : 16, text : 'Corporate' },
                    { id : 17, text : 'Financial' },
                    { id : 18, text : 'Government' },
                    { id : 19, text : 'Individual' }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: false,
                min : 1,
                max : 1,
                options : [
                    { id : 15, text : 'Central' },
                    { id : 16, text : 'Corporate' },
                    { id : 17, text : 'Financial' },
                    { id : 18, text : 'Government' },
                    { id : 19, text : 'Individual' }
                ]
            }
        ],


    classificationModel: {
        ISDA_TYPE: {
            21 : true,
            22 : true
        },
        ISSUE_TYPE: {
            3 : true,
            4 : true
        },
        CLIENT_TYPE: '15'
    }
});