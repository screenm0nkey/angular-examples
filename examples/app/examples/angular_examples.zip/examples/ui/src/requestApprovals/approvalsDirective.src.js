'use strict';


var ApprovalsDirective = function (approvalsService, statusClassService) {
    return {
        restrict: 'A',
        scope : true,
        controllerAs: 'ApprovalsController',
        templateUrl: '/templates/requestApprovals/approvals.html',
        controller : function ($scope) {
            var retrieveRequestApprovals = function () {
                approvalsService
                    .query($scope.requestDetails.links.approvals)
                    .then(function (response) {
                        angular.extend($scope, response);
                    });
            };

            retrieveRequestApprovals();

            this.getApprovalIconClass = statusClassService.getApprovalIconClass;
            this.getApprovalColorClass = statusClassService.getApprovalColorClass;

            this.updateApprovalStatus = function (link, message) {
                var promise = approvalsService.updateApprovalStatus(link, message);

                promise.then(function () {
                    $scope.$emit('approvalsStatus:changed');
                    retrieveRequestApprovals();
                }, function (errResponse) {
                    $scope.links = {};
                    $scope.errorExists = true;
                    $scope.errorMessage = errResponse.data.message;
                });
            };
        }
    };
};

module.exports = ['approvalsService', 'statusClassService', ApprovalsDirective];