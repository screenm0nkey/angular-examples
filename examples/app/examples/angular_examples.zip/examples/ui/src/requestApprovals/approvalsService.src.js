'use strict';

var ApprovalsService = function ($http, $q) {

    return {
        query: function (url) {
            var fetchApprovalsPromise = function (url) {
                var fetchApprovalsOptions = {
                    url: url,
                    method: 'GET'
                };
                var requiredApprovals = $http(fetchApprovalsOptions);
                return requiredApprovals;
            };

            var approvalsDeferred = $q.defer();
            var requiredApprovals = fetchApprovalsPromise(url);

            requiredApprovals.then(function (response) {
                var approvals = {};
                var links = {};

                approvals.approvals = response.data.approvals;

                response.data.links.forEach(function(link) {
                    links[link.rel.replace('approval/', '')] = link.url;
                });

                approvals.links = links;
                approvalsDeferred.resolve(approvals);
            });

            return approvalsDeferred.promise;
        },

        updateApprovalStatus: function (processLink, message) {
            var httpOptions = { url : processLink };

            httpOptions.method = message ? 'POST' : 'GET';

            if (message) {
                httpOptions.data = {
                    comment: message
                };
            }

            return $http(httpOptions);
        }
    };
};

module.exports =['$http', '$q', ApprovalsService];