
angular.module('drmDashboard.fixtures').value('classificationFixtures', {
    endpoints : {
        staticFormDataUrl : '/approvals/classification/static',
        formModelDataUrl : '/approvals/classification'
    },

    // this data will put the form into a valid state
    validForm : {
        staticData :  [{
            category : 'ISDA_TYPE',
            name : 'Type',
            multiselect : true,
            editable: true,
            min : 1,
            max : 3,
            options : [
                { id : 1, text : 'Amending ISDA' },
                { id : 2, text : 'Amending CSA' },
                { id : 3, text : 'New ISDA' },
                { id : 4, text : 'New CSA' }
            ]
        }],
        selectedData : [{
            category:'ISDA_TYPE',
            multiselect : true,
            selected : [1, 2]
        }]
    },


    getStaticFormData : {
        classificationOptions : [
            {
                category : 'ISDA_TYPE',
                name : 'Type',
                multiselect : true,
                editable: false,
                min : 1,
                max : 3,
                options : [
                    { id : 1, text : 'Amending ISDA' },
                    { id : 2, text : 'Amending CSA' },
                    { id : 3, text : 'New ISDA' },
                    { id : 4, text : 'New CSA' },
                    { id : 5, text : 'New document - not CSA or ISDA' },
                    { id : 6, text : 'Amending document - not CSA or ISDA' },
                    { id : 7, text : 'Other' }
                ]
            },
            {
                category : 'ISSUE_TYPE',
                name : 'Issue',
                multiselect : true,
                editable: true,
                min : 1,
                max : 3,
                options : [
                    { id : 1, text : 'Collateral Threshold' },
                    { id : 2, text : 'Cross-Default Threshold' },
                    { id : 3, text : 'CSA Excluded Products', suboptions: [
                        {
                            category : 'CSA_Excluded_Products',
                            name : 'CSA Excluded Products',
                            multiselect : true,
                            editable: true,
                            min : 1,
                            max : 3,
                            options : [
                                { id : 1, text : 'FX' },
                                { id : 2, text : 'FX Spot' },
                                { id : 3, text : 'Commodities' }
                            ]
                        }
                    ]},
                    { id : 4, text : 'High MTA - 5 million and above' },
                    { id : 5, text : 'Initial Margin - UBS Posting' },
                    { id : 6, text : 'No Rehypothecation' },
                    { id : 7, text : 'Non Standard Collateral' },
                    { id : 8, text : 'Optional Termination Event' },
                    { id : 9, text : 'Ratings Contingency', 'suboptions':[{
                        'category' : 'Ratings_Contingency',
                        'name' : 'Ratings Contingency',
                        'editable' : true,
                        'min' : 1,
                        'max' : 1,
                        'multiselect':false,
                        'options' : [
                            {'id' : 46,'text':'Ba2\tBB','suboptions':[]},
                            {'id':51,'text':'Caa1\tCCC+','suboptions':[]},
                            {'id':52,'text':'Caa2\tCCC','suboptions':[]},
                            {'id':56,'text':'C\tD','suboptions':[]},
                            {'id':48,'text':'B1\tB+','suboptions':[]},
                            {'id':45,'text':'Ba1\tBB+','suboptions':[]},
                            {'id':35,'text':'Aaa\tAAA','suboptions':[]},
                            {'id':36,'text':'Aa1\tAA+','suboptions':[]},
                            {'id':38,'text':'Aa3\tAA-','suboptions':[]},
                            {'id':40,'text':'A2\tA','suboptions':[]},
                            {'id':42,'text':'Baa1\tBBB+','suboptions':[]},
                            {'id':50,'text':'B3\tB-','suboptions':[]},
                            {'id':49,'text':'B2\tB','suboptions':[]},
                            {'id':37,'text':'Aa2\tAA','suboptions':[]},
                            {'id':55,'text':'Ca\tC','suboptions':[]},
                            {'id':54,'text':'Ca\tCC','suboptions':[]},
                            {'id':39,'text':'A1\tA+','suboptions':[]},
                            {'id':44,'text':'Baa3\tBBB-','suboptions':[]},
                            {'id':47,'text':'Ba3\tBB-','suboptions':[]},
                            {'id':43,'text':'Baa2\tBBB','suboptions':[]},
                            {'id':53,'text':'Caa3\tCCC-','suboptions':[]},
                            {'id':41,'text':'A3\tA-','suboptions':[]}],
                        'comments' : [{comment_name: 'other_ate'}, {comment_name: 'other_contingency'}]
                        }]},
                    { id : 10, text : 'Other' }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: true,
                min : 1,
                max : 1,
                options : [
                    { id : 1, text : 'Central Bank' },
                    { id : 2, text : 'Corporate' },
                    { id : 3, text : 'Financial Institutions' },
                    { id : 4, text : 'Government/Quasi Government Entity' },
                    { id : 5, text : 'Individual' },
                    { id : 6, text : 'Insurance' },
                    { id : 7, text : 'Leveraged Fund' },
                    { id : 8, text : 'Municipal' },
                    { id : 9, text : 'Mutual/Non-Leveraged Funds or Investment Funds' },
                    { id : 10, text : 'Pension Fund' },
                    { id : 11, text : 'Supranational' },
                    { id : 12, text : 'Other' }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: false,
                min : 1,
                max : 1,
                options : [
                    { id : 1, text : 'Central Bank' },
                    { id : 2, text : 'Corporate' },
                    { id : 3, text : 'Financial Institutions' },
                    { id : 4, text : 'Government/Quasi Government Entity' },
                    { id : 5, text : 'Individual' },
                    { id : 6, text : 'Insurance' },
                    { id : 7, text : 'Leveraged Fund' },
                    { id : 8, text : 'Municipal' },
                    { id : 9, text : 'Mutual/Non-Leveraged Funds or Investment Funds' },
                    { id : 10, text : 'Pension Fund' },
                    { id : 11, text : 'Supranational' },
                    { id : 12, text : 'Other' }
                ]
            }
        ],
        processedClassificationOptions : [
            {
                category : 'ISDA_TYPE',
                name : 'Type',
                multiselect : true,
                editable: false,
                min : 1,
                max : 3,
                options : [
                    { id : 1, text : 'Amending ISDA' },
                    { id : 2, text : 'Amending CSA' },
                    { id : 3, text : 'New ISDA' },
                    { id : 4, text : 'New CSA' },
                    { id : 5, text : 'New document - not CSA or ISDA' },
                    { id : 6, text : 'Amending document - not CSA or ISDA' },
                    { id : 7, text : 'Other' }
                ]
            },
            {
                category : 'ISSUE_TYPE',
                name : 'Issue',
                multiselect : true,
                editable: true,
                min : 1,
                max : 3,
                options : [
                    { id : 1, text : 'Collateral Threshold' },
                    { id : 2, text : 'Cross-Default Threshold' },
                    { id : 3, text : 'CSA Excluded Products', suboptions: [
                        {
                            category : 'ISSUE_TYPE__3__CSA_Excluded_Products',
                            name : 'CSA Excluded Products',
                            multiselect : true,
                            editable: true,
                            min : 1,
                            max : 3,
                            options : [
                                { id : 1, text : 'FX' },
                                { id : 2, text : 'FX Spot' },
                                { id : 3, text : 'Commodities' }
                            ]
                        }
                    ]},
                    { id : 4, text : 'High MTA - 5 million and above' },
                    { id : 5, text : 'Initial Margin - UBS Posting' },
                    { id : 6, text : 'No Rehypothecation' },
                    { id : 7, text : 'Non Standard Collateral' },
                    { id : 8, text : 'Optional Termination Event' },
                    { id : 9, text : 'Ratings Contingency', 'suboptions':[{
                        'category' : 'ISSUE_TYPE__9__Ratings_Contingency',
                        'name' : 'Ratings Contingency',
                        'editable' : true,
                        'min' : 1,
                        'max' : 1,
                        'multiselect':false,
                        'options' : [
                            {'id' : 46,'text':'Ba2\tBB','suboptions':[]},
                            {'id':51,'text':'Caa1\tCCC+','suboptions':[]},
                            {'id':52,'text':'Caa2\tCCC','suboptions':[]},
                            {'id':56,'text':'C\tD','suboptions':[]},
                            {'id':48,'text':'B1\tB+','suboptions':[]},
                            {'id':45,'text':'Ba1\tBB+','suboptions':[]},
                            {'id':35,'text':'Aaa\tAAA','suboptions':[]},
                            {'id':36,'text':'Aa1\tAA+','suboptions':[]},
                            {'id':38,'text':'Aa3\tAA-','suboptions':[]},
                            {'id':40,'text':'A2\tA','suboptions':[]},
                            {'id':42,'text':'Baa1\tBBB+','suboptions':[]},
                            {'id':50,'text':'B3\tB-','suboptions':[]},
                            {'id':49,'text':'B2\tB','suboptions':[]},
                            {'id':37,'text':'Aa2\tAA','suboptions':[]},
                            {'id':55,'text':'Ca\tC','suboptions':[]},
                            {'id':54,'text':'Ca\tCC','suboptions':[]},
                            {'id':39,'text':'A1\tA+','suboptions':[]},
                            {'id':44,'text':'Baa3\tBBB-','suboptions':[]},
                            {'id':47,'text':'Ba3\tBB-','suboptions':[]},
                            {'id':43,'text':'Baa2\tBBB','suboptions':[]},
                            {'id':53,'text':'Caa3\tCCC-','suboptions':[]},
                            {'id':41,'text':'A3\tA-','suboptions':[]}],
                        'comments' : [{comment_name: 'other_ate'}, {comment_name: 'other_contingency'}]
                    }]},
                    { id : 10, text : 'Other' }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: true,
                min : 1,
                max : 1,
                options : [
                    { id : 1, text : 'Central Bank' },
                    { id : 2, text : 'Corporate' },
                    { id : 3, text : 'Financial Institutions' },
                    { id : 4, text : 'Government/Quasi Government Entity' },
                    { id : 5, text : 'Individual' },
                    { id : 6, text : 'Insurance' },
                    { id : 7, text : 'Leveraged Fund' },
                    { id : 8, text : 'Municipal' },
                    { id : 9, text : 'Mutual/Non-Leveraged Funds or Investment Funds' },
                    { id : 10, text : 'Pension Fund' },
                    { id : 11, text : 'Supranational' },
                    { id : 12, text : 'Other' }
                ]
            },
            {
                category : 'CLIENT_TYPE',
                name : 'Client Type',
                multiselect : false,
                editable: false,
                min : 1,
                max : 1,
                options : [
                    { id : 1, text : 'Central Bank' },
                    { id : 2, text : 'Corporate' },
                    { id : 3, text : 'Financial Institutions' },
                    { id : 4, text : 'Government/Quasi Government Entity' },
                    { id : 5, text : 'Individual' },
                    { id : 6, text : 'Insurance' },
                    { id : 7, text : 'Leveraged Fund' },
                    { id : 8, text : 'Municipal' },
                    { id : 9, text : 'Mutual/Non-Leveraged Funds or Investment Funds' },
                    { id : 10, text : 'Pension Fund' },
                    { id : 11, text : 'Supranational' },
                    { id : 12, text : 'Other' }
                ]
            }
        ]
    },
    get : [
        { category:'ISDA_TYPE', multiselect : true, selected : [1, 2]},
        {
            category:'ISSUE_TYPE',
            multiselect : true,
            selected : [3, 4, 9],
            3 : [{
                category : 'CSA_Excluded_Products',
                multiselect : true,
                selected: [1, 2]
            }],
            9 : [{
                category : 'Ratings_Contingency',
                multiselect: false,
                selected: [1],
                comments: [{comment_name : 'other_ate', comment_value: 'some other ate'}]
            }]
        },
        {
            category:'CLIENT_TYPE',
            multiselect : false,
            selected : [5]
        }
    ],

    // used to test the filtering of classification data which is PUT to the api
    unfilteredPut : [
        {category:'ISSUE_TYPE'},
        {category:'CLIENT_TYPE'},
        {category:'ISDA_TYPE'},
        {category:'MADEUP_TYPE'},
        {category:'FOO_TYPE'}
    ],

    // the PUT data is a reduced array as we only return data which is editable.
    put : [
        {
            category:'ISSUE_TYPE',
            selected : [3, 4, 9],
            3 : [{
                category : 'CSA_Excluded_Products',
                selected: [1, 2]
            }],
            9 : [{
                category : 'Ratings_Contingency',
                selected: [1],
                comments: [{comment_name : 'other_ate', comment_value: 'some other ate'}]
            }]
        },
        {
            category:'CLIENT_TYPE',
            selected : [5]
        }
    ],

    classificationModel: {
        ISDA_TYPE: {
            1 : true,
            2 : true
        },
        ISSUE_TYPE: {
            3 : true,
            4 : true,
            9 : true
        },
        ISSUE_TYPE__3__CSA_Excluded_Products : {
            1 : true,
            2 : true
        },
        ISSUE_TYPE__9__Ratings_Contingency : '1',
        ISSUE_TYPE__9__Ratings_Contingency__comment__other_ate: 'some other ate',
        CLIENT_TYPE: '5'
    }
});