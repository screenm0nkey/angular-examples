'use strict';

var ClassificationService = function ($http, $q, endpoints) {
    var modelSeparator = '__';

    var getSelectedFormData = function (url) {
        var defer = $q.defer();

        $http({
            method : 'GET',
            url : url
        }).success(function (resp) {
            defer.resolve(resp);
//          defer.resolve(dynamicModelData);
        }).error(function () {});

        return defer.promise;
    };


    var getStaticFormData = function (url) {
        var defer = $q.defer();

        $http({
            method : 'GET',
            url : url
        }).success(function (resp) {
            defer.resolve(resp);
//          defer.resolve(staticModelData);
        }).error(function(){});

        return defer.promise;
    };


    var update = function (opts) {
        var defer = $q.defer();
        var dataArray = convertDataFromAngularFormModel(opts.modelFormData);

        $http({
            method : 'PUT',
            url : opts.url,
            data : removeNonEditableValues(dataArray, opts.staticFormData)
        }).success(function () {
            defer.resolve(true);
        });

        return defer.promise;
    };


    var getFormData = function(requestClassificationUrl){
        var defer = $q.defer();

        getStaticFormData(endpoints.classifications).then(function (staticFormData) {
            getSelectedFormData(requestClassificationUrl).then(function (modelFormData) {

                modelFormData = convertDataToAngularFormModel(modelFormData);
                staticFormData = renameSubclassificationCategories(staticFormData);
                decorateModelFormDataWithStaticDataKeys(staticFormData, modelFormData);

                defer.resolve({
                    staticFormData: staticFormData,
                    modelFormData: modelFormData
                });
            });
        });

        return defer.promise;
    };


    var removeNonEditableValues = function(dataArray, staticFormData){
        var editableArray = _.pluck(_.where(staticFormData, {editable:true}), 'category');

        var filteredArray = _.filter(dataArray, function (item) {
            return _.contains(editableArray, item.category);
        });

        return filteredArray;
    };

    var renameSubclassificationCategories = function (staticClassificatioData) {
        _.each(staticClassificatioData, function (classification) {
            if(classification.options && classification.options.length) {
                _.each(classification.options, function (classificationOption) {
                    if(classificationOption.hasOwnProperty('suboptions')) {
                        _.each(classificationOption.suboptions, function (suboption) {
                            suboption.category = classification.category + modelSeparator + classificationOption.id + modelSeparator +suboption.category;
                        });
                    }
                });
            }
        });
        return staticClassificatioData;
    };


    // If a form has not been classified then then form model data will be an
    // empty object, which is no good for the classification form as it will throw
    // a js error if the keys don't match-up with the static data
    var decorateModelFormDataWithStaticDataKeys = function (staticData, formModelData) {
        _.each(staticData, function(item) {
            if (!formModelData[item.category]) {
                formModelData[item.category] = {};
            }

            _.each(item.options, function (option) {
                if (option.suboptions && option.suboptions.length) {

                    _.each(option.suboptions, function (suboption) {
                       if (!formModelData[suboption.category]) {
                            formModelData[suboption.category]  = {};
                        }
                    });
                }
            });
        });
    };


    var getSelectedValuesAsArray = function (obj) {
        var arr = [];

        if (_.isArray(obj)) {
            arr = obj;
        }
        else if (_.isString(obj) || _.isNumber(obj)){
            arr.push(parseInt(obj, 10));
        }
        else if (_.isObject(obj)) {
            _.each(obj, function(value, key){
                if (value) {
                    arr.push(parseInt(key, 10));
                }
            });
        }

        return _.compact(arr);
    };


    var getSelectedValuesAsString = function(options, selected, htmltag, className) {
        var arr = [];

        _.each(options, function(option){
            if (_.contains(selected, option.id)) {
                var cls = className ? ' class="' + className + '"' : '';
                var text = htmltag ? '<' + htmltag + cls + '>' + option.text + '</' + htmltag + '>' : option.text;
                arr.push(text);
            }
        });

        return arr.join(', ');
    };


    var convertToFormObj= function(formItem){
        var obj = {};

        if (formItem.selected && formItem.selected.length) {
            if (formItem.multiselect === true) {
                var values = {};
                obj[formItem.category] = values;

                _.each(formItem.selected, function (selected) {
                    values[selected] = true;
                });

            } else if (formItem.multiselect === false) {
                obj[formItem.category] = String(formItem.selected[0]);
            }
        }

        return obj;
    };

    var extractComments = function (formItem) {
        var obj = {};

        _.each(formItem.comments, function (comment) {
            obj[formItem.category + modelSeparator + 'comment' + modelSeparator + comment.comment_name] = comment.comment_value;
        });

        return obj;
    };

    var extractSubSelections = function (formItem) {
        var subArray = [];

        _.each(formItem.selected, function (selectedId) {
            if(formItem[selectedId]) {
                _.each(formItem[selectedId], function (suboption) {
                    suboption.category = [formItem.category, modelSeparator, selectedId, modelSeparator, suboption.category].join('');
                });
                subArray = subArray.concat(formItem[selectedId]);
            }
        });

        return subArray.length ? subArray : null;
    };


    var convertDataToAngularFormModel = function (formDataArray) {
        var obj = {};
        var buildSelectionsRecursively = function(formItem) {
            if (formItem.selected.length) {
                var subs = extractSubSelections(formItem);
                if (_.isArray(subs)) {
                    _.each(subs, function (sub) {
                        buildSelectionsRecursively(sub);
                    });
                }
                angular.extend(obj, convertToFormObj(formItem));
            }
            if (formItem.comments && formItem.comments.length) {
                angular.extend(obj, extractComments(formItem));
            }
        };

        for (var i = formDataArray.length - 1; i >= 0; i--) {
            buildSelectionsRecursively(formDataArray[i]);
        }

        return obj;
    };

    var convertDataFromAngularFormModel = function (formModelData) {
        var dataArray = [];
        var subsArray = [];
        var commentsArray = [];

        _.each(formModelData, function (angularClassificationRepresentation, angularCategoryRepresentation) {
            var categoryPathFragments = angularCategoryRepresentation.split('__');
            if (angularCategoryRepresentation.indexOf('comment') >= 0) {
                commentsArray.push({
                    comment_value: angularClassificationRepresentation,
                    commentPath: categoryPathFragments}
                );

            } else {
                var classification = getSelectedValuesAsArray(angularClassificationRepresentation);

                if (categoryPathFragments.length > 1) {
                    subsArray.push({values: classification, pathFragments: categoryPathFragments});
                }

                if (classification.length && categoryPathFragments.length === 1) {
                    dataArray.push({
                        category : categoryPathFragments[0],
                        selected : classification
                    });
                }
            }
        });

        addSubclassificationToUpdatedData(subsArray, dataArray);
        addCommentsToUpdatedData(commentsArray, dataArray);

        return dataArray;
    };

    var addSubclassificationToUpdatedData = function (subsArray, dataArray) {
        _.each(subsArray, function(subClassification){

            var categoryPathFragments = subClassification.pathFragments;

            if (subClassification.values) {
                var parentCategory = categoryPathFragments.shift();
                var obj = {};

                if(subClassification.values.length) {
                    obj[categoryPathFragments.shift()] = [{
                        category : categoryPathFragments.shift(),
                        selected : subClassification.values
                    }];
                }

                var classificationObject = _.find(dataArray, {category: parentCategory});
                angular.extend(classificationObject, obj);
            }
        });
    };

    var addCommentsToUpdatedData = function (commentsArray, dataArray) {
        _.each(commentsArray, function (comment) {
            var commentPath = comment.commentPath;
            var commentValue = comment.comment_value;
            var commentName = commentPath.pop();
            //remove 'comment' keyword from path
            commentPath.pop();

            var addCommentToClassificationObject = function(classificationObject) {
                classificationObject.comments = classificationObject.comments || [];
                classificationObject.comments.push({comment_name: commentName, comment_value: commentValue});
            };

            var classificationObject = _.find(dataArray, {category: commentPath.shift()});
            if(commentPath.length) {
                var subClassificationObject = _.find(classificationObject[commentPath.shift()], {category: commentPath.shift()});
                addCommentToClassificationObject(subClassificationObject);
            } else {
                addCommentToClassificationObject(classificationObject);
            }
        });
    };

    var getSubOption = (function () {
        var suboptionStore = {};

        return function(staticFormData, name) {
            if (!suboptionStore[name]) {
                _.each(staticFormData, function (item) {
                    _.each(item.options, function (option) {
                        _.each(option.suboptions, function (suboptions) {
                            if (suboptions.name === name) {
                                suboptionStore[name] = suboptions;
                            }
                        });
                    });
                });
            }

            return suboptionStore[name];
        };
    }());

    return {
        update : update,
        getStaticFormData : getStaticFormData,
        getSelectedFormData : getSelectedFormData,
        getFormData : getFormData,
        addStaticDataKeys : decorateModelFormDataWithStaticDataKeys,
        getSelectedValuesAsArray : getSelectedValuesAsArray,
        getSelectedValuesAsString : getSelectedValuesAsString,
        convertDataToAngularFormModel : convertDataToAngularFormModel,
        removeNonEditableValues : removeNonEditableValues,
        extractSubSelections : extractSubSelections,
        convertToFormObj : convertToFormObj,
        getSubOption : getSubOption
    };
};

module.exports =['$http', '$q', 'endpoints', ClassificationService];