'use strict';

xdescribe('Classification Summary Directive', function () {
    var $directiveFormElement;
    var $button;
    var $scope;
    var $rootScope;
    var $compile;
    var $httpBackend;
    var fixtures;
    var staticFormData;
    // selectedFormData is the data from the api which has not been formatted
    var selectedFormData;
    // modelFormData is the angular formatted selectedFormData
    var modelFormData;

    beforeEach(module('ngSanitize'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.requestApprovals'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('/templates/requestApprovals/classification.html'));
    beforeEach(module('/templates/requestApprovals/formElements/selectionList.html'));

    beforeEach(module(function ($provide) {
        $provide.value('endpoints', {
            classifications : '/approvals/classification/static'
        });
    }));

    beforeEach(inject(function (_$rootScope_, _$compile_, _$httpBackend_, _classificationFixtures_) {
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
        $scope.featureEnabled = function () {return true;};
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        fixtures = angular.copy(_classificationFixtures_);
        staticFormData = fixtures.getStaticFormData.classificationOptions;
        selectedFormData = fixtures.get;
        modelFormData = fixtures.classificationModel;
    }));

    afterEach(function () {
        $directiveFormElement.remove();
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    var renderDirective = function (selectedFormDataFromApi) {
        selectedFormDataFromApi = selectedFormDataFromApi || selectedFormData;
        $scope.requestDetails = {
            links : {
                classifications: fixtures.endpoints.formModelDataUrl
            }
        };

        $httpBackend.expect('GET', '/approvals/classification/static').respond(200, staticFormData);
        $httpBackend.expect('GET', fixtures.endpoints.formModelDataUrl).respond(200, selectedFormDataFromApi);

        $directiveFormElement = angular.element('<div drm-classification></div>');
        $compile($directiveFormElement)($scope);
        $('body').append($directiveFormElement);
        $scope.$digest();
        $button = $directiveFormElement.find('button[type="submit"]');
        $httpBackend.flush();
    };

    describe('displaying summary message', function () {
        var messageClass = '.alert-summary';

        it('should display summary of the form classification if any of the form elements have been selected', function () {
            renderDirective();
            var $message = $directiveFormElement.find(messageClass);
            expect($message.is(':visible')).toBe(true);
        });

        it('should not display summary if none of the form elements have been selected', function () {
            renderDirective([]);
            var $message = $directiveFormElement.find(messageClass);
            expect($message.is(':visible')).toBe(false);
        });

        it('should generate a message based on selections made in form', function () {
            renderDirective();
            var message = $($scope.summaryMessage).text();
            expect(message).toBe('Classification SummaryClient Type : IndividualClient Type : IndividualIssue : CSA Excluded Products, High MTA - 5 million and aboveType : Amending ISDA, Amending CSA');
        });

        it('should not generate a message if no form options are selected', function () {
            renderDirective([]);
            var message = $($scope.summaryMessage).text();
            expect(message).toBe('Classification Summary');
        });
    });


});