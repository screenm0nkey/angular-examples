'use strict';

require('./ngGrid/ngGridModule.src.js');
require('./documents/documentsModule.src.js');
require('./authorisation/authorisationModule.src.js');
require('./reporting/reportingModule.src.js');
require('./tasks/tasksModule.src.js');
require('./user/userModule.src.js');
require('./requestApprovals/approvalsModule.src.js');
require('./requestCreator/requestCreatorModule.src.js');
require('./requestDetails/requestDetailsModule.src.js');
require('./requestEditor/requestEditorModule.src.js');
require('./navigation/navigationModule.src.js');
require('./shared/sharedComponentsModule.src.js');
require('./errors/module.src.js');

window.console = window.console || {
    log: function () {}
};

// Declare app level module which depends on filters, and services
var drmDashboard = angular.module('drmDashboard', [
    'ngAnimate',
    'ngGrid',
    'ngGridHeader',
    'ngRoute',
    'ngSanitize',
    'angularFileUpload',
    'angular-loading-bar',
    'ui.bootstrap',
    'drmDashboard.ngGrid',
    'drmDashboard.documents',
    'drmDashboard.reporting',
    'drmDashboard.tasks',
    'drmDashboard.requestApprovals',
    'drmDashboard.requestCreator',
    'drmDashboard.requestDetails',
    'drmDashboard.requestEditor',
    'drmDashboard.navigation',
    'drmDashboard.sharedComponents',
    'drmDashboard.authorisation',
    'drmDashboard.user',
    'drmDashboard.errors'
]);

// this allows us to lazy-load services after the app has boot-strapped
drmDashboard.config(function($controllerProvider, $compileProvider, $filterProvider, $provide) {
    drmDashboard.$controller = $controllerProvider;
    drmDashboard.$compile = $compileProvider;
    drmDashboard.$filter = $filterProvider;
    drmDashboard.$provide = $provide;
});


drmDashboard.config(['$httpProvider', function($httpProvider){
    // Add the interceptor to the $httpProvider. We use it to catch https errors.
    $httpProvider.interceptors.push('ErrorInterceptorService');
}]);


drmDashboard.config([ '$routeProvider', '$locationProvider',
    function($routeProvider, $locationProvider) {
        var originalWhen = $routeProvider.when;

        // we make sure we resolve the static links end points and SOO user
        // for all routes. the Auth service depends on the static links so we
        // call the endpoints service first to get links.
        $routeProvider.when = function(path, route){
            route.resolve = route.resolve || {};
            route.resolve = {
                bootstrap : function (endpoints, authorisationService) {
                    return endpoints.getStaticLinks().then(function(){
                        return authorisationService.getSSOUser();
                    });
                }
            };
            return originalWhen(path, route);
        };

        $routeProvider.when('/tasks', {
            templateUrl : 'templates/tasks/tasks.html',
            controller : 'TasksController'
        });
        $routeProvider.when('/reporting', {
            templateUrl : 'templates/reporting/reporting.html',
            controller : 'ReportingCtrl'
        });
        $routeProvider.when('/requestDetails/:id', {
            templateUrl : 'templates/requestDetails/requestDetails.html',
            controller : 'RequestDetailsCtrl',
            controllerAs : 'RequestDetails'
        });
        $routeProvider.when('/requestDetails/:id/edit', {
            templateUrl : 'templates/requestEditor/requestEditor.html',
            controller : 'RequestEditorCtrl'
        });
        $routeProvider.when('/request/amendment', {
            templateUrl : 'templates/requestCreator/requestCreator.html',
            controller : 'RequestCreatorCtrl'
        });
        $routeProvider.when('/error/:id', {
            templateUrl: 'templates/errors/default.html',
            controller : 'ErrorController'
        });
        $routeProvider.otherwise({
            redirectTo : '/tasks'
        });
        $locationProvider.html5Mode(true);
    }
]);

drmDashboard.run(['$log', '$rootScope', 'featureSwitch', function($log, $rootScope, featureSwitch){
    // handy for logging in views
    $rootScope.$log = $log;
    $rootScope.featureEnabled = featureSwitch.featureEnabled;
    $rootScope.featureDisabled = featureSwitch.featureDisabled;
}]);