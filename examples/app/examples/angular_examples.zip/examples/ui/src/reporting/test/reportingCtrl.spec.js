'use strict';


describe('Reporting controller', function () {
    var $scope;
    var reportingPromise;
    var statusClassService;
    var ReportingCtrl;
    var tasksColumnService;
    var reportingService;
    var endpoints;
    var ngGridDefaultObj = { someval : 11 };

    beforeEach(module('drmDashboard.reporting'));
    beforeEach(module('drmDashboard.sharedComponents'));

    beforeEach(inject(function($rootScope, $controller, _endpoints_) {
        var ngGridDefaults = sinon.spy(function() {
            return ngGridDefaultObj;
        });

        endpoints = _endpoints_;

        reportingPromise = {
            success: sinon.spy(),
            error: sinon.spy(),
            then:sinon.spy()
        };

        statusClassService = {
            getApprovalColorClass: sinon.spy(),
            getApprovalIconClass: sinon.spy()
        };

        reportingService = {
            query : sinon.spy(function(){
                return {
                    then : sinon.spy()
                };
            }),
            exportCSV : sinon.spy(function () {
                return reportingPromise;
            })
        };

        tasksColumnService = {
            tasksColumnDefinitions : sinon.spy()
        };

        $scope = $rootScope.$new();

        ReportingCtrl = $controller('ReportingCtrl', {
            $scope : $scope,
            reportingService : reportingService,
            statusClassService: statusClassService,
            ngGridDefaults:ngGridDefaults,
            tasksColumnService : tasksColumnService
        });
    }));


    describe('prepare ng-grid options for displaying grid data', function () {
        it('should get default grid options', function () {
            expect($scope.gridOptions ).toBe(ngGridDefaultObj);
            expect(reportingService.query.called ).toBe(true);
        });
    });

    describe('exportCSV method', function () {
        it('should call exportCSVService`s export csv method', function () {
            $scope.exportCSV();
            expect(reportingService.exportCSV.called).toBe(true);
        });

        it('should bind the success case to success handler', function () {
            $scope.exportCSV();
            expect(reportingPromise.success.called).toBe(true);
            expect(reportingPromise.success.calledWith($scope.exportSuccessHandler)).toBe(true);
        });

        it('should bind the failure case to failure handler', function () {
            $scope.exportCSV();
            expect(reportingPromise.error.called).toBe(true);
            var reportingPromiseArguments = reportingPromise.error.getCall(0).args;
            expect(reportingPromiseArguments[0]).toBe($scope.exportErrorHandler);
        });
    });

    describe('after exporting the csv', function () {
        describe('if there is an error', function () {
            it('it should set the error message in scope', function () {
                /* GIVEN */
                var expectedMessage = 'foo';
                var data = {
                    errors: [{
                        code: 1,
                        message: expectedMessage
                    }]
                };
                /* WHEN */
                $scope.exportErrorHandler(data, status);
                /* THEN */
                expect($scope.exportingErrorMsg).toBe(expectedMessage);
            });
        });

        describe('on success', function () {
            it('append an iFrame at the end of the document', function () {
                /* GIVEN */
                var originalBodyHTML = document.body.innerHTML;
                var endpoint = endpoints['reporting-csv'];
                var expectedIFrame = '<iframe src="' + endpoint + '" style="display: none;" width="1px" height="1px"></iframe>';

                /* WHEN */
                $scope.exportSuccessHandler();

                /* THEN */
                var newBodyHTML = document.body.innerHTML;
                expect(newBodyHTML.slice(originalBodyHTML.length).trim()).toEqual(expectedIFrame.trim());
            });
        });
    });

    describe('default scope values', function () {
        it('should assign statusClassService methods to scope', function () {
            /* WHEN */
            ReportingCtrl.getApprovalColorClass();
            ReportingCtrl.getApprovalIconClass();

            /* THEN */
            expect(statusClassService.getApprovalColorClass.called).toBe(true);
            expect(statusClassService.getApprovalIconClass.called).toBe(true);
        });
    });
});