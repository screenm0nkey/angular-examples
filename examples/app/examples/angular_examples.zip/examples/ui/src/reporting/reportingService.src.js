'use strict';

var ReportingService = function ($http, $q, tasksService, endpoints) {
    var query = function () {
        var deferred = $q.defer();

        $http({
            method: 'GET',
            url: endpoints.reporting,
            cache: false
        }).success(function (tasks) {
            var ngGridRowData = tasksService.formatTask(tasks);
            deferred.resolve(ngGridRowData);
        });

        return deferred.promise;
    };


    var exportCSV = function () {
        return $http({
            url: endpoints['reporting-csv'],
            method:'GET',
            headers: {
                'Accept': 'application/octet-stream'
            }
        });
    };


    return {
        query : query,
        exportCSV : exportCSV
    };
};

module.exports = ['$http', '$q', 'tasksService', 'endpoints', ReportingService];

