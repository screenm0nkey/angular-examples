var ReportingController = require('./reportingCtrl.src.js');
var ReportingService = require('./reportingService.src.js');

angular.module('drmDashboard.reporting', [])
    .factory('reportingService', ReportingService)
    .controller('ReportingCtrl', ReportingController);
