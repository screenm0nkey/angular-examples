/*jshint maxparams:7*/
'use strict';

var ReportingController = function ($scope, reportingService, statusClassService, ngGridDefaults, tasksColumnService, endpoints) {
    $scope.exportErrorHandler = function (data) {
        $scope.exportingErrorMsg = data.errors[0].message;
    };

    $scope.exportSuccessHandler = function () {
        var endpoint = endpoints['reporting-csv'];
        var iFrame = $('<iframe src="' + endpoint + '" style="display: none;" width="1px" height="1px">');
        $('body').append(iFrame);
    };

    // TODO - Get the CSV export button logic into a directive inc the handlers above
    $scope.exportCSV = function() {
        var reportingPromise = reportingService.exportCSV();
        reportingPromise.success($scope.exportSuccessHandler);
        reportingPromise.error($scope.exportErrorHandler);
    };

    $scope.title = 'Reporting';

    this.getApprovalIconClass = statusClassService.getApprovalIconClass;
    this.getApprovalColorClass = statusClassService.getApprovalColorClass;

    $scope.gridOptions = ngGridDefaults({
       sortInfo: { fields:['entity.updated_at'], directions: ['desc'] }
    });

    // display the tasks data using ngGrid. Show all columns regardless of ssouser group.
    reportingService.query().then(function(tasks) {
        $scope.tasks = tasks;
        $scope.columnDefs = tasksColumnService.reportingColumnDefinitions(tasks);
        // TODO - Write test to check this is set when tasks are empty
        $scope.noTasksMsg = !$scope.tasks.length;
    });
};


module.exports = ['$scope', 'reportingService', 'statusClassService','ngGridDefaults', 'tasksColumnService', 'endpoints', ReportingController];