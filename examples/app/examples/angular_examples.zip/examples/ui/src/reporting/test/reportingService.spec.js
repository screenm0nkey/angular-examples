'use strict';

describe('reportingService', function () {
    var reportingService;
    var $httpBackend;
    var serverResponse;
    var expectedServiceOutput;
    var endpoints;
    var formatTask = sinon.spy(function() {
        return expectedServiceOutput;
    });

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('tasksService', {
                formatTask : formatTask
            });
        });
    });

    beforeEach(function () {
        module('drmDashboard.reporting');
        module('drmDashboard.sharedComponents');
        module('drmDashboard.fixtures');

        inject(function (_reportingService_, _$httpBackend_, tasksFixtures, _endpoints_) {
            serverResponse = tasksFixtures.tasks.data;
            expectedServiceOutput = tasksFixtures.formattedTasksAllGroups.data;
            reportingService = _reportingService_;
            endpoints = _endpoints_;
            $httpBackend = _$httpBackend_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });


    describe('query method', function () {
        it('should call http service with appropriate url and process data', function () {
            var promise = reportingService.query();
            $httpBackend.when('GET', endpoints.reporting).respond(200, serverResponse);

            promise.then(function (data) {
                expect(data).toEqual(expectedServiceOutput);
            });

            $httpBackend.flush();
        });
    });

    describe('exportCSV method', function () {
        it('should call api  with appropriate url and header info', function () {
            $httpBackend.expectGET(endpoints['reporting-csv'], {
                'Accept': 'application/octet-stream'
            }).respond(200);

            reportingService.exportCSV();
            $httpBackend.flush();
        });
    });

});