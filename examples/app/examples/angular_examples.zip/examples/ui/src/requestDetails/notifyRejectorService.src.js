'use strict';

var NotifyRejectorService = function($http) {

    return {
        notify: function (requestId) {
            var promise = $http({
                url: '/approvals/requests/' + requestId + '/notify',
                method: 'GET'
            });

            return promise;
        }
    };
};

module.exports = ['$http', NotifyRejectorService];