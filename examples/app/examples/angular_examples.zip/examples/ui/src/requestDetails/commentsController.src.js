'use strict';

var CommentsController = function ($scope, commentsService) {

    var commentSent = false;

    var retrieveComments = function () {
        commentsService
            .query($scope.requestDetails.links.comments)
            .then(function (response) {
                $scope.comments = response;
                commentSent = false;
            });
    };

    this.addComment = function () {
        if (!commentSent) {
            commentSent = true;
            var comment = {
                message: $scope.comment
            };
            commentsService
                .addComment(comment, $scope.requestDetails.links.comments)
                .then(function () {
                    $scope.comment = '';
                    retrieveComments();
                });
        }
    };

    retrieveComments();
};

module.exports = ['$scope', 'commentsService', CommentsController];
