'use strict';


describe('Request Details Service', function () {
    var requestDetailsService;
    var requestId;
    var $httpBackend;
    var pathExtractor;
    var fixtures;


    beforeEach( function () {
        requestId = 7;

        pathExtractor = {
            extract: sinon.spy(function (url) {
                return  url;
            })
        };

        module(function ($provide) {
            $provide.value('pathExtractor', pathExtractor);
        });
        module('drmDashboard.requestDetails');
        module('drmDashboard.fixtures');
        inject(function (_RequestDetailsService_, _$httpBackend_, _requestDetails_) {
            requestDetailsService = _RequestDetailsService_;
            $httpBackend = _$httpBackend_;
            fixtures = _requestDetails_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('query method', function () {
        it('should call http service and respond with a promise', function () {
            /* GIVEN */
            var serverResponse = fixtures.query;
            var expectedRequestDetails = {
                entity: fixtures.query.entity,
                links: fixtures.links
            };

            /* WHEN */
            var detailsPromise = requestDetailsService.query(requestId);
            $httpBackend.when('GET', '/approvals/requests/' + requestId).respond(serverResponse);

            /* THEN */
            detailsPromise.then(function (response) {
                expect(response).toEqual(expectedRequestDetails);
            });

            $httpBackend.flush();
        });
    });

    describe('get method', function () {
        it('should call http service with given url and respond with proper promise', function () {
            /* GIVEN */
            var expectedRequestDetails = {
                entity: fixtures.query.entity,
                links: fixtures.links
            };
            var url='someUrl';

            /* WHEN */
            var detailsPromise = requestDetailsService.get(url);
            $httpBackend.when('GET', url).respond(fixtures.query);
            $httpBackend.flush();

            /* THEN */
            detailsPromise.then(function (response) {
                expect(response).toEqual(expectedRequestDetails);
            });
        });
    });
});