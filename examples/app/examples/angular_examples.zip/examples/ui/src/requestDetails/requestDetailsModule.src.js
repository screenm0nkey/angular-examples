'use strict';
var RequestDetailsController = require('./requestDetailsController.src.js');
var DocumentsController = require('./documentsController.src.js');
var CommentsService  = require('./commentsService.src.js');
var CommentsController = require('./commentsController.src.js');
var RequestDetailsService = require('./requestDetailsService.src.js');
var NotifyRejectorService = require('./notifyRejectorService.src.js');

angular.module('drmDashboard.requestDetails', [])
    .factory('RequestDetailsService', RequestDetailsService)
    .factory('NotifyRejectorService', NotifyRejectorService)
    .factory('commentsService', CommentsService)
    .controller('RequestDetailsCtrl', RequestDetailsController)
    .controller('DocumentsController', DocumentsController)
    .controller('CommentsController', CommentsController);
