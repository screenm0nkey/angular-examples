'use strict';

var RequestDetailsController = function ($scope, $location, $routeParams, requestDetailsService, notifyRejectorService) {

    requestDetailsService.query($routeParams.id)
        .then(function (requestDetails) {
            if (requestDetails.entity.justification) {
                var justification = requestDetails.entity.justification;
                justification = justification.replace(/>/g, '&gt;');
                justification = justification.replace(/</g, '&lt;');
                justification.replace(/\n/g, '<br />');
            }

            $scope.requestDetails = requestDetails.entity;
            $scope.requestDetails.links = requestDetails.links;
        });

    $scope.title = 'Request';
    $scope.requestId = $routeParams.id;
    $scope.requestDetails = {};

    this.canNotifyRejector = function () {
        return  $scope.requestDetails.status === 'PARTIALLY_REJECTED' || $scope.requestDetails.status === 'FULLY_REJECTED';
    };

    this.notifyRejector = function (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        notifyRejectorService.notify($routeParams.id).then(function () {
            $location.url('/mytasks');
        });
    };
};

module.exports = ['$scope', '$location', '$routeParams', 'RequestDetailsService','NotifyRejectorService', RequestDetailsController];
