'use strict';



var CommentsService = function ($http, $q, userParserService) {

    var query = function (url) {
        var deferred = $q.defer();

        var commentsOptions = {
            url: url,
            method: 'GET'
        };

        var commentsPromise  = $http(commentsOptions);

        commentsPromise.success(function(comments) {
            angular.forEach(comments, function (comment) {
                comment.message = userParserService.wrapUserHTML(comment.message, 'span', 'drm-mentioned-user');
            });

            deferred.resolve(comments);
        });

        return deferred.promise;
    };


    var addComment = function (comment, url) {
        var deferred = $q.defer();

        userParserService.extractGuids(comment.message).then(function (extractedGuids) {
            var commentOptions = {
                url : url,
                method : 'POST',
                data : extractedGuids
            };

            $http(commentOptions).then(function (response) {
                deferred.resolve(response);
            });
        });

        return deferred.promise;
    };

    return {
        query : query,
        addComment : addComment
    };
};

module.exports =['$http', '$q','UserParserService',  CommentsService];