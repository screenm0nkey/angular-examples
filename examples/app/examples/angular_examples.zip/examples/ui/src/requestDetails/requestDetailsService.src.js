'use strict';

var RequestDetailsService = function ($http, $q, $location) {
    return {
        get: function (url) {
            var deferred = $q.defer();

            $http({
                url: url,
                method:'GET'
            }).success(function(response) {
                var requestDetails = {};

                requestDetails.entity = response.entity;
                requestDetails.links = {};

                response.links.forEach(function(link) {
                    requestDetails.links[link.rel.replace('request/', '')] = link.url;
                });

                deferred.resolve(requestDetails);
            });

            return deferred.promise;
        },
        query: function (requestId) {
            return this.get('/approvals/requests/' + requestId);
        },
        // TODO - This needs unit test
        update: function (requestDetails) {
            var deferred = $q.defer();

            if(requestDetails.dox_id) {
                requestDetails.dox_id = parseInt(requestDetails.dox_id, 10);
            }

            $http({
                method: 'PUT',
                url: '/approvals/requests/edit',
                data: requestDetails
            }).success(function(response) {
                $location.url('/requestDetails/' + requestDetails.id);
                deferred.resolve(response);
            });

            return deferred.promise;
        }
    };
};

module.exports =['$http', '$q', '$location', RequestDetailsService];