'use strict';

describe('NotifyRejectorService', function () {
    var promise;
    var httpSpy;
    var notifyRejectorService;

    beforeEach(function () {
        promise = {};
        httpSpy = sinon.spy(function () { return promise;});

        module(function ($provide) {
            $provide.value('$http', httpSpy);
        });
        module('drmDashboard.requestDetails');
        inject(function (_NotifyRejectorService_) {
            notifyRejectorService = _NotifyRejectorService_;
        });
    });

    describe('notify functionality', function () {
        it('should call http service', function () {
            /* GIVEN */

            var requestId = '7';
            var expectedArguments = {
                url: '/approvals/requests/'+requestId+'/notify',
                method: 'GET'
            };
            /* WHEN */

            notifyRejectorService.notify(requestId);

            /* THEN */

            expect(httpSpy.called).toBe(true);

            var putArguments = httpSpy.getCall(0).args;

            expect(putArguments[0]).toEqual(expectedArguments);
        });
    });
});