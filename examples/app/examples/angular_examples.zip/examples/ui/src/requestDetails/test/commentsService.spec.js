'use strict';


describe('Comments Service', function () {
    var commentsService;
    var $httpBackend;
    var pathExtractor;
    var userFixtures;
    var endpoints;


    beforeEach( function () {
        pathExtractor = {
            extract: sinon.spy(function (url) {
                return  url;
            })
        };

        module(function ($provide) {
            $provide.value('pathExtractor', pathExtractor);
        });

        module('drmDashboard.requestDetails');
        module('drmDashboard.user');
        module('drmDashboard.fixtures');
        module('drmDashboard.sharedComponents');

        inject(function (_commentsService_, _$httpBackend_, _userFixtures_, _endpoints_) {
            commentsService = _commentsService_;
            $httpBackend = _$httpBackend_;
            userFixtures = _userFixtures_;
            endpoints = _endpoints_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('query method', function () {
        it('should call http service and respond with a promise', function () {
            /* GIVEN */
            var commentGetEndpointResponse = [
                {message: '@wayne1.quinlivan some comment @nick.lowman commentContinues'},
                {message: 'comment2 @paul.gustafik comment continues @wayne1.quinlivan @requestor'}
            ];

            var expectedComments = [
                {message: '<span class="drm-mentioned-user">@wayne1.quinlivan</span> some comment <span class="drm-mentioned-user">@nick.lowman</span> commentContinues'},
                {message: 'comment2 <span class="drm-mentioned-user">@paul.gustafik</span> comment continues <span class="drm-mentioned-user">@wayne1.quinlivan</span> <span class="drm-mentioned-user">@requestor</span>'}
            ];

            /* WHEN */
            var url = '/approvals/forums/7/posts';
            var commentsPromise = commentsService.query(url);

            /* THEN */
            $httpBackend.expect('GET', url).respond(commentGetEndpointResponse);

            commentsPromise.then(function (response) {
                expect(response).toEqual(expectedComments);
            });

            $httpBackend.flush();
        });
    });

    describe('addComment method', function () {
        it('should extract user ids from message and send augmented object to api', function () {
            /* GIVEN */
            var commentObject = {
                'message' : '@nick.lowman commentText @wayne1.quinlivan and @paul.gustafik @requestor'
            };

            var expectedRequestBody = {
                comment : '@nick.lowman commentText @wayne1.quinlivan and @paul.gustafik @requestor',
                user_ids : ['1','3', '2', 'requestor']
            };

            var url = '/approvals/posts/9';

            /* WHEN */
            commentsService.addComment(commentObject, url);

            /* THEN */
            $httpBackend.expect('GET', endpoints.users).respond(userFixtures.query);
            $httpBackend.expect('POST',url, expectedRequestBody).respond(200);
            $httpBackend.flush();
        });
    });
});