/*jshint maxparams:6*/

'use strict';

describe('RequestDetailsController', function () {
    var $scope;
    var $rootScope;
    var $controller;
    var notifyRejectorPromise;
    var notifyRejectorService;
    var routeParams = { id: 7 };
    var location;
    var RequestDetailsCtrl;
    var $httpBackend;
    var fixture;

    beforeEach(module('drmDashboard.requestDetails'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('ngRoute'));

    beforeEach(inject(function (_$rootScope_, _$controller_, $http, _RequestDetailsService_, _requestDetails_, _$httpBackend_) {
        $rootScope = _$rootScope_;
        $httpBackend = _$httpBackend_;
        fixture = _requestDetails_;
        $controller = _$controller_;
        notifyRejectorPromise = {
            then: function (callback) {
                callback();
            }
        };
        notifyRejectorService = {
            notify: sinon.spy(function () {
                return notifyRejectorPromise;
            })
        };

        location = {
            url: sinon.spy()
        };

        $scope = _$rootScope_.$new();

        // create the request details controller
        RequestDetailsCtrl = $controller('RequestDetailsCtrl', {
            $scope: $scope,
            $http: $http,
            $location: location,
            $routeParams: routeParams,
            RequestDetailsService: _RequestDetailsService_,
            NotifyRejectorService: notifyRejectorService
        });

        $httpBackend.expect('GET', '/approvals/requests/' + routeParams.id).respond(fixture.query);
        $httpBackend.flush();
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('requestId value', function () {
        it('should be equal to routeParams id', function () {
            /* THEN */
            expect($scope.requestId).toBe(routeParams.id);
        });
    });

    describe('get request details from service', function () {
        it('should populate request details.', function () {
            var expectedRequestDetails = _.extend(fixture.query.entity, {links: fixture.links});
            expect($scope.requestDetails).toEqual(expectedRequestDetails);
        });
    });

    describe('Default scope values and methods', function () {
        it('should populate scope title', function () {
            /* THEN */
            expect($scope.title).toBe('Request');
        });
    });

    describe('canNotifyRejector method', function () {
        it('should decide whether a user can notify a rejector', function () {
            /* GIVEN */
            var testCases = [
                {
                    status: 'PARTIALLY_REJECTED',
                    expectedValue: true
                },
                {
                    status: 'FULLY_REJECTED',
                    expectedValue: true
                },
                {
                    status: 'APPROVED',
                    expectedValue: false
                },
                {
                    status: 'PARTIALLY_APPROVED',
                    expectedValue: false
                }
            ];

            testCases.forEach(function (testCase) {
                $scope.currentUser = {};
                $scope.requestDetails = {};
                $scope.currentUser.role = testCase.currentRole;
                $scope.requestDetails.status = testCase.status;

                /* WHEN */
                var canNotifyRejector = RequestDetailsCtrl.canNotifyRejector();

                /* THEN */
                expect(canNotifyRejector).toBe(testCase.expectedValue);
            });
        });
    });

    describe('notifyRejector method', function () {
        var evt = {};
        beforeEach(function(){
            evt.preventDefault = sinon.spy();
            evt.stopPropagation = sinon.spy();
        });

        it('should stop click event bubbling up to avoid issues with accordian functionality', function () {
            /* WHEN */
            RequestDetailsCtrl.notifyRejector(evt);
            /* THEN */
            expect(evt.preventDefault.called).toBe(true);
            expect(evt.stopPropagation.called).toBe(true);
        });

        it('should call NotifyRejectorService and on success redirect the page to "myTasks"', function () {
            /* WHEN */
            RequestDetailsCtrl.notifyRejector(evt);
            /* THEN */
            expect(notifyRejectorService.notify.called).toBe(true);
            var notifyArguments = notifyRejectorService.notify.getCall(0).args;
            expect(notifyArguments[0]).toBe(7);
            expect(location.url.called).toBe(true);
            expect(location.url.calledWith('/mytasks')).toBe(true);
        });
    });
});