/*jshint maxparams:8*/
'use strict';

describe('CommentsController', function () {
    var $scope;
    var $rootScope;
    var $httpBackend;
    var $controller;
    var endpoints;

    var CommentsController;
    var commentsService;
    var commentFixtures;
    var userFixtures;
    var URL = 'commentsUrl';

    beforeEach(module('drmDashboard.requestDetails'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('drmDashboard.user'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('ngRoute'));

    beforeEach(inject(function (_$httpBackend_, _$rootScope_, _$controller_, _commentsService_, _commentsFixtures_, _userFixtures_, _endpoints_) {
        $rootScope = _$rootScope_;
        $controller = _$controller_;
        $httpBackend = _$httpBackend_;
        commentsService = _commentsService_;
        commentFixtures = _commentsFixtures_;
        endpoints = _endpoints_;
        userFixtures = _userFixtures_;
        $scope = _$rootScope_.$new();
        $scope.requestDetails = {};
        $scope.requestDetails.links = {comments: URL};

        CommentsController = $controller('CommentsController', {
            $scope: $scope,
            commentsService: commentsService
        });

        $httpBackend.expect('GET', URL).respond(200, commentFixtures.query);
        $httpBackend.flush();
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('addComment integration', function () {
        it('should call CommentsService add method and on success retrieve all comments', function () {
            /* GIVEN */
            var commentMessage = 'foo';
            $scope.comment = commentMessage;
            $scope.url = URL;

            /* WHEN */
            CommentsController.addComment();
            expect($scope.comment).toBe(commentMessage);

            /*THEN*/
            $httpBackend.expect('GET', endpoints.users).respond(userFixtures.query);
            $httpBackend.expect('POST', URL, {comment: commentMessage, user_ids: []}).respond(201);
            $httpBackend.expect('GET', URL).respond(200);
            $httpBackend.flush();

            expect($scope.comment).toBe('');
        });
    });

    describe('get comments', function () {
        it('should populate comments', function () {
            expect($scope.comments).toEqual(commentFixtures.query);
        });
    });
});