/*jshint maxparams:7*/

'use strict';

describe('DocumentsController', function () {
    var $scope;
    var $rootScope;
    var $controller;
    var DocumentsController;
    var $httpBackend;
    var fixtures;
    var requestDetailsLinks;
    var documentsService;
    var $upload = {upload: sinon.spy()};

    beforeEach(module(function ($provide) {
        $provide.value('$upload', $upload);
    }));

    beforeEach(module('drmDashboard.requestDetails'));
    beforeEach(module('drmDashboard.documents'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('ngRoute'));

    beforeEach(inject(function (_$rootScope_, _$controller_, _pathExtractor_, _documentsFixtures_, _$httpBackend_, _documentsService_, _requestDetails_) {
        $rootScope = _$rootScope_;
        $controller = _$controller_;
        $httpBackend = _$httpBackend_;
        fixtures = _documentsFixtures_;
        requestDetailsLinks = _requestDetails_.links;
        documentsService = _documentsService_;
        $scope = _$rootScope_.$new();
        sinon.spy(documentsService, 'query');
        $scope.requestDetails = {};
        $scope.requestDetails.links = requestDetailsLinks;

        DocumentsController = $controller('DocumentsController', {
            $scope: $scope,
            documentsService: _documentsService_,
            pathExtractor: _pathExtractor_
        });
        $httpBackend.when('GET',requestDetailsLinks.documents).respond(200, {});
        $httpBackend.flush();
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
        documentsService.query.restore();
    });

    describe('when controller loads, get files list', function () {
        it('should populate files details', function () {
            expect(documentsService.query.called).toBe(true);
            expect(documentsService.query.calledWith(requestDetailsLinks.documents)).toBe(true);
            expect($scope.documents).toEqual([]);
        });
    });

    describe('Default scope values and methods', function () {
        it('should populate documentsGridOptions', function () {
            /* GIVEN */
            var expectedGridOptions = {
                data: 'documents',
                columnDefs: 'columnDefs',
                showColumnMenu: true,
                showFilter: true,
                multiSelect: false,
                rowTemplate: '/templates/requestDetails/partials/documentRowTemplate.html'
            };

            /* THEN */
            expect($scope.documentsGridOptions).toEqual(expectedGridOptions);
        });

        it('should populate column definitions', function () {
            /* GIVEN */
            var expectedColumnDefinitions = [
                {
                    field: 'fileName',
                    displayName: 'File',
                    cellTemplate: '/templates/requestDetails/partials/fileCellTemplate.html'
                },
                {
                    field: 'createdAt',
                    displayName: 'Created At',
                    cellTemplate: '/templates/requestDetails/partials/createdAtTemplate.html'
                },
                {
                    field: 'versionCount',
                    displayName: 'Versions'
                }
            ];

            /* WHEN */
            expect($scope.columnDefs).toEqual(expectedColumnDefinitions);
        });

        it('should populate versions grid options definitions', function () {
            /* GIVEN */

            var expectedVersionsGridOptions = {
                data: 'fileVersions',
                columnDefs: 'versionsColumnDefs',
                showColumnMenu: true,
                showFilter: true,
                multiSelect: false
            };

            /* THEN */
            expect($scope.versionsGridOptions).toEqual(expectedVersionsGridOptions);
        });

        it('should populate versionsColumn definitions', function () {
            /* GIVEN */

            var expectedVersionColumnDefs = [
                {
                    field: 'downloadLink',
                    displayName: 'Download',
                    cellTemplate: '/templates/requestDetails/partials/fileCellTemplate.html'
                },
                {
                    field: 'createdAt',
                    displayName: 'Created At',
                    cellTemplate: '/templates/requestDetails/partials/createdAtTemplate.html'
                },
                {
                    field: 'createdBy',
                    displayName: 'Created By'
                }
            ];

            /* THEN */
            expect($scope.versionsColumnDefs).toEqual(expectedVersionColumnDefs);
        });
    });


    describe('onFileSelect method', function () {
        it('should assign selected files to scope variable', function () {
            /* GIVEN */
            var expectedFiles = ['file1', 'file2'];

            /* WHEN */
            DocumentsController.onFileSelect(expectedFiles);

            /* THEN */
            expect($scope.filesToUpload).toEqual(expectedFiles);
        });
    });

    describe('uploadFiles method', function () {
        it('should call file upload Service if there are files to upload', function () {
            /* GIVEN */
            $scope.filesToUpload = ['file1', 'file2'];

            sinon.stub(documentsService, 'upload', function () {
                return {then : function(){}};
            });

            /* WHEN */
            DocumentsController.uploadFiles({ target: 'someTarget'});
            expect(documentsService.upload.called).toBe(true);
            expect(documentsService.upload.getCall(0).args).toEqual([requestDetailsLinks.documentupload, $scope.filesToUpload ]);
            documentsService.upload.restore();
        });


        it('should not call file upload Service if there are no files to upload', function () {
            /* GIVEN */
            $scope.filesToUpload = undefined;

            /* WHEN */
            sinon.stub(documentsService, 'upload', function () {
                return {then : function(){}};
            });
            DocumentsController.uploadFiles();

            /* THEN */
            expect(documentsService.upload.called).toBe(false);
            documentsService.upload.restore();
        });
    });

    describe('displayFileVersions method', function () {
        it('should get the file versions from the RequestDetailsService', function () {
            /* GIVEN */
            $scope.fileVersions = [];

            /* WHEN */
            $httpBackend.expectGET('someURL').respond(fixtures.documentVersionObject);
            DocumentsController.displayFileVersions('someURL');

            $httpBackend.flush();

            /* THEN */
            expect($scope.fileVersions).toEqual(fixtures.formattedDocumentVersionArray);
        });
    });
});