angular.module('drmDashboard.fixtures').value('requestDetails', {
    query : {
        'entity' : {
            'id':1,
            'requested_at':1405342104759,
            'updated_at':1405342104759,
            'priority':'Medium',
            'justification':null,
            'client':'Task 1',
            'client_rxm':null,
            'requester':'Piotr Buza',
            'status':'AWAITING_APPROVAL',
            'type':'AMENDMENT',
            'business_sponsor':null,
            'lead_sales_owner':null,
            'standard_terms':false,
            'existing_trades':true
        },
        'links':[
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/comments',
                'url':'http://drmlocal/collaboration/collaboration/1/posts'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/approvals',
                'url':'http://drmlocal/approvals/required_approvals/1'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/classifications',
                'url':'http://drmlocal/approvals/requests/10/classifications'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/documents',
                'url':'http://drmlocal/approvals/requests/10/files'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/documentupload',
                'url':'http://drmlocal/approvals/requests/10/files/multipart'
            }
        ]
    },
    links: {
        comments: 'http://drmlocal/collaboration/collaboration/1/posts',
        approvals: 'http://drmlocal/approvals/required_approvals/1',
        classifications : 'http://drmlocal/approvals/requests/10/classifications',
        documents : 'http://drmlocal/approvals/requests/10/files',
        documentupload : 'http://drmlocal/approvals/requests/10/files/multipart'
    }
});
