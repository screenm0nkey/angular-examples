angular.module('drmDashboard.fixtures').value('commentsFixtures', {
    query : [
        { message : 'first message'},
        { message : 'second message'}
    ]
});
