/*jshint maxparams:10*/

'use strict';

var DocumentsController = function ($scope, pathExtractor, documentsService) {

    documentsService.query($scope.requestDetails.links.documents).then(function(documents){
        $scope.documents = documents;
    });


    this.onFileSelect = function (files) {
        $scope.filesToUpload = files;
    };

    this.uploadFiles = function (evt) {
        if($scope.filesToUpload) {
            documentsService
                .upload($scope.requestDetails.links.documentupload, $scope.filesToUpload)
                .then(function () {
                    documentsService.query($scope.requestDetails.links.documents).then(function(documents){
                        $scope.documents = documents;
                    });
                    // TODO: this is untested
                    $(evt.target).find('input[type="file"]').val(null);
                    $scope.filesToUpload = undefined;
                });
        }
    };

    this.displayFileVersions = function (url) {
        documentsService.getVersions(url).then(function (versions) {
            $scope.fileVersions = versions;
        });
    };

    $scope.documentsGridOptions = {
        data: 'documents',
        columnDefs: 'columnDefs',
        showColumnMenu: true,
        showFilter: true,
        multiSelect: false,
        rowTemplate: '/templates/requestDetails/partials/documentRowTemplate.html'
    };

    $scope.columnDefs = [
        {
            field: 'fileName',
            displayName: 'File',
            cellTemplate: '/templates/requestDetails/partials/fileCellTemplate.html'
        },
        {
            field: 'createdAt',
            displayName: 'Created At',
            cellTemplate: '/templates/requestDetails/partials/createdAtTemplate.html'
        },
        {
            field: 'versionCount',
            displayName: 'Versions'
        }
    ];

    $scope.versionsGridOptions = {
        data: 'fileVersions',
        columnDefs: 'versionsColumnDefs',
        showColumnMenu: true,
        showFilter: true,
        multiSelect: false
    };

    $scope.versionsColumnDefs = [
        {
            field: 'downloadLink',
            displayName: 'Download',
            cellTemplate: '/templates/requestDetails/partials/fileCellTemplate.html'
        },
        {
            field: 'createdAt',
            displayName: 'Created At',
            cellTemplate: '/templates/requestDetails/partials/createdAtTemplate.html'
        },
        {
            field: 'createdBy',
            displayName: 'Created By'
        }
    ];
};

module.exports = ['$scope', 'pathExtractor', 'documentsService', DocumentsController];
