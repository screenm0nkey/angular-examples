/*jshint maxparams:6*/
'use strict';

var TasksController = function ($scope, tasksService, statusClassService, ngGridDefaults, tasksColumnService) {
    this.getApprovalIconClass = statusClassService.getApprovalIconClass;
    this.getApprovalColorClass = statusClassService.getApprovalColorClass;

    $scope.title = 'Tasks';
    $scope.gridOptions = ngGridDefaults({
         sortInfo: { fields:['entity.updated_at'], directions: ['desc'] }
    });

    tasksService.query().then(function(tasks){
        $scope.tasks = tasks;
        $scope.columnDefs = tasksColumnService.tasksColumnDefinitions(tasks);
        // TODO - Write test to check this is set when tasks are empty.
        $scope.noTasksMsg = !$scope.tasks.length;
    });
};

module.exports = ['$scope','tasksService', 'statusClassService', 'ngGridDefaults', 'tasksColumnService', TasksController];