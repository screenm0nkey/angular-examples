'use strict';

describe('Column Definition Service', function () {
    var $rootScope;
    var tasksColumnService;
    var fixture;
    var columnFixture;

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('SSOUser', {
                isRequestor : true
            });
        });
    });

    beforeEach(function () {
        module('drmDashboard.tasks');
        module('drmDashboard.sharedComponents');
        module('drmDashboard.ngGrid');
        module('drmDashboard.fixtures');
    });

    beforeEach(function () {
        inject(function (_$rootScope_, _tasksColumnService_, tasksFixtures, _columnFixtures_) {
            $rootScope = _$rootScope_;
            tasksColumnService = _tasksColumnService_;
            fixture = tasksFixtures.formattedTasksAllGroups.data;
            columnFixture = _columnFixtures_;
        });
    });

    describe('tasksColumnDefinitions method', function () {
        it('should return column definitions', function () {
            /* WHEN */
            var columnDefinitions = tasksColumnService.tasksColumnDefinitions(fixture);

            /* THEN */
            expect(columnFixture.tasks).toEqual(columnDefinitions);
        });
    });

    describe('reportingColumnDefinitions method', function () {
        it('should return column definitions', function () {
            /* WHEN */
            var columnDefinitions = tasksColumnService.reportingColumnDefinitions(fixture);

            /* THEN */
            expect(columnFixture.reporting).toEqual(columnDefinitions);
        });
    });
});
