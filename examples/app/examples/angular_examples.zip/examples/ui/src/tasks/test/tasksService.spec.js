'use strict';

describe('Tasks Service', function () {
    var $rootScope;
    var service;
    var serverResponse;
    var expectedServiceOutput;
    var formattedTALMTasksFixture;

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('SSOUser', {
               group : 'TALM'
            });
        });
    });

    beforeEach(function () {
        module('drmDashboard.tasks');
        module('drmDashboard.sharedComponents');
        module('drmDashboard.fixtures');
    });

    beforeEach(function () {
        inject(function (_$rootScope_, _tasksService_, tasksFixtures) {
            $rootScope = _$rootScope_;
            service = _tasksService_;
            serverResponse = tasksFixtures.tasks.data;
            expectedServiceOutput = tasksFixtures.formattedTasksAllGroups.data;
            formattedTALMTasksFixture = tasksFixtures.formattedTasksTALM.data;
        });
    });

    describe('formatTask()  method', function () {
        it('should return formatted row including all group information', function () {
            var formattedRow = service.formatTask(serverResponse);
            expect(formattedRow).toEqual(expectedServiceOutput);
        });

        it('should return formatted row even if classification type is empty object', function () {
            var modifiedServerResponse = angular.copy(serverResponse);
            modifiedServerResponse[0].entity.classification_map = {};

            var formattedRow = service.formatTask(modifiedServerResponse);
            var modifiedExpectedServiceOutput = angular.copy(formattedRow);
            modifiedExpectedServiceOutput[0].clientType = ' ';
            modifiedExpectedServiceOutput[0].issueType = ' ';
            modifiedExpectedServiceOutput[0].classificationType =' ';

            expect(formattedRow).toEqual(modifiedExpectedServiceOutput);
        });

        it('should return formatted row including only group information relative to the signed in user', function () {
            var filterByGroup = true;
            var formattedRow = service.formatTask(serverResponse, filterByGroup);
            expect(formattedRow).toEqual(formattedTALMTasksFixture);
        });
    });

});