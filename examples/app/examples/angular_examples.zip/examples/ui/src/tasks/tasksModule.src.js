var TasksController = require('./tasksController.src.js');
var TasksService = require('./tasksService.src.js');
var ColumnDefinitionService = require('./../tasks/columnDefintionService.src.js');

angular.module('drmDashboard.tasks', [])
    .service('tasksService', TasksService)
    .factory('tasksColumnService', ColumnDefinitionService)
    .controller('TasksController', TasksController);