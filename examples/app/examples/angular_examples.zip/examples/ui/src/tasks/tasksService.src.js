/*jshint maxparams:6*/
'use strict';

var TasksService = function ($http, $q, statusClassService, SSOUser, endpoints) {
    var self = this;

    this.query = function () {
        var deferred = $q.defer();

        $http({
            method: 'GET',
            url: endpoints.tasks
        }).success(function (tasks) {
            var filterByGroup = SSOUser.isApprover;
            var formattedTasks = self.formatTask(tasks.tasks, filterByGroup);
            deferred.resolve(formattedTasks);
        });

        return deferred.promise;
    };

    this.formatTask = function(tasks, filterByGroup) {
        var processedTasks = [];

        tasks.forEach(function (task) {
            var processedTask = {
                id : task.entity.id,
                client : task.entity.client,
                requester : task.entity.requester,
                requested_at : task.entity.requested_at,
                updated_at : task.entity.updated_at,
                type : task.entity.type,
                priority : task.entity.priority,
                status : task.entity.status,
                clientType: task.entity.classification_map.CLIENT_TYPE ? task.entity.classification_map.CLIENT_TYPE.join(', ') : ' ',
                issueType: task.entity.classification_map.ISSUE_TYPE ? task.entity.classification_map.ISSUE_TYPE.join(', ') : ' ',
                classificationType: task.entity.classification_map.TYPE ? task.entity.classification_map.TYPE.join(', ') : ' ',
                approvals_summary : []
            };


            task.approvals_summary.forEach(function (approvalSummary) {
                var group = approvalSummary.group.code.replace('DRM_', '');

                // only show group information relative to the user who is signed in.
                if (filterByGroup && SSOUser.group !== group ) {
                    return;
                }

                var processedSummary = {
                    approvedBy: approvalSummary.approved_by,
                    approvedAt: approvalSummary.approved_at,
                    code: group.replace('_', ' '),
                    assignedTo: approvalSummary.assignee,
                    approvalClass : statusClassService.getIconAndColorClasses(approvalSummary, task.entity.requester)
                };

                if (processedSummary.code === 'Global Treasury') {
                    processedSummary.code = 'GT';
                }

                processedTask.approvals_summary.push(processedSummary);
            });

            processedTasks.push(processedTask);
        });

        return processedTasks;
    };
};

module.exports = ['$http', '$q', 'statusClassService', 'SSOUser', 'endpoints', TasksService];