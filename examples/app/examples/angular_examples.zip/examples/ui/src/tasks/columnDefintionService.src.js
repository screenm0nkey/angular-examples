'use strict';

var ColumnDefinitionService = function(ngGridTemplateService, SSOUser) {

    var dateFormat = 'date:\'yyyy/MM/dd hh:mm:ss\'';

    var reducedColumnDefinitions = function (tasks) {
        var columnDefinitions = [
            { field:'client', displayName: 'Client', cellTemplate:'/templates/ngGrid/cells/client.html'},
            { field:'requester', displayName: 'Requestor', width: 200},
            { field:'requested_at', displayName: 'Created', cellFilter: dateFormat, width: 120 },
            { field:'updated_at', displayName: 'Updated', cellFilter: dateFormat, width: 120 },
            { field:'type', displayName: 'Type', cellTemplate: '/templates/ngGrid/cells/type.html', width: 90},
            { field:'status', displayName: 'Status', cellTemplate: '/templates/ngGrid/cells/status.html', width: 100},
            { field:'priority', displayName: 'Priority', width: 60}
        ];

        var firstTask = tasks[0];
        var i, len;

        for (i = 0, len = firstTask.approvals_summary.length; i < len; i++) {
            columnDefinitions.push({
                field: 'approvals_summary['+i+'].approvalClass',
                displayName: firstTask.approvals_summary[i].code + ' Status',
                cellTemplate: ngGridTemplateService.groupStatusCell(i),
                width: 50,
                categoryDisplayName: firstTask.approvals_summary[i].code
            });
        }

        return columnDefinitions;
    };

    var baseColumnDefinitions = function (tasks) {
        var columnDefinitions = reducedColumnDefinitions(tasks);

        //Add column width for case when there more columns than would fit one page width
        columnDefinitions = _.map(columnDefinitions, function (item) {
            if (item.field === 'client') {
                item.width = 200;
            }

            return item;
        });

        var firstTask = tasks[0];
        var i, len;

        for (i = 0, len = firstTask.approvals_summary.length; i < len; i++) {
            columnDefinitions.push({
                field: 'approvals_summary[' + i + '].approvedBy',
                displayName: firstTask.approvals_summary[i].code + ' Approved by',
                categoryDisplayName: firstTask.approvals_summary[i].code,
                width: 120
            });
            columnDefinitions.push({
                field: 'approvals_summary[' + i + '].approvedAt',
                displayName: firstTask.approvals_summary[i].code + ' Time of Approval / Rejection',
                cellFilter: dateFormat,
                categoryDisplayName: firstTask.approvals_summary[i].code,
                width: 120
            });
            columnDefinitions.push({
                field: 'approvals_summary[' + i + '].assignedTo',
                displayName: firstTask.approvals_summary[i].code + ' Assignee',
                categoryDisplayName: firstTask.approvals_summary[i].code,
                width: 120
            });
        }

        return columnDefinitions;
    };

    var tasksColumnDefinitions = function(tasks) {
        if (!tasks.length) {
            return;
        }

        if (SSOUser.isRequestor) {
            return reducedColumnDefinitions(tasks);
        } else if (SSOUser.isApprover) {
            return baseColumnDefinitions(tasks);
        }
    };

    var reportingColumnDefinitions = function (tasks) {
        if (!tasks.length) {
            return;
        }

        var columnDefinitions = baseColumnDefinitions(tasks);
        columnDefinitions.push({'field': 'classificationType', 'displayName': 'Classification Type', 'width': 200});
        columnDefinitions.push({'field': 'issueType', 'displayName': 'Issue Type', 'width': 200});
        columnDefinitions.push({'field': 'clientType', 'displayName': 'Client Type', 'width': 200});

        return columnDefinitions;
    };

    return {
        tasksColumnDefinitions : tasksColumnDefinitions,
        reportingColumnDefinitions : reportingColumnDefinitions
    };

};


module.exports = ['ngGridTemplateService', 'SSOUser', ColumnDefinitionService];