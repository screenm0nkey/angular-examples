/*jshint quotmark:false*/
angular.module('drmDashboard.fixtures').value('columnFixtures', {
    tasks: [
        {'field': 'client', 'displayName': 'Client', 'cellTemplate': "/templates/ngGrid/cells/client.html"},
        {'field': 'requester', 'displayName': 'Requestor', 'width': 200},
        {'field': 'requested_at', 'displayName': 'Created', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'width': 120},
        {'field': 'updated_at', 'displayName': 'Updated', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'width': 120},
        {'field': 'type', 'displayName': 'Type', 'cellTemplate': "/templates/ngGrid/cells/type.html", 'width': 90},
        {'field': 'status', 'displayName': 'Status', 'cellTemplate': "/templates/ngGrid/cells/status.html", 'width': 100},
        {'field': 'priority', 'displayName': 'Priority', 'width': 60},
        {'field': 'approvals_summary[0].approvalClass', 'displayName': 'GT Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[0].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'GT'},
        {'field': 'approvals_summary[1].approvalClass', 'displayName': 'MCOF Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[1].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'MCOF'},
        {'field': 'approvals_summary[2].approvalClass', 'displayName': 'TALM Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[2].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'TALM'}
    ],
    reporting: [
        {'field': 'client', 'displayName': 'Client', 'cellTemplate': "/templates/ngGrid/cells/client.html", 'width': 200},
        {'field': 'requester', 'displayName': 'Requestor', 'width': 200},
        {'field': 'requested_at', 'displayName': 'Created', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'width': 120},
        {'field': 'updated_at', 'displayName': 'Updated', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'width': 120},
        {'field': 'type', 'displayName': 'Type', 'cellTemplate': "/templates/ngGrid/cells/type.html", 'width': 90},
        {'field': 'status', 'displayName': 'Status', 'cellTemplate': "/templates/ngGrid/cells/status.html", 'width': 100},
        {'field': 'priority', 'displayName': 'Priority', 'width': 60},
        {'field': 'approvals_summary[0].approvalClass', 'displayName': 'GT Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[0].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'GT'},
        {'field': 'approvals_summary[1].approvalClass', 'displayName': 'MCOF Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[1].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'MCOF'},
        {'field': 'approvals_summary[2].approvalClass', 'displayName': 'TALM Status', 'cellTemplate': "<div class=\"grid--approval ngCellText\" ng-class=\"col.colIndex()\"><span class=\"glyphicon\" ng-class=row.getProperty(\"approvals_summary[2].approvalClass\")/></div>", 'width': 50, 'categoryDisplayName': 'TALM'},
        {'field': 'approvals_summary[0].approvedBy', 'displayName': 'GT Approved by', 'categoryDisplayName': 'GT', 'width': 120},
        {'field': 'approvals_summary[0].approvedAt', 'displayName': 'GT Time of Approval / Rejection', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'categoryDisplayName': 'GT', 'width': 120},
        {'field': 'approvals_summary[0].assignedTo', 'displayName': 'GT Assignee', 'categoryDisplayName': 'GT', 'width': 120},
        {'field': 'approvals_summary[1].approvedBy', 'displayName': 'MCOF Approved by', 'categoryDisplayName': 'MCOF', 'width': 120},
        {'field': 'approvals_summary[1].approvedAt', 'displayName': 'MCOF Time of Approval / Rejection', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'categoryDisplayName': 'MCOF', 'width': 120},
        {'field': 'approvals_summary[1].assignedTo', 'displayName': 'MCOF Assignee', 'categoryDisplayName': 'MCOF', 'width': 120},
        {'field': 'approvals_summary[2].approvedBy', 'displayName': 'TALM Approved by', 'categoryDisplayName': 'TALM', 'width': 120},
        {'field': 'approvals_summary[2].approvedAt', 'displayName': 'TALM Time of Approval / Rejection', 'cellFilter': "date:'yyyy/MM/dd hh:mm:ss'", 'categoryDisplayName': 'TALM', 'width': 120},
        {'field': 'approvals_summary[2].assignedTo', 'displayName': 'TALM Assignee', 'categoryDisplayName': 'TALM', 'width': 120},
        {'field': 'classificationType', 'displayName': 'Classification Type', 'width': 200},
        {'field': 'issueType', 'displayName': 'Issue Type', 'width': 200},
        {'field': 'clientType', 'displayName': 'Client Type', 'width': 200}
    ]
});
