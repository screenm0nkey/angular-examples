angular.module('drmDashboard.fixtures').value('tasksFixtures', {
    tasks : {
        data : [
            {
                entity: {
                    id: 1,
                    requested_at: 1401807094863,
                    updated_at: 1401807094863,
                    priority: 'Medium',
                    justification: null,
                    client: 'test1',
                    client_rxm: null,
                    requester: 'Piotr Buza',
                    status: 'AWAITING_APPROVAL',
                    type: 'AMENDMENT',
                    process_id: '307',
                    business_sponsor: null,
                    lead_sales_owner: null,
                    standard_terms: true,
                    existing_trades: false,
                    credit_head_email: null,
                    classification_map: {
                        CLIENT_TYPE: ['Central Bank'],
                        ISSUE_TYPE: ['Collateral Threshold', 'Cross-Default Threshold'],
                        TYPE:['Amending ISDA']
                    }
                },
                approvals_summary: [
                    {
                        action: null,
                        approved: false,
                        approved_by: 'foo',
                        approved_at: 1401807095863,
                        assignee: 'foo',
                        candidate: false,
                        comment: 'test comment',
                        required: true,
                        request_id: 0,
                        status: 'Rejected',
                        group: {
                            id: 3,
                            code: 'DRM_Global_Treasury',
                            name: 'Global Treasury',
                            role: 'APPROVER'
                        }
                    },
                    {
                        action: null,
                        approved: false,
                        approved_by: 'mcof approver',
                        approved_at: 1401807095863,
                        assignee: 'Piotr Buza',
                        candidate: false,
                        comment: null,
                        required: true,
                        request_id: 0,
                        status: 'Rejected',
                        group: {
                            id: 5,
                            code: 'DRM_MCOF',
                            name: 'MCOF-CSA-Impact Analysis',
                            role: 'APPROVER'
                        }
                    },
                    {
                        approved: true,
                        candidate: false,
                        required: true,
                        request_id: 0,
                        group: {
                            id: 8,
                            code: 'DRM_TALM',
                            name: 'TALM',
                            role: 'APPROVER'
                        },
                        status: 'Approved',
                        action: null,
                        approved_by: 'talm approver',
                        approved_at: 1401807095863,
                        comment: null,
                        assignee: 'Piotr Buza'
                    }
                ]
            }
        ]
    },

    formattedTasksAllGroups : {
        data: [
            {
                id: 1,
                client: 'test1',
                requester: 'Piotr Buza',
                requested_at: 1401807094863,
                updated_at: 1401807094863,
                type: 'AMENDMENT',
                priority: 'Medium',
                status: 'AWAITING_APPROVAL',
                clientType: 'Central Bank',
                issueType: 'Collateral Threshold, Cross-Default Threshold',
                classificationType: 'Amending ISDA',
                approvals_summary: [
                    {
                        approvalClass: 'rejected glyphicon-time',
                        approvedBy: 'foo',
                        approvedAt: 1401807095863,
                        assignedTo: 'foo',
                        code: 'GT'
                    },
                    {
                        approvalClass: 'rejected glyphicon-remove',
                        approvedBy: 'mcof approver',
                        approvedAt: 1401807095863,
                        assignedTo: 'Piotr Buza',
                        code: 'MCOF'
                    },
                    {
                        approvalClass: 'approved glyphicon-ok',
                        approvedBy: 'talm approver',
                        approvedAt: 1401807095863,
                        assignedTo: 'Piotr Buza',
                        code: 'TALM'
                    }
                ]
            }
        ]
    },

    formattedTasksTALM : {
        data: [
            {
                id: 1,
                client: 'test1',
                requester: 'Piotr Buza',
                requested_at: 1401807094863,
                updated_at: 1401807094863,
                type: 'AMENDMENT',
                priority: 'Medium',
                status: 'AWAITING_APPROVAL',
                clientType: 'Central Bank',
                issueType: 'Collateral Threshold, Cross-Default Threshold',
                classificationType: 'Amending ISDA',
                approvals_summary: [
                    {
                        approvalClass: 'approved glyphicon-ok',
                        approvedBy: 'talm approver',
                        approvedAt: 1401807095863,
                        assignedTo: 'Piotr Buza',
                        code: 'TALM'
                    }
                ]
            }
        ]
    }
});
