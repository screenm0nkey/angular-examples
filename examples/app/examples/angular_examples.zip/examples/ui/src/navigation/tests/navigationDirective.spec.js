'use strict';

describe('Navigation Directive', function () {

    var $rootScope;
    var $scope;
    var $compile;
    var $httpBackend;
    var fixtures;
    var navigation = $('<div />');

    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('drmDashboard.navigation'));
    beforeEach(module('/templates/navigation/navigation.html'));

    beforeEach(inject(function (_$rootScope_, _$compile_, _endpointsFixtures_, _$httpBackend_) {
        $rootScope = _$rootScope_;
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        fixtures = _endpointsFixtures_;
        $scope = $rootScope.$new();
    }));

    afterEach(function () {
        navigation.remove();
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    var renderDirective = function () {
        navigation = angular.element('<div navigation></div>');
        $compile(navigation)($scope);
        $('body').append(navigation);
        $rootScope.$digest();
    };
    describe('request details link', function () {
        it('should show create request link when user is authorized to use it', function () {
            /* GIVEN */
            $httpBackend.expect('GET', '/approvals').respond(fixtures.getStaticLinks);

            /* WHEN */
            renderDirective();
            $httpBackend.flush();

            /* THEN */
            var createRequestLink = navigation.find('a[href="request/amendment"]');
            expect(createRequestLink.is(':visible')).toBe(true);

        });

        it('should show create request link when user is authorized to use it', function () {
            /* GIVEN */
            var linksObject = angular.copy(fixtures.getStaticLinks);
            _.remove(linksObject.links, function (link) {
                return link.rel === 'request/create';
            });

            $httpBackend.expect('GET', '/approvals').respond(linksObject);

            /* WHEN */
            renderDirective();
            $httpBackend.flush();

            /* THEN */
            var createRequestLink = navigation.find('a[href="request/amendment"]');
            expect(createRequestLink.is(':visible')).toBe(false);
        });
    });
});
