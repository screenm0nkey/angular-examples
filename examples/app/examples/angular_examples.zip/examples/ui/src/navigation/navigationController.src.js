'use strict';

var NavigationController = function ($scope, endpoints) {
    endpoints.getStaticLinks().then(function () {
        if(endpoints.create) {
            $scope.canCreateRequest = true;
        }
    });
};

module.exports = ['$scope', 'endpoints', NavigationController];