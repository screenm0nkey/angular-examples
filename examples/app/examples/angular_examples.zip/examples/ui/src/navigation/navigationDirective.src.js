'use strict';

var NavigationDirective = function () {
    return {
        restrict: 'A',
        templateUrl: '/templates/navigation/navigation.html'
    };
};

module.exports = NavigationDirective;