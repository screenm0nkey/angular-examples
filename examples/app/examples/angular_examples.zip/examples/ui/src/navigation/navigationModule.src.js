'use strict';

var NavigationController = require('./navigationController.src.js');
var NavigationDirective = require('./navigationDirective.src.js');

angular.module('drmDashboard.navigation',[])
    .controller('NavigationCtrl', NavigationController)
    .directive('navigation', NavigationDirective);


