/*jshint maxparams:7*/
'use strict';

describe('RequestCreatorController', function() {
    var $scope;
    var $location;
    var uploadPromise;
    var RequestCreatorService;
    var schema;
    var $httpBackend;
    var fileUploadService;
    var $upload = {
        upload: function () {}
    };
    var endpoints = {
        createMetadata: 'crateMetadataUrl',
        create:'createUrl'
    };
    var fixture;

    beforeEach(module('drmDashboard.requestCreator'));
    beforeEach(module('drmDashboard.requestDetails'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module(function($provide){
        $provide.value('endpoints', endpoints);
    }));
    beforeEach(inject(function($rootScope, $controller, _$httpBackend_, _RequestDetailsService_, _RequestCreatorService_, _requestDetails_, _createRequestPostSchema_) {
        schema = _createRequestPostSchema_.enhancedSchema;

        uploadPromise = {
            then: sinon.spy()
        };

        RequestCreatorService = _RequestCreatorService_;

        fileUploadService = {
            upload: sinon.spy(function () {
                return uploadPromise;
            })
        };

        $location = {
            path: sinon.spy()
        };

        $httpBackend = _$httpBackend_;
        fixture = _requestDetails_;

        $scope = $rootScope.$new();

        $controller('RequestCreatorCtrl', {
            $scope: $scope,
            $location: $location,
            RequestCreatorService: _RequestCreatorService_,
            RequestDetailsService: _RequestDetailsService_,
            documentsService: fileUploadService,
            $upload: $upload

        });

        $httpBackend.when('GET', 'crateMetadataUrl').respond(schema);
        $httpBackend.flush();

    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('default form values', function () {
        it('should be populated', function () {
            var expectedDefaultFormData = {
                'existing_trades':'true',
                'type':'AMENDMENT',
                'priority':'Medium'
            };

            expect($scope.form).toEqual(expectedDefaultFormData);
        });

        it('should set up the createRequestSchema', function () {
            expect($scope.createRequestSchema).toEqual(schema);
        });
    });

    describe('fileUploadFinishedHandler', function () {
        it('should call location service with "reporting" path', function () {

            /* WHEN */

            $scope.fileUploadFinishedHandler();

            /* THEN */

            expect($location.path.calledWith('/reporting')).toBe(true);
        });
    });

    describe('createRequest method', function () {
        it('should call the create method of the RequestCreatorService', function () {

            /* WHEN */
            $scope.createRequest();

            /* THEN */
            $httpBackend.expect('POST', endpoints.create, $scope.form).respond(201, null,{location: 'requestLocation'});
            $httpBackend.flush();
        });

        it('should bind uploadFileOnRequestCreation method to successful resolution of the promise', function () {
            sinon.stub($scope, 'uploadFileOnRequestCreation');

            /* WHEN */
            $scope.createRequest();
            $httpBackend.expect('POST', endpoints.create, $scope.form).respond(201, null,{location: 'requestLocation'});
            $httpBackend.flush();

            /* THEN */
            expect($scope.uploadFileOnRequestCreation.called).toBe(true);
            $scope.uploadFileOnRequestCreation.restore();
        });

        it('should bind showSubmissionError method to error resolution of the promise', function () {
            /* GIVEN */
            sinon.spy($scope, 'showSubmissionError');

            /* WHEN */

            $scope.createRequest();
            $httpBackend.expect('POST', endpoints.create, $scope.form).respond(404, null,{location: 'requestLocation'});
            $httpBackend.flush();

            /* THEN */
            expect($scope.showSubmissionError.called).toBe(true);
            $scope.showSubmissionError.restore();
        });

        it('should set the createRequestFailedToFalse', function () {
            /* GIVEN */
            $scope.createRequestFailed = true;

            /* WHEN */
            $scope.createRequest();
            $httpBackend.expect('POST', endpoints.create, $scope.form).respond(200, null,{location: 'requestLocation'});
            $httpBackend.flush();

            /* THEN */
            expect($scope.createRequestFailed).toBe(false);
        });
    });

    describe('showSubmissionError method', function () {
        it('should set createRequestFailedFlag', function () {
            /* WHEN */
            $scope.showSubmissionError();

            /* THEN */

            expect($scope.createRequestFailed).toBe(true);
        });
    });

    describe('onFileSelect method', function () {
        it('should assign files to scope', function () {
            /* GIVEN */
            var selectedFiles = ['file1', 'file2'];

            /* WHEN */
            $scope.onFileSelect(selectedFiles);

            /* THEN */
            expect($scope.filesToUpload).toBe(selectedFiles);
        });
    });

    describe('uploadFileOnRequestCreation method', function () {
        it('should call fileUploadFinishedHandler if there are not files to be uploaded', function () {
            /* GIVEN */
            var dummyData = '';
            var dummyStatus = 200;
            var requestId = 1;
            var dummyLocation = 'http://drmlocal/approvals/requests/' + requestId;
            var dummyHeaders = sinon.spy(function () {
                return dummyLocation;
            });

            sinon.spy($scope, 'fileUploadFinishedHandler');

            $scope.filesToUpload = [];

            /* WHEN */
            $scope.uploadFileOnRequestCreation(dummyData, dummyStatus, dummyHeaders);

            /* THEN */
            expect($scope.fileUploadFinishedHandler.called).toBe(true);
            expect(fileUploadService.upload.called).toBe(false);

            $scope.fileUploadFinishedHandler.restore();
        });

        it('should call fileUploadService and bind proper handlers to its promise and should set the url of the task detail in local scope', function () {
            /* GIVEN */
            var dummyData = '';
            var dummyStatus = 201;
            var requestId = 1;
            var dummyLocation = 'http://localhost:10300/requests/' + requestId;
            var dummyHeaders = sinon.spy(function () {
                return dummyLocation;
            });

            $scope.filesToUpload = ['file'];

            /* WHEN */
            $scope.uploadFileOnRequestCreation(dummyData, dummyStatus, dummyHeaders);

            /* THEN */

            $httpBackend.expect('GET', dummyLocation).respond(fixture.query);

            $httpBackend.flush();

            /* AND */
            expect(fileUploadService.upload.called).toBe(true);
            var uploadArguments = fileUploadService.upload.getCall(0).args;
            expect(uploadArguments[0]).toBe(fixture.links.documentupload);
            expect(uploadArguments[1]).toBe($scope.filesToUpload);

            /* AND */
            expect(uploadPromise.then.called).toBe(true);
            var uploadPromiseArguments = uploadPromise.then.getCall(0).args;

            expect(uploadPromiseArguments[0]).toEqual($scope.fileUploadFinishedHandler);
            expect(uploadPromiseArguments[1]).toEqual($scope.fileUploadErrorHandler);

            /* AND */
            expect($scope.requestDetailsUrl).toEqual('/requestDetails/' + requestId);
        });
    });

    describe('fileUploadErrorHandler', function () {
        it('should set fileUploadFailed to false', function () {
            /* WHEN */
            $scope.fileUploadErrorHandler();

            /* THEN */
            expect($scope.fileUploadFailed).toBe(true);
        });
    });
});