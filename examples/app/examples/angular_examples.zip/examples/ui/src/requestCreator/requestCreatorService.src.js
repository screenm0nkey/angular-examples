'use strict';

var RequestCreatorService = function ($http, $q, endpoints) {
    return {
        create: function (formData) {
            var createRequestEndpoint = endpoints.create;

            if(formData.dox_id) {
                formData.dox_id = parseInt(formData.dox_id, 10);
            }
            var createOptions = {
                url: createRequestEndpoint,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: formData
            };
            var createPromise = $http(createOptions);

            return createPromise;
        },

        getMetadata: function () {
            var deferred = $q.defer();

            $http({
                url:endpoints.createMetadata,
                method: 'GET'
            }).success(function (metadata){
                //Adds required property
                for(var prop in metadata) {
                    if(metadata.hasOwnProperty(prop)){
                        if(prop === 'required' ) {
                            for(var i = 0; i < metadata.required.length; i++) {
                                var requiredPropertyName = metadata.required[i];
                                metadata.properties[requiredPropertyName].required = true;
                            }
                        }
                    }
                }
                deferred.resolve(metadata);
            });

            return deferred.promise;
        }
    };
};

module.exports = ['$http',  '$q','endpoints', RequestCreatorService];