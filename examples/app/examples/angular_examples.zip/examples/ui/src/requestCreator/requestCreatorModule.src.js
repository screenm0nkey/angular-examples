'use strict';

var RequestCreatorController = require('./requestCreatorController.src.js');
var RequestCreatorService = require('./requestCreatorService.src.js');
var RequestForm = require('./requestFormDirective.src.js');

angular.module('drmDashboard.requestCreator', [])
    .directive('drmRequestForm', RequestForm)
    .factory('RequestCreatorService', RequestCreatorService)
    .controller('RequestCreatorCtrl', RequestCreatorController);
