'use strict';

describe('Create Request Form Directive', function () {

    var $rootScope;
    var $scope;
    var $compile;
    var createRequestFormSchema;
    var formElement;
    var directiveElement;

    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('drmDashboard.requestCreator'));
    beforeEach(module('/templates/requestCreator/requestFormPartial.html'));

    beforeEach(inject(function (_$rootScope_, _$compile_, _createRequestPostSchema_) {
        $rootScope = _$rootScope_;
        $compile = _$compile_;
        createRequestFormSchema = angular.copy(_createRequestPostSchema_);
        $scope = $rootScope.$new();
    }));

    afterEach(function(){
        formElement.remove();
    });

    var renderDirective = function () {
        $scope.createRequestSchema = createRequestFormSchema.enhancedSchema;
        formElement = angular.element('<form name="testForm"><div drm-request-form></div></form>');
        $compile(formElement)($scope);
        $('body').append(formElement);
        $rootScope.$digest();
        directiveElement = formElement.find('[drm-request-form]');
    };

    describe('Region box', function () {
        it('should add a select box ', function () {
            renderDirective();
            expect(formElement.find('select[ng-model="form.region"]').length).toEqual(1);
        });

        it('should populate the options from schema', function () {
            renderDirective();
            expect(formElement.find('select[ng-model="form.region"] option').length).toEqual(createRequestFormSchema.enhancedSchema.properties['region']['enum'].length + 1);
        });

        it('should add ng-required attribute to element', function () {
            /* WHEN */
            renderDirective();
            /* THEN */
            expect(formElement.find('select[ng-required="createRequestSchema.properties[\'region\'].required"]').length).toBe(1);
            expect(formElement.hasClass('ng-invalid')).toBe(true);
        });

        it('should bind the selection value to model', function () {
            /* WHEN */
            renderDirective();

            /* THEN */
            formElement.find('select').val(1).trigger('change');
            expect($scope.testForm.region.$modelValue).toEqual(createRequestFormSchema.enhancedSchema.properties['region']['enum'][1]);
        });
    });

    describe('DOX ID region', function () {
        it('', function () {
            /* WHEN */
            renderDirective();

            /* THEN */
            expect(formElement.find('input[ng-model="form.dox_id"]').length).toEqual(1);
        });
    });
});