angular.module('drmDashboard.fixtures').value('createRequestPostSchema', {
        schema: {
            'type': 'object',
            'properties': {
                'region': {
                    'type': 'string',
                    'enum': [ 'US', 'EMEA', 'APAC']
                },
                'dox_id': {
                    'type': 'number'
                }
            },
            'required': ['region'],
            'additionalProperties': false
        },
        enhancedSchema: {
            'type': 'object',
            'properties': {
                'region': {
                    'type': 'string',
                    'enum': [ 'US', 'EMEA', 'APAC'],
                    'required': true
                },
                'dox_id': {
                    'type': 'number'
                }
            },
            'required': ['region'],
            'additionalProperties': false
        }
    }
);
