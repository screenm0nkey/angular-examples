/*jshint maxparams:6*/

'use strict';


var RequestCreatorController = function ($scope, $location,  RequestCreatorService, documentsService, RequestDetailsService) {
    var initializeFormWithDefaultData = function () {
        $scope.form = {
            'existing_trades':'true',
            'type':'AMENDMENT',
            'priority':'Medium'
        };
    };

    var getSchema = function () {
        RequestCreatorService.getMetadata().then(function (schema) {
            $scope.createRequestSchema = schema;
        });
    };

    var handleRequestFormSubmition = function () {
        $scope.createRequest = function () {
            $scope.createRequestFailed = false;

            var createPromise = RequestCreatorService.create($scope.form);
            createPromise.success($scope.uploadFileOnRequestCreation);
            createPromise.error($scope.showSubmissionError);
        };
    };

    var handleRequestCreationSuccess = function () {
        $scope.uploadFileOnRequestCreation = function (data, status, headers) {
            var requestEndpoint = headers(['location']);

            if ($scope.filesToUpload && $scope.filesToUpload.length > 0) {
                RequestDetailsService.get(requestEndpoint).then(function(requestDetails){
                    $scope.requestDetailsUrl = '/requestDetails/' + requestDetails.entity.id;
                    var uploadPromise = documentsService.upload(requestDetails.links.documentupload, $scope.filesToUpload);
                    uploadPromise.then($scope.fileUploadFinishedHandler, $scope.fileUploadErrorHandler);
                });
            } else {
                $scope.fileUploadFinishedHandler();
            }
        };
    };

    var handleFileSelection = function () {
        $scope.onFileSelect = function (selectedFiles) {
            $scope.filesToUpload = selectedFiles;
        };
    };

    var handleRequestCompletionSuccess = function () {
        $scope.fileUploadFinishedHandler = function () {
            $location.path('/reporting');
        };
    };

    var handleFileUploadError = function () {
        $scope.fileUploadFailed = false;
        $scope.fileUploadErrorHandler = function () {
            $scope.fileUploadFailed = true;
        };
    };

    var handleRequestCreationFailure = function () {
        $scope.createRequestFailed = false;
        $scope.showSubmissionError = function () {
            $scope.createRequestFailed = true;
        };
    };


    initializeFormWithDefaultData();
    getSchema();
    handleRequestFormSubmition();
    handleRequestCreationSuccess();
    handleRequestCreationFailure();
    handleFileSelection();
    handleFileUploadError();
    handleRequestCompletionSuccess();
};

module.exports = ['$scope', '$location', 'RequestCreatorService', 'documentsService', 'RequestDetailsService', RequestCreatorController];