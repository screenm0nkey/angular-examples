'use strict';

var DrmRequestFormDirective = function () {
    return {
        restrict: 'A',
        replace : true,
        scope : true,
        templateUrl: '/templates/requestCreator/requestFormPartial.html'
    };
};

module.exports = [DrmRequestFormDirective];