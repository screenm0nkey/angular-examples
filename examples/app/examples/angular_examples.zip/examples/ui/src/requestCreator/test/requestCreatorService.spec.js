'use strict';

describe('RequestCreatorService', function () {
    var httpSpy;
    var $httpBackend;
    var promise;
    var endpoints = {
        create: 'createUrl',
        createMetadata: 'createMetadataUrl'
    };
    var createRequestFormSchema;
    var requestCreatorService;

    beforeEach(function () {
        promise = {};
        httpSpy = sinon.spy(function () {
            return promise;
        });
        module(function ($provide) {
            $provide.value('endpoints', endpoints);
        });

        module('drmDashboard.requestCreator');
        module('drmDashboard.fixtures');
        inject(function (_RequestCreatorService_, _$httpBackend_, _createRequestPostSchema_) {
            requestCreatorService = _RequestCreatorService_;
            createRequestFormSchema = _createRequestPostSchema_;
            $httpBackend = _$httpBackend_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('create method', function () {
        it('should call $http post method with proper data', function () {
            /* GIVEN */
            var formData = {
                foo:'bar',
                dox_id: '0098790'
            };

            var dataToBeSent = {
                foo:'bar',
                dox_id: 98790
            };

            /* WHEN */
            var createPromise = requestCreatorService.create(formData);

            /* THEN */
            $httpBackend.expect('POST', endpoints.create, dataToBeSent).respond(201);
            $httpBackend.flush();

            createPromise.then(function (resp) {
                expect(resp.status).toEqual(201);
            });
        });
    });

    describe('getMetadata', function () {
        it('should use http to get metadata from proper capability link', function () {
            /* WHEN */
            var schemaPromise = requestCreatorService.getMetadata();

            /* THEN */
            $httpBackend.expect('GET', endpoints.createMetadata).respond(createRequestFormSchema.schema);
            $httpBackend.flush();

            schemaPromise.then(function (resp) {
                expect(resp).toEqual(createRequestFormSchema.enhancedSchema);
            });
        });
    });
});