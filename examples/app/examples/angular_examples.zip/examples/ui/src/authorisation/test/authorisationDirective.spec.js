'use strict';

describe('Authorisation Show directive', function () {
    var $scope;
    var $compile;
    var $provide;

    var isAllowed;
    var authorisationService;

    beforeEach(module('drmDashboard.authorisation'));

    beforeEach(module(function (_$provide_) {
        $provide = _$provide_;
    }));

    beforeEach(inject(function (_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    beforeEach(function () {
        authorisationService = {
            isMemberOfAsync: sinon.spy(function () {
                return {
                    then : function (callback){
                        callback(isAllowed);
                    }
                };
            })
        };
    });

    xit('should add a hidden class if authorisation service returns false', function () {
        isAllowed = false;
        $provide.value('authorisationService', authorisationService);

        /*WHEN*/
        var element = angular.element('<div drm-show="DRM_Collaborator,DRM_Credit_Risk_Control,DRM_Global_Treasury">foo</div>');
        $compile(element)($scope);

        /*THEN*/
        expect($(element).hasClass('hidden')).toBeTruthy();
    });

    xit('should remove hidden class if authorisation service returns true', function () {
        isAllowed = true;
        $provide.value('authorisationService', authorisationService);
        var element = angular.element('<div drm-show="DRM_Legal,DRM_LegalDRM_Legal">foo</div>');
        $compile(element)($scope);
        expect($(element).hasClass('hidden')).toBeFalsy();
    });

    describe('attributes', function () {
        xit('should be split into an array using a ","', function () {
            /* GIVEN */
            isAllowed = true;
            $provide.value('authorisationService', authorisationService);
            var element = angular.element('<div drm-show="DRM_Legal,DRM_Legal,DRM_Legal">foo</div>');

            /* WHEN */
            $compile(element)($scope);

            /* THEN */
            var isMemberOfArguments = authorisationService.isMemberOfAsync.getCall(0).args;
            expect(isMemberOfArguments[0]).toEqual(['DRM_Legal','DRM_Legal','DRM_Legal']);
        });

        xit('2nd test should be split into an array using a ","', function () {
            /* GIVEN */
            isAllowed = true;
            $provide.value('authorisationService', authorisationService);
            var element = angular.element('<div drm-show>foo</div>');

            /* WHEN */
            $compile(element)($scope);

            /* THEN */
            var isMemberOfArguments = authorisationService.isMemberOfAsync.getCall(0).args;
            expect(isMemberOfArguments[0]).toEqual(['']);
        });
    });
});