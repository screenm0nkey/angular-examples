'use strict';

var DrmShowDirective = function (authorisationService) {
    return {
        restrict: 'A',
        compile : function(tElement) {
            $(tElement).addClass('hidden');

            return function link (scope, element, attributes) {
                // convert attributes to array
                var isMemberOfArguments = attributes.drmShow.split(',');

                if (authorisationService.isMemberOf(isMemberOfArguments)) {
                    $(element).removeClass('hidden');
                }
            };
        }
    };
};

module.exports = ['authorisationService', DrmShowDirective];
