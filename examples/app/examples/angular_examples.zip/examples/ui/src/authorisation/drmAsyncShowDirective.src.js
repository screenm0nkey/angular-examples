'use strict';
/*
 drmAsyncShowDirective is the same as the drmShowDirective but it uses a promise to wait for the SSOUser
 to resolve before it shows/hides elements. This directive is currently only used by the navigation as the
 nav sits outside of <ng-view>. All content inside of <ng-view> won't load until the SSOUser is available.
*/
var drmAsyncShowDirective = function (authorisationService) {
    return {
        restrict: 'A',
        compile : function(tElement) {
            $(tElement).addClass('hidden');

            return function link (scope, element, attributes) {
                // convert attributes to array
                var isMemberOfArguments = attributes.drmAsyncShow.split(',');

                authorisationService.isMemberOfAsync(isMemberOfArguments).then(function(show){
                    if (show) {
                        $(element).removeClass('hidden');
                    }
                });
            };
        }
    };
};

module.exports = ['authorisationService', drmAsyncShowDirective];
