'use strict';

// Examples of argument values:
// sessionObj.roles = ['DRM_Collaborator', 'DRM_Legal']
// groupIdArray = ['DRM_Collaborator'];



var approverGroups = [
    'DRM_Global_Treasury',
    'DRM_MCOF',
    'DRM_TALM'
];

var AuthorisationService = function ($http, $q, endpoints) {
    var SSOUser;

    var setSSOUser = function(srcObj) {
        SSOUser = SSOUser || {};
        angular.extend(SSOUser, srcObj);
    };

    // Gets called by every route in the app.js
    var ssoDeferred = $q.defer();
    var getSSOUser = function() {
        if (!SSOUser) {
            $http({
                url: endpoints.session,
                method: 'GET'
            }).success(function (session) {
                var role = _.find(session.roles, function (role) {
                    return role.indexOf('DRM_') >= 0;
                });
                setSSOUser({
                    group: role.replace('DRM_', ''),
                    isApprover: approverGroups.indexOf(role) !== -1,
                    isRequestor: approverGroups.indexOf(role) === -1
                });

                // add the SSO user to the app as a service so it can be injected
                angular.module('drmDashboard').$provide.value('SSOUser', SSOUser);
                ssoDeferred.resolve(SSOUser);
            });
        }

        return ssoDeferred.promise;
    };


    var isMemberOf = function (groupIdArray) {
        var hasRole = false;
        var name = 'DRM_' + SSOUser.group;

        for (var i = 0, len = groupIdArray.length; i < len; i++) {
            if (name === groupIdArray[i]) {
                hasRole = true;
                break;
            }
        }
        return hasRole;
    };

    // isMemberOfAsync() is currently only used by the drmAsyncShow Directive. it's here
    // because the nav depends on the auth service to display menu items. the problem is
    // the nav sits outside of the <ng-app> directive so it circumnavigates the logic in
    // router in app.js, which does all the checking for the SSO user and static links.
    var isMemberOfAsync = function (groupIdArray) {
        var deferred = $q.defer();

        endpoints.getStaticLinks().then(function () {
            getSSOUser().then(function(){
                deferred.resolve(isMemberOf(groupIdArray));
            });
        });

        return deferred.promise;
    };

    return {
        getSSOUser : getSSOUser,
        setSSOUser : setSSOUser,
        isMemberOf : isMemberOf,
        isMemberOfAsync : isMemberOfAsync
    };
};


module.exports = ['$http', '$q', 'endpoints', AuthorisationService];
