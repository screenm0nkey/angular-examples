'use strict';

var AuthorisationService = require('./authorisationService.src.js');
var drmShowDirective = require('./drmShowDirective.src.js');
var drmAsyncShowDirective = require('./drmAsyncShowDirective.src.js');

angular.module('drmDashboard.authorisation', [])
    .factory('authorisationService', AuthorisationService)
    .directive('drmShow', drmShowDirective)
    .directive('drmAsyncShow', drmAsyncShowDirective);
