'use strict';

describe('Authorisation Service', function () {
    var authorisationService;
    var $httpBackend;
    var $injector;
    var endpoints;
    var endpointsFixtures;

    beforeEach( function () {
        module('drmDashboard');
        module('drmDashboard.fixtures');
        module('drmDashboard.authorisation');
        module('drmDashboard.sharedComponents');

        inject(function (_authorisationService_, _$httpBackend_, _$injector_, _endpoints_, _endpointsFixtures_) {
            authorisationService = _authorisationService_;
            $httpBackend = _$httpBackend_;
            $injector =_$injector_;
            endpoints = _endpoints_;
            endpointsFixtures = _endpointsFixtures_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });


    describe('getSSOUser() method', function () {
        it('should return a promise which resolves to a formatted object with a group property', function () {
            var sessionEndpointResponse = { roles: ['DRM_Collaborator'] };
            var hasRolePromise = authorisationService.getSSOUser();

            $httpBackend.when('GET', endpoints.session).respond(sessionEndpointResponse);
            hasRolePromise.then(function(SSOUser){
                expect(SSOUser).toBeTruthy();
                expect(SSOUser.group).toEqual('Collaborator');
                expect(typeof SSOUser.isApprover).toEqual('boolean');
                expect(typeof SSOUser.isApprover).toEqual('boolean');
            });
            $httpBackend.flush();
        });

        it('should set the SSOUser as an injectable service', function () {
            var sessionEndpointResponse = { roles: ['DRM_Collaborator'] };
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond(sessionEndpointResponse);
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');
            expect(SSOUser).toEqual({ group : 'Collaborator', isApprover : false, isRequestor : true });
        });

        it('should set DRM_MCOF, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_MCOF'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('MCOF');
            expect(SSOUser.isApprover).toEqual(true);
            expect(SSOUser.isRequestor).toEqual(false);
        });

        it('should set DRM_Global_Treasury, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_Global_Treasury'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Global_Treasury');
            expect(SSOUser.isApprover).toEqual(true);
            expect(SSOUser.isRequestor).toEqual(false);
        });

        it('should set DRM_TALM, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_TALM'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('TALM');
            expect(SSOUser.isApprover).toEqual(true);
            expect(SSOUser.isRequestor).toEqual(false);
        });

        it('should set DRM_Sales, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_Sales'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Sales');
            expect(SSOUser.isApprover).toEqual(false);
            expect(SSOUser.isRequestor).toEqual(true);
        });

        it('should set DRM_Collaborator, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_Collaborator'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Collaborator');
            expect(SSOUser.isApprover).toEqual(false);
            expect(SSOUser.isRequestor).toEqual(true);
        });

        it('should set DRM_Credit_Risk_Control, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_Credit_Risk_Control'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Credit_Risk_Control');
            expect(SSOUser.isApprover).toEqual(false);
            expect(SSOUser.isRequestor).toEqual(true);
        });

        it('should set DRM_Legal, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();
            $httpBackend.when('GET', endpoints.session).respond({roles:['AccessControlView','DRM_Legal','LED-Collateral Offshore Admin','LED-CreateStandaloneSchedule','LED-Legal Onshore Admin','LED_Website','MAT_AccessControlView','MAT_ViewOnlyUser','ViewOnlyUser'],firstname:'Victoria'});
            $httpBackend.flush();

            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Legal');
            expect(SSOUser.isApprover).toEqual(false);
            expect(SSOUser.isRequestor).toEqual(true);
        });

        it('should set DRM_Onboarding, to correct approver/requester groups', function () {
            authorisationService.getSSOUser();

            $httpBackend.when('GET', endpoints.session).respond({ roles: ['DRM_Onboarding'] });
            $httpBackend.flush();
            var SSOUser = $injector.get('SSOUser');

            expect(SSOUser.group).toEqual('Onboarding');
            expect(SSOUser.isApprover).toEqual(false);
            expect(SSOUser.isRequestor).toEqual(true);
        });
    });


    describe('isMemberOf() method', function () {
        it('should return true if user has right role', function () {
            authorisationService.setSSOUser({group:'Global_Treasury'});
            var hasRole = authorisationService.isMemberOf(['DRM_Credit_Risk_Control','DRM_Global_Treasury','DRM_Onboarding']);
            expect(hasRole).toBeTruthy();
        });

        it('should return false if user has not right role', function () {
            authorisationService.setSSOUser({group:'Sales'});
            var hasRole = authorisationService.isMemberOf(['DRM_Credit_Risk_Control','DRM_Global_Treasury','DRM_Onboarding']);
            expect(hasRole).toBeFalsy();
        });

        it('should return false if false if there is degenerate empty argument for the isMemberOf', function () {
            authorisationService.setSSOUser({group:'Sales'});
            var hasRole = authorisationService.isMemberOf(['']);
            expect(hasRole).toBeFalsy();
        });

        it('should return false if false if there is degenerate argument for the isMemberOf', function () {
            authorisationService.setSSOUser({group:'Sales'});
            var hasRole = authorisationService.isMemberOf(['foo', '10', 10]);
            expect(hasRole).toBeFalsy();
        });
    });

    describe('isMemberOfAsync() method', function () {
        it('should call approvals first to get static link and then call session endpoint', function () {
            var promise = authorisationService.isMemberOfAsync(['DRM_TALM']);
            $httpBackend.when('GET', '/approvals').respond(200, endpointsFixtures.getStaticLinks);
            $httpBackend.when('GET', '/session').respond(200, {roles:['DRM_TALM']});

            promise.then(function (isMemberOf) {
                expect(isMemberOf).toBeTruthy();
            });

            $httpBackend.flush();
        });

        it('should call approvals first to get static link and then call session endpoint', function () {
            var promise = authorisationService.isMemberOfAsync(['DRM_MCOF']);
            $httpBackend.when('GET', '/approvals').respond(200, endpointsFixtures.getStaticLinks);
            $httpBackend.when('GET', '/session').respond(200, {roles:['DRM_TALM']});

            promise.then(function (isMemberOf) {
                expect(isMemberOf).toBeFalsy();
            });

            $httpBackend.flush();
        });
    });
});