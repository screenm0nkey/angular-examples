/*global xit:true*/
'use strict';

describe('PanelZippyDirective', function () {
    var element;
    var scope;

    beforeEach(module('drmDashboard.sharedComponents'));

    beforeEach(inject(function ($rootScope, $compile) {
        element = angular.element('<div drm-panel-zippy>foo</div>');

        scope = $rootScope;

        $compile(element)(scope);
        scope.$digest();
    }));

    xit('should toggle class "drm-panel-zippy__active" to zippy on click', function () {
        /* WHEN */

        element[0].click();
        expect(element.hasClass('drm-panel-zippy__active')).toBe(true);

        element[0].click();
        expect(element.hasClass('drm-panel-zippy__active')).toBe(false);
    });

    it('should add class "drm-panel-zippy" to zippy', function () {

        /* WHEN */

        expect(element.hasClass('drm-panel-zippy')).toBe(true);
        expect(element.hasClass('drm-panel-zippy__active')).toBe(false);
    });

    describe('with attribute active', function () {
        beforeEach(inject(function ($rootScope, $compile) {
            element = angular.element('<div drm-panel-zippy="open">foo</div>');

            scope = $rootScope;

            $compile(element)(scope);
            scope.$digest();
        }));

        it('should add active class', function () {
            /* GIVEN */


            /* WHEN */


            /* THEN */
            expect(element.hasClass('drm-panel-zippy__active')).toBe(true);

        });
    });


});