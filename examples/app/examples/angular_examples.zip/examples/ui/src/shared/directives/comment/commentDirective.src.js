'use strict';

var CommentDirective = function (UserService, filterFilter) {
    return {
        restrict: 'A',
        replace : true,
        templateUrl: '/templates/shared/directives/comment/comment.html',

        controller : ['$scope', '$window', '$element', function($scope, $window, $element) {
            var $input = $element.find('input');
            var $menu = $element.find('ul');
            var unfilteredList;
            var watcher;
            var emailList;
            var beforeSearchStr = '';
            var afterSearchStr = '';
            var ARROWKEYUP = 38;
            var ARROWKEYDOWN = 40;
            var ENTERKEY = 13;
            var ESCKEY = 27;

            $scope.filteredList = [];

            UserService.query().then(function (resp) {
                unfilteredList = _.map(resp, function (item) {
                    item.email = item.email.replace('@ubs.com', '');
                    return item;
                });
                emailList = _.map(unfilteredList, function(item) {
                    return item.email;
                });
            });


            // clean up watchers and event bindings when scope is destroyed
            $scope.$on('$destroy', function() {
                $($window.document).off('.drm.comment.directive');

                if(_.isFunction(watcher)) {
                    watcher();
                }
            });


            // hide context menu if a click occurs outside of the comment directive
            $($window.document).on('click.drm.comment.directive', function hideContextMenu (evt) {
                var clickOutsideComment = !$(evt.target).closest('.drm-targeted-comment')[0];

                if ($menu.is(':visible') && clickOutsideComment) {
                    $scope.searchString = null;
                    $scope.$digest();
                }
            });


            // validate all matches found in comment against the user email list and
            // return false if there are regex matches which don't have a valid user
            // email mapped to it i.e.
            // the match '@som' in the comment will validate as '@some.user' from
            // an email address match of some.user@ubs.com
            var commentIsValid = function(str){
                // This regex should find all the instances of strings starting
                // with @ symbol which are at least one character long
                var regex = /@([^\s][^\s]*)(\s|$)/g;
                var match = regex.exec(str);

                while (match) {
                    if(_.indexOf(emailList, match[1]) < 0) {
                        $scope.invalidUser = match[1];
                        return false;
                    }
                    match = regex.exec(str);
                }
                $scope.invalidUser = null;
                return true;
            };


            // set the comment input as invalid if there is an invalid user match in the comment
            watcher = $scope.$watch('comment', function (newVal, oldVal) {
                if($input) {
                    var ngModelCtrl = angular.element($input.eq(0)).controller('ngModel');

                    if(newVal && newVal !== oldVal) {
                        if(commentIsValid(newVal)) {
                            ngModelCtrl.$setValidity('comment', true);
                        } else {
                            ngModelCtrl.$setValidity('comment', false);
                        }
                    }

                    if(!newVal) {
                        ngModelCtrl.$setValidity('comment', true);
                        $scope.invalidUser = null;
                    }
                }
            });


            $scope.focusOnMenu = function (evt) {
                if (evt.keyCode === ARROWKEYDOWN) {
                    evt.preventDefault();
                    evt.stopPropagation();
                    //This is to negate issues with digest loop when we listen on blur
                    setTimeout(function () {
                        $(evt.target).siblings('ul').find('li:first a').focus();
                    }, 10);
                }
            };


            $scope.startSearch = function (evt) {
                evt.preventDefault();

                if (evt.keyCode === ESCKEY) {
                    $scope.searchString = null;
                    return;
                }

                var comment = $input.val();
                var lastIndexOfAt = comment.lastIndexOf('@', doGetCaretPosition(evt.target)-1);
                var lastIndexOfSpace = comment.lastIndexOf(' ', doGetCaretPosition(evt.target)-1);
                var searchString;

                if(lastIndexOfAt >= 0 && lastIndexOfSpace < lastIndexOfAt) {
                    beforeSearchStr = comment.slice(0, lastIndexOfAt+1);
                    searchString  = comment.slice(lastIndexOfAt + 1);
                    var indexOfSpaceInSearchString = searchString.indexOf(' ');

                    if (indexOfSpaceInSearchString < 0) {
                        indexOfSpaceInSearchString = searchString.length;
                    }

                    afterSearchStr = searchString.slice(indexOfSpaceInSearchString) || ' ';
                    searchString = searchString.slice(0, indexOfSpaceInSearchString);
                    $scope.searchString = searchString;

                    if(searchString) {
                        $scope.showWarning = null;
                    }
                } else {
                    $scope.searchString = null;
                }

                $scope.showAlert();
                $scope.filteredList = filterFilter(unfilteredList, searchString);
            };


            $scope.selectItem = function (evt, item) {
                evt.preventDefault();
                var augmentedComment = beforeSearchStr + item.email + afterSearchStr;
                $scope.comment = augmentedComment;
                $input.focus();
                $scope.searchString = null;
            };


            function doGetCaretPosition (element) {
                var iCaretPos = 0;
                // IE Support
                if (document.selection) {
                    element.focus ();
                // To get cursor position, get empty selection range
                    var oSel = document.selection.createRange ();
                // Move selection start to 0 position
                    oSel.moveStart ('character', -element.value.length);
                // The caret position is selection length
                    iCaretPos = oSel.text.length;
                }
                // Firefox and chrome support
                else if (element.selectionStart || element.selectionStart === '0') {
                    iCaretPos = element.selectionStart;
                }

                return (iCaretPos);
            }


            $scope.navigateMenu = function (evt) {
                evt.preventDefault();
                evt.stopPropagation();

                var $list = $(evt.target).closest('ul');
                var $firstItemLink = $list.find('li:eq(0) a');
                var $lastItemLink = $list.find('li:last-child').prev().find('a');

                if (evt.keyCode === ARROWKEYDOWN) {
                    var $nextLiLink = $(evt.target).closest('li').next('li').find('a');

                    if ($nextLiLink[0]) {
                        $nextLiLink.focus();
                    } else {
                        $firstItemLink.focus();
                    }
                } else if (evt.keyCode === ARROWKEYUP) {
                    var $prevLiLink = $(evt.target).closest('li').prev('li').find('a');

                    if($prevLiLink[0]) {
                        $prevLiLink.focus();
                    } else {
                        $lastItemLink.focus();
                    }
                } else if (evt.keyCode === ENTERKEY) {
                    // we use a timeout to stop digest issues as the digest is already
                    // in progress after click action
                    setTimeout(function () {
                        $(evt.target).trigger('click');
                    }, 0);
                } else if (evt.keyCode === ESCKEY) {
                    $scope.searchString = null;
                }
            };


            var timeoutId;
            $scope.showAlert = function () {
                clearTimeout(timeoutId);
                setTimeout(function() {
                    $scope.showWarning = !$scope.searchString && $scope.invalidUser;
                    $scope.$digest();
                },100);
            };
        }]
    };
};

module.exports = ['UserService', 'filterFilter', CommentDirective];