angular.module('drmDashboard.fixtures').value('endpointsFixtures', {
    getStaticLinks : {
        links : [
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/testsection1',
                'url':'/someurl/1'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/testsection2',
                'url':'/someurl/2'
            },
            {
                'media_type':'application/vnd.drm.approvals+json',
                'rel':'request/getStaticLinks',
                'url':'/someurl/3'
            },
            {
                'mediaType' : 'application/vnd.drm.approvals+json',
                'rel': 'request/create',
                'url': '/approvals/requests/create',
                'metadata': {
                    'url': '/approvals/requests/metadata'
                }
            }
        ]
    }
});