'use strict';

describe('Feature switch service', function () {
    var featureSwitch;

    beforeEach( function () {
        module('drmDashboard.sharedComponents');
    });

    var setFeatureSwitchOnEnvironment = function (environment, featureID, value) {
        featureSwitch.features[environment] = {};
        featureSwitch.features[environment][featureID] = value;
    };

    ['drm.swissbank.com', 'q-drm.swissbank.com', 's-drm.swissbank.com'].forEach(function (host) {
        describe('on '+ host + ' environment', function () {
            var featureId = 'DummyIdentifier';
            beforeEach(module(function ($provide) {
                $provide.value('$location', {
                    host: function () {
                        return host;
                    }
                });
            }));

            beforeEach(function () {
                inject(function (_featureSwitch_) {
                    featureSwitch = _featureSwitch_;
                });
            });

            describe('featureEnabled method', function () {
                it('should return false if a feature is not among listed features as default behaviour', function () {
                    setFeatureSwitchOnEnvironment(host,featureId);
                    expect(featureSwitch.featureEnabled()).toBe(false);
                    expect(featureSwitch.featureEnabled(featureId)).toBe(false);
                });

                it('should return true if a feature is among listed features for ' + host + ' environment and is set to enabled', function () {
                    setFeatureSwitchOnEnvironment(host,featureId, 'enabled');
                    expect(featureSwitch.featureEnabled(featureId)).toBe(true);
                });

                it('should return false if a feature is among listed features for ' + host + ' environment and is not set to enabled', function () {
                    setFeatureSwitchOnEnvironment(host,featureId, 'anythingButEnabled');
                    expect(featureSwitch.featureEnabled(featureId)).toBe(false);
                });
            });
        });
    });

    ['drmlocal', 'd-drm.swissbank.com'].forEach(function (host) {
        describe('on '+ host + ' environment', function () {
            var featureId = 'DummyIdentifier';
            beforeEach(module(function ($provide) {
                $provide.value('$location', {
                    host: function () {
                        return host;
                    }
                });
            }));

            beforeEach(function () {
                inject(function (_featureSwitch_) {
                    featureSwitch = _featureSwitch_;
                });
            });

            describe('featureEnabled method', function () {
                it('should return false if a feature is not among listed features as default behaviour', function () {
                    setFeatureSwitchOnEnvironment(host,featureId);
                    expect(featureSwitch.featureEnabled()).toBe(true);
                    expect(featureSwitch.featureEnabled(featureId)).toBe(true);
                });

                it('should return false if a feature is among listed features for ' + host + ' environment and is set to disabled', function () {
                    setFeatureSwitchOnEnvironment(host,featureId, 'disabled');
                    expect(featureSwitch.featureEnabled(featureId)).toBe(false);
                });

                it('should return false if a feature is among listed features for ' + host + ' environment and is not set to enabled', function () {
                    setFeatureSwitchOnEnvironment(host,featureId, 'anythingButDisabled');
                    expect(featureSwitch.featureEnabled(featureId)).toBe(true);
                });
            });
        });
    });
});