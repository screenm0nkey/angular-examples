'use strict';

var CustomDate = function ($filter) {
    var standardDateFilterFn = $filter('date');
    return function(dateToFormat){
        return standardDateFilterFn(dateToFormat, 'yyyy/MM/dd HH:mm:ss');
    };
};

module.exports = ['$filter', CustomDate];