'use strict';

describe('StatusClassService', function () {
    var statusClassService;

    beforeEach( function () {
        module('drmDashboard.sharedComponents');

        inject(function (_statusClassService_) {
            statusClassService = _statusClassService_;
        });
    });

    describe('getApprovalIconClass method', function () {
        it('should return appropriate icon class depending on approval status and requester', function () {
            /* GIVEN */

            var testCases = [
                {
                    input: {
                        approval: {
                            status: 'Approved',
                            assignee: 'foo'
                        },
                        requester: 'foo'
                    },
                    expectedResult: 'glyphicon-ok'
                },
                {
                    input: {
                        approval: {
                            status: 'Rejected',
                            assignee: 'foo'
                        },
                        requester: 'foo'
                    },
                    expectedResult: 'glyphicon-remove'
                },
                {
                    input: {
                        approval: {
                            status: null,
                            assignee: 'foo'
                        },
                        requester: 'foo'
                    },
                    expectedResult: ''
                },
                {
                    input: {
                        approval: {
                            status: 'Awaiting Approval',
                            assignee: ''
                        },
                        requester: 'foo'
                    },
                    expectedResult: 'glyphicon-time'
                },
                {
                    input: {
                        approval: {
                            status: 'Rejected',
                            assignee: 'foo'
                        },
                        requester: 'bar'
                    },
                    expectedResult: 'glyphicon-time'
                },
                {
                    input: {
                        approval: {
                            status: 'Reviewed - Not Required',
                            assignee: 'foo'
                        },
                        requester: 'bar'
                    },
                    expectedResult: 'glyphicon-ok'
                }
            ];


            testCases.forEach(function (testCase) {
                /* WHEN */
                var cssClass = statusClassService.getApprovalIconClass(testCase.input.approval, testCase.input.requester);

                /* THEN */
                expect(cssClass).toBe(testCase.expectedResult);
            });
        });
    });

    describe('Get color class', function () {
        it('should return appropriate color class', function () {
            /* GIVEN */

            var testCases = [
                {
                    input: {
                        approval: {
                            status: 'Approved'
                        }
                    },
                    expectedClass: 'approved'
                },
                {
                    input: {
                        approval: {
                            status: 'Rejected'
                        }
                    },
                    expectedClass: 'rejected'
                },
                {
                    input: {
                        approval: {
                            status: 'Reviewed - Not Required'
                        }
                    },
                    expectedClass: 'not-required'
                }
            ];

            testCases.forEach(function (testCase) {
                /* WHEN */
                var approvalColorClass = statusClassService.getApprovalColorClass(testCase.input.approval.status);

                /* THEN */

                expect(approvalColorClass).toBe(testCase.expectedClass);
            });
        });
    });

    describe('getIconAndColorClasses', function () {
        it('should call getApprovalColorClass and getApproavlIconClass methods', function () {
            /* GIVEN */

            var approval = {
                status: 'status'
            };
            var reporter = 'reporter';

            sinon.stub(statusClassService, 'getApprovalColorClass', function () {return 'color';});
            sinon.stub(statusClassService, 'getApprovalIconClass', function () {return 'icon';});

            /* WHEN */

            var statusClass = statusClassService.getIconAndColorClasses(approval, reporter);

            /* THEN */

            expect(statusClassService.getApprovalColorClass.calledWith(approval.status)).toBe(true);
            expect(statusClassService.getApprovalIconClass.calledWith(approval, reporter)).toBe(true);

            expect(statusClass).toBe('color icon');

            statusClassService.getApprovalColorClass.restore();
            statusClassService.getApprovalIconClass.restore();
        });
    });
});