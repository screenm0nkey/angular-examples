'use strict';

describe('filter', function () {

    beforeEach(module('drmDashboard.sharedComponents'));

    it('should format the date in YYYY/MM/dd HH:mm:ss', inject(function (customDateFilter) {
        var inputTime = 1399394587234;

        expect(customDateFilter(inputTime)).toEqual('2014/05/06 17:43:07');
    }));
});