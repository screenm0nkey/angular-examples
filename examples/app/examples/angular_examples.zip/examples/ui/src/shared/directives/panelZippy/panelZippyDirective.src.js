'use strict';

var PanelZippy = function () {
    return {
        restrict: 'A',
        link: function(scope, element, attributes) {
            if(attributes.drmPanelZippy && attributes.drmPanelZippy === 'open') {
                element.addClass('drm-panel-zippy__active');
            }

            element.addClass('drm-panel-zippy');
            element.on('click', function () {
                element.toggleClass('drm-panel-zippy__active');
            });
        }
    };
};

module.exports = PanelZippy;