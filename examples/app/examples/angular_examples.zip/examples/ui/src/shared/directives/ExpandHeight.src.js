'use strict';

var DrmExpandHeightDirective = function ($window) {
    var defaults = {
        height     : 300, // height of the element after animate (px)
        time       : 300, // time it takes to expand (ms)
        openDelay  : 300, // delay before the animate starts.
        closeDelay : 1500 // delay after mouse off element that the element height is reset
    };

    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var editable = attrs.editable === 'true';
            var hasScroll = function(){
                if (editable) {
                    // we always want to expand if the element is editable.
                    return true;
                }
                // expand if the content is longer than the element height.
                return element[0].scrollHeight > element[0].clientHeight;
            };

            var timeoutMouseInId=0 ,
                timeoutMouseOutId=0,
                timeoutTypingId=0,
                mouseOut = true,
                typing = false,
                height = (!!attrs.drmExpandHeight ? attrs.drmExpandHeight : defaults.height) + 'px';

            $(element).keyup(function () {
                typing = true;
                $window.clearTimeout(timeoutTypingId);
                timeoutTypingId = setTimeout(function () {
                    typing = false;
                    if (mouseOut) {
                        $(element)
                            .blur()
                            .stop(true, true)
                            .removeAttr('style');
                    }
                }, 5000);
            });

            $( element ).hover(function() {
                mouseOut = false;
                $window.clearTimeout(timeoutMouseOutId);
                if (hasScroll()) {
                    timeoutMouseInId = $window.setTimeout(function(){
                        $(element)
                            .focus()
                            .stop( true, true )
                            .animate({height: height }, defaults.time);
                    }, defaults.openDelay);
                }
            }, function() {
                mouseOut = true;
                $window.clearTimeout(timeoutMouseInId);
                if (hasScroll()) {
                    timeoutMouseOutId = $window.setTimeout(function () {
                        if (!typing) {
                            $(element)
                                .blur()
                                .stop(true, true)
                                .removeAttr('style');
                        }

                    }, defaults.closeDelay);
                }
            });
        }
    };
};

module.exports = ['$window', DrmExpandHeightDirective];