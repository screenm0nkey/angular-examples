'use strict';

var PathExtractor = require('./services/pathExtractorService.src.js');
var CustomDate = require('./filters/customDate.src.js');
var DrmPanelZippy = require('./directives/panelZippy/panelZippyDirective.src.js');
var DrmExpandHeightDirective = require('./directives/ExpandHeight.src.js');
var CommentDirective = require('./directives/comment/commentDirective.src.js');
var StatusClassService = require('./services/statusClassService.src.js');
var EndpointService = require('./services/endpointsService.src.js');
var FeatuerSwitchService = require('./services/featureSwitchService.src.js');

angular.module('drmDashboard.sharedComponents', [])
    .factory('endpoints', EndpointService)
    .factory('pathExtractor', PathExtractor)
    .factory('statusClassService', StatusClassService)
    .factory('featureSwitch', FeatuerSwitchService)
    .directive('drmPanelZippy', DrmPanelZippy)
    .directive('drmExpandHeight', DrmExpandHeightDirective)
    .directive('drmComment', CommentDirective)
    .filter('customDate', CustomDate);

