'use strict';

describe('PathExtractor service', function () {
    var pathExtractor;

    beforeEach( function () {
        module('drmDashboard.sharedComponents');

        inject(function (_pathExtractor_) {
            pathExtractor = _pathExtractor_;
        });
    });

    it('should return path from well formed URL', function () {
        /* GIVEN */

        var cases = [
            {
                source: '',
                expectedResult: ''
            },
            {
                source: '/foo/bar',
                expectedResult: '/foo/bar'
            },
            {
                source: 'http://localhost:1000/foo/bar',
                expectedResult: '/foo/bar'
            }
        ];

        cases.forEach(function (testCase) {
            /* WHEN */

            var path = pathExtractor.extract(testCase.source);

            /* THEN */

            expect(path).toBe(testCase.expectedResult);
        });
    });
});