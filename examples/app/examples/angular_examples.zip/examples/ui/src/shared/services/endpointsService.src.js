'use strict';

var EndPointService = function ($http, $q) {
    var links = {
        files: '/approvals/files',
        reporting: '/approvals/requests_summary',
        'reporting-csv': '/approvals/requests_summary/download.csv',
        session: '/session',
        tasks: '/approvals/tasks',
        users: '/users',
        classification: '/approvals/classification'
    };

    // this is called every time a route is resolved. it gets all
    // static links needed to drive the application.
    var getStaticLinks = function () {
        var defer = $q.defer();

        $http({
            method : 'GET',
            url :'/approvals',
            cache : true
        }).success(function (resp) {
            var staticLinks = {};

            resp.links.forEach(function(link) {
                var linkName = link.rel.replace('request/', '');

                if (linkName !== 'getStaticLinks') {
                    staticLinks[linkName] = link.url;
                }

                if (link.metadata) {
                    var metadataName = linkName + 'Metadata';
                    staticLinks[metadataName] = link.metadata.url;
                }
            });

            angular.extend(links, staticLinks);
            defer.resolve(links);
        });

        return defer.promise;
    };

    links.getStaticLinks = getStaticLinks;
    return links;
};

module.exports = ['$http', '$q', EndPointService];