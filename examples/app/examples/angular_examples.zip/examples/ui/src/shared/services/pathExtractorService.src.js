'use strict';

var PathExtractor = function () {
    return {
        extract: function (url) {
            var indexOfDoubleSlash = url.indexOf('//');
            var offset = 2;
            if(indexOfDoubleSlash<0) {
                offset = 0;
            }
            var indexOfFirstSlashAfterDoubleSlash = url.indexOf('/', indexOfDoubleSlash + offset);

            return url.slice(indexOfFirstSlashAfterDoubleSlash);
        }
    };
};

module.exports = PathExtractor;