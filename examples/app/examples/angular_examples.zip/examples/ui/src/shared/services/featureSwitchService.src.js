'use strict';

var FeatureSwitch = function ($location) {
/*
*    example:
*    {
*        'drm.swissbank.com': {
*            'DRM-7' : 'enabled'
*        },
*        'drmlocal': {
*            'DRM-7' : 'disabled'
*        }
*    }
**/

    var features = {
        'drm.swissbank.com' : {},
        's-drm.swissbank.com' : {},
        'q-drm.swissbank.com' : {},

        'd-drm.swissbank.com' : {},
        'drmlocal': {
            'DRM-196': 'enabled',
            'DRM-198': 'enabled'
        }
    };

    var hostsWithFeaturesEnabledByDefault = ['drmlocal', 'd-drm.swissbank.com'];

    var enabledByDefault = function (host) {
        return _.indexOf(hostsWithFeaturesEnabledByDefault, host) < 0 ? false : true;
    };

    var featureIsKnown = function (featureId, host) {
        return features[host][featureId] ? true : false;
    };

    var featureEnabled = function (featureId) {
        var host = $location.host();

        if(!featureIsKnown(featureId, host) && enabledByDefault(host)) {
            return true;
        } else if (!featureIsKnown(featureId, host)) {
            return false;
        }

        if(enabledByDefault(host)) {
            return features[host][featureId] === 'disabled' ? false : true;
        } else {
            return features[host][featureId] === 'enabled' ? true : false;
        }
    };

    var featureDisabled = function (featureId) {
        return !featureEnabled(featureId);
    };

    return {
        featureEnabled: featureEnabled,
        featureDisabled: featureDisabled,
        features: features
    };
};

module.exports  = ['$location', FeatureSwitch];