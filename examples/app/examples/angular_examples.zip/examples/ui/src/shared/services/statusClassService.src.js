'use strict';

var StatusClassService = function () {
    var getApprovalIconClass = function (approval, requester) {
        var className = '';

        switch(true) {
            case (approval.status === 'Approved'):
                className = 'glyphicon-ok';
                break;
            case (approval.status === 'Rejected' && approval.assignee === requester):
                className = 'glyphicon-remove';
                break;
            case (approval.status === 'Rejected' && approval.assignee !== requester):
            case (approval.status === 'Awaiting Approval'):
                className = 'glyphicon-time';
                break;
            case (approval.status === 'Reviewed - Not Required'):
                className = 'glyphicon-ok';
                break;
        }

        return className;
    };

    var getApprovalColorClass = function (status) {
        if (status === 'Approved') {
            return 'approved';
        } else if (status === 'Rejected') {
            return 'rejected';
        } else if (status === 'Reviewed - Not Required') {
            return 'not-required';
        }
        return '';
    };

    return {
        getApprovalIconClass: getApprovalIconClass,

        getApprovalColorClass: getApprovalColorClass,

        getIconAndColorClasses: function (approval, requester) {
            var statusClass = this.getApprovalColorClass(approval.status);
            statusClass += ' ';
            statusClass  += this.getApprovalIconClass(approval, requester);

            return statusClass.trim();
        }
    };
};

module.exports = StatusClassService;