'use strict';

describe('StatusClassService', function () {
    var $httpBackend;
    var endpointsService;
    var fixtures;

    beforeEach( function () {
        module('drmDashboard.fixtures');
        module('drmDashboard.sharedComponents');

        inject(function (_$httpBackend_, _endpoints_, _endpointsFixtures_) {
            $httpBackend = _$httpBackend_;
            fixtures = _endpointsFixtures_;
            endpointsService = _endpoints_;
        });
    });

    describe('getStaticLinks() method', function () {
        it('should get a list of static links from api and convert then to object literal for injecting as service', function () {
            var promise = endpointsService.getStaticLinks();
            $httpBackend.expect('GET', '/approvals').respond(200, fixtures.getStaticLinks);

            promise.then(function (links) {
                expect(links['testsection1']).toEqual('/someurl/1');
                expect(links['testsection2']).toEqual('/someurl/2');
                // the injected service will also be updated as it's a service which means it shared object
                expect(endpointsService['testsection1']).toEqual('/someurl/1');
                expect(endpointsService['testsection2']).toEqual('/someurl/2');
                expect(endpointsService['create']).toEqual('/approvals/requests/create');
                expect(endpointsService['createMetadata']).toEqual('/approvals/requests/metadata');
            });

            $httpBackend.flush();
        });

        it('should not overwrite the getStaticLinks() method name if the link info from api contains "getStaticLinks" ', function () {
            var promise = endpointsService.getStaticLinks();
            $httpBackend.expect('GET', '/approvals').respond(200, fixtures.getStaticLinks);

            promise.then(function (links) {
                expect(typeof links['getStaticLinks']).toEqual('function');
            });

            $httpBackend.flush();
        });
    });
});