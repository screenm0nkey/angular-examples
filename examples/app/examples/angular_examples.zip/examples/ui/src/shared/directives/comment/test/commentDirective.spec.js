/*global waitsFor:true, runs:true*/
'use strict';

describe('Comments Directive', function () {
    var $directiveEl;
    var $scope;
    var $rootScope;
    var $httpBackend;
    var $compile;
    var fixtures;
    var inputSelector;
    var endpoints;

    beforeEach(module('drmDashboard.sharedComponents'));
    beforeEach(module('drmDashboard.user'));
    beforeEach(module('drmDashboard.fixtures'));
    beforeEach(module('/templates/shared/directives/comment/comment.html'));

    beforeEach(inject(function (_$rootScope_, _$compile_, _$httpBackend_, _userFixtures_, _endpoints_) {
        $httpBackend = _$httpBackend_;
        $rootScope = _$rootScope_;
        $compile = _$compile_;
        fixtures = _userFixtures_;
        endpoints = _endpoints_;
        $scope = $rootScope;
        $scope.form = {};
        inputSelector = 'input[type="text"][placeholder="Add your comment here..."][ng-model="comment"][ng-keyup="startSearch($event)"][ng-click="startSearch($event)"]';
    }));

    var renderDirective = function () {
        $directiveEl = $(angular.element('<div drm-comment/>'));
        $compile($directiveEl)($scope);
        // The comment directive has a dependency on the User Service which calls the user endpoint.
        $httpBackend.when('GET', endpoints.users).respond(fixtures.query);
        $httpBackend.flush();
        $scope.$digest();
        return $directiveEl;
    };

    it('should populate the directive with required dom elmenents with proper classes', function () {
        renderDirective();
        expect($directiveEl.find(inputSelector).length).toBeGreaterThan(0);
    });

    it('should bind the outside form to inner scope', function () {
        $scope.comment = 'hello';
        renderDirective();
        expect($directiveEl.find('input[type="text"]').val()).toBe('hello');
    });

    it('should display one list item', function () {
        renderDirective();
        $('body').append($directiveEl);
        expect($directiveEl.find('ul').is(':visible')).toBe(false);
        expect($directiveEl.find('li').length).toBe(1);
        $directiveEl.remove();
    });

    describe('', function () {
        var $directiveEl;
        var $input;
        var positionCaret;
        var simulateTyping;
        var simulateKeyPress;
        var ESCKEY = 27;
        var ARROWKEYDOWN = 40;
        var ARROWKEYUP = 38;
        var ENTERKEY = 13;

        positionCaret = simulateTyping = function(str, caretPos){
            $input.val(str);
            angular.element($input[0]).controller('ngModel').$setViewValue(str);

            if (caretPos) {
                $input.focus();
                $input[0].setSelectionRange(caretPos, caretPos);
            }

            $input.click();
        };

        simulateKeyPress = function (el, keyCode) {
            var evt = $.Event('keydown', { keyCode: keyCode });
            $(el).trigger(evt);
            evt = $.Event('keyup', { keyCode: keyCode });
            $(el).trigger(evt);
        };


        beforeEach(function () {
            $directiveEl = renderDirective();
            $('body').append($directiveEl);
            $input = $directiveEl.find(inputSelector);
        });

        afterEach(function () {
            $directiveEl.remove();
        });

        describe('displaying context menu', function () {
            it('should NOT bring up context menu if there is no matching value', function () {
                $input.val('text');
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
                $input.click();
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should bring up context menu if there an @ symbol followed by a character', function () {
                $input.val('@notexistinguser');
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
                $input.click();
                expect($directiveEl.find('ul').is(':visible')).toBe(true);

                //If the search does not return any match, it should should just show whatever user has written
                expect($directiveEl.find('li').length).toBe(1);
                expect($directiveEl.find('li').text()).toBe('notexistinguser');
            });

            it('should bring up context menu if there an @ symbol followed by a character', function () {
                $input.val('@b');
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
                $input.click();
                expect($directiveEl.find('ul').is(':visible')).toBe(true);
                expect($directiveEl.find('li').length).toBe(1);
            });

            it('should bring up the context menu if you click after the @ but not show them if you click before @', function () {
                simulateTyping('some @a');
                positionCaret('some @a', 5);
                expect($input.hasClass('ng-invalid')).toBe(true);
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should bring up context menu if you click at the end of a search string ', function () {
                simulateTyping('some @a text');
                positionCaret('some @a text', 7);
                expect($input.hasClass('ng-invalid')).toBe(true);
                expect($directiveEl.find('ul').is(':visible')).toBe(true);
            });

            it('should display one list item if a user exists and his name is preceded by @', function () {
                simulateTyping('@wayne');
                expect($directiveEl.find('li').length).toBe(2);
            });

            it('should display one list item if a user exists and his name is preceded by @ and a carot position is in the middle of the name', function () {
                positionCaret('some text @wayne some other text @nick', 11);
                expect($directiveEl.find('li').length).toBe(2);
                expect($directiveEl.find('li a').text()).toBe('Wayne Quinlivan');
            });

            it('should display one list item if a user exists and his name is preceded by @ and the name is at the end of the input', function () {
                simulateTyping('some text @wayne some other text @nick');
                expect($directiveEl.find('li').length).toBe(2);
                expect($directiveEl.find('li a').text()).toBe('Nick Lowman');
            });

            it('should display one list items if search string matches more users', function () {
                simulateTyping('some text @wayne some other text @w');
                expect($directiveEl.find('li').length).toBe(4);
            });

            it('should display one list item if a user exists and his name is preceded by @ and a carot position is in the middle of the name', function () {
                positionCaret('some text @wayne some other text @nick', 19);
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                simulateTyping('some other text @wayne');
                expect($directiveEl.find('li').length).toBe(2);
                expect($directiveEl.find('li a').text()).toBe('Wayne Quinlivan');
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                simulateTyping('some other text @wayne1.quinlivan');
                expect($directiveEl.find('li').length).toBe(2);
                expect($directiveEl.find('li a').text()).toBe('Wayne Quinlivan');
                expect($directiveEl.find('li').eq(1).text()).toBe('wayne1.quinlivan');
            });

            it('should hide display list once a user accepts an input or moves on with typing', function () {
                positionCaret('text @wayne some', 8);
                positionCaret('text @wayne some', 14);
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                simulateTyping('some other text @');
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });
        });


        describe('hiding context menu', function () {
            it('should hide the context menu when the esc key is pressed with focus on input', function () {
                simulateTyping('@wayn');
                expect($directiveEl.find('ul').is(':visible')).toBe(true);
                simulateKeyPress($input, ESCKEY);
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should hide the context menu when the esc key is pressed while menu has the focus', function () {
                simulateTyping('@wayn');
                expect($directiveEl.find('ul').is(':visible')).toBe(true);
                var firstLink = $directiveEl.find('ul li:first a');
                firstLink.focus();
                simulateKeyPress(firstLink, ESCKEY);
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });

            it('should hide the context when click occurs outside of directive', function () {
                simulateTyping('@wayn');
                expect($directiveEl.find('ul').is(':visible')).toBe(true);
                $('body').click();
                expect($directiveEl.find('ul').is(':visible')).toBe(false);
            });
        });


        describe('completion of name on menu item selection', function () {

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                simulateTyping('some other text @wayne');
                var $firstLi = $directiveEl.find('li:first a');
                $firstLi.click();
                expect($firstLi.text()).toBe('Wayne Quinlivan');
                expect($input.val()).toBe('some other text @wayne1.quinlivan ');

                expect($input[0] === document.activeElement).toBe(true);

                expect($directiveEl.find('ul').is(':visible')).toBe(false);
                expect($directiveEl.find('.alert-warning').is(':visible')).toBe(false);
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                positionCaret('@wayne text @wayne1.quinlivan', 3);
                var $firstLi = $directiveEl.find('li:first a');
                $firstLi.click();
                expect($input.val()).toBe('@wayne1.quinlivan text @wayne1.quinlivan');
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                simulateTyping('some @wayne1.quinlivan text @wayne');
                var $firstLi = $directiveEl.find('li:first a');
                $firstLi.click();
                expect($input.val()).toBe('some @wayne1.quinlivan text @wayne1.quinlivan ');
            });

            it('should display one list item if a user exists and his name is preceded by some text then space and @', function () {
                positionCaret('some @wayne1.quinlivan text @wayne text', 31);
                var $firstLi = $directiveEl.find('li:eq(0) a');
                $firstLi.click();
                expect($input.val()).toBe('some @wayne1.quinlivan text @wayne1.quinlivan text');
            });

            it('should on arrow down focus next li a if it exists in the list', function () {
                simulateTyping('@wayn');
                var $li = $directiveEl.find('li:eq(0) a');
                $li.focus();
                simulateKeyPress($li, ARROWKEYDOWN);
                expect($directiveEl.find('li:eq(1) a')[0] === document.activeElement).toBe(true);
            });

            it('should on arrow down focus first li a in the list if next one does not exist', function () {
                simulateTyping('@wayn');
                var $li = $directiveEl.find('li:eq(1) a');
                $li.focus();
                simulateKeyPress($li, ARROWKEYDOWN);
                expect($directiveEl.find('li:eq(0) a')[0] === document.activeElement).toBe(true);
            });

            it('should on arrow up focus previous li a in the list if one exists', function () {
                simulateTyping('@wayn');
                var $li = $directiveEl.find('li:eq(1) a');
                $li.focus();
                simulateKeyPress($li, ARROWKEYUP);
                expect($directiveEl.find('li:eq(0) a')[0] === document.activeElement).toBe(true);
            });

            it('should on arrow up focus on last li a in the list if one does not exists', function () {
                simulateTyping('@wayn');
                var $li = $directiveEl.find('li:eq(0) a');
                $li.focus();
                simulateKeyPress($li, ARROWKEYUP);
                expect($directiveEl.find('li:eq(1) a')[0] === document.activeElement).toBe(true);
            });

            it('should on arrow up focus on itself if it is the only li a in the list', function () {
                simulateTyping('@wayne');
                var $li = $directiveEl.find('li:eq(0) a');
                $li.focus();
                simulateKeyPress($li, ARROWKEYUP);
                expect($directiveEl.find('li:eq(0) a')[0] === document.activeElement).toBe(true);
            });

            it('should ', function () {
                simulateTyping('@wayne');
                var $li = $directiveEl.find('li:eq(0) a');
                $li.focus();
                simulateKeyPress($li, ENTERKEY);

                waitsFor(function () {
                    return $directiveEl.find('ul').is(':hidden');
                }, 'Menu did not hide', 500);

                runs(function () {
                    expect($input.val()).toBe('@wayne1.quinlivan ');
                });
            });

            it('should move the focus to selection menu once a user hits arrow down on input box', function () {
                $input.focus();
                simulateTyping('@way');
                simulateKeyPress($input, ARROWKEYDOWN);

                waitsFor(function () {
                    return $directiveEl.find('li:eq(0) a')[0] === document.activeElement;
                }, 'Failed to set active element', 500);

                runs(function () {
                    $input.blur();
                    expect($directiveEl.find('ul').is(':visible')).toBe(true);
                    expect($directiveEl.find('li:eq(0) a')[0] === document.activeElement).toBe(true);
                });

                var flag = false;

                waitsFor(function () {
                    setTimeout(function () {
                        flag = true;
                    }, 20);

                   return flag;
                });

                runs(function () {
                    expect($directiveEl.find('ul').is(':visible')).toBe(true);
                    expect($directiveEl.find('li:eq(0) a')[0] === document.activeElement).toBe(true);
                });

            });
        });


        describe('validation', function () {
            it('should check if input field is pristine', function () {
                expect($input.hasClass('ng-pristine')).toBe(true);
            });

            it('should make input field dirty once we start typing', function () {
                simulateTyping('some other text');
                expect($input.hasClass('ng-dirty')).toBe(true);
                expect($input.hasClass('ng-invalid')).toBe(false);
            });

            it('should make input field invalid if input field value contains a string preceded by @ which is not present within user emails', function () {
                simulateTyping('some other @nico');
                expect($input.hasClass('ng-invalid')).toBe(true);

                simulateTyping('some other @n');
                expect($input.hasClass('ng-invalid')).toBe(true);

                simulateTyping('some other @nico ');
                expect($input.hasClass('ng-invalid')).toBe(true);

                positionCaret('some other @nico oiup @wayne1.quinlivan', 14);
                expect($input.hasClass('ng-invalid')).toBe(true);
            });

            it('should make input field valid if the @ symbol is followed by space', function () {
                simulateTyping('some other @ text');
                expect($input.hasClass('ng-valid')).toBe(true);
                expect($directiveEl.find('.alert-warning').is(':hidden')).toBe(true);
            });

            it('should make input field valid if all strings preceded by @ are in the emails', function () {
                positionCaret('some other @nick.lowman oiup @wayne1.quinlivan', 14);
                expect($input.hasClass('ng-valid')).toBe(true);
            });

            it('should show a warning if a email can not be found', function () {
                var warning = $directiveEl.find('.alert-warning');

                simulateTyping('some other @nico');
                expect(warning.is(':visible')).toBe(false);

                simulateTyping('some other @nico ');

                waitsFor(function () {
                    return warning.is(':visible');
                }, 1000, 'Failed on warning not being visible');

                runs(function () {
                    expect(warning.text()).toBe('nico is not a valid user');
                });
            });

            it('should show a warning if a email can not be found', function () {
                var warning = $directiveEl.find('.alert-warning');

                simulateTyping('some other @nico ');

                waitsFor(function () {
                    return warning.is(':visible');
                }, 1000, 'Failed on warning not being visible');

                runs(function () {
                    simulateTyping('some other @nick.lowman');
                    expect(warning.is(':visible')).toBe(false);

                    expect(warning.text()).toBe(' is not a valid user');
                });
            });

            it('should display search results as items in context menu', function () {
                simulateTyping('some other @wayne1.quinlivan text @user');
                positionCaret('some other @wayne1.quinlivan text @user', 27);
                expect($input.hasClass('ng-invalid')).toBe(true);
                var $lis = $directiveEl.find('li');
                expect($lis.length).toBe(2);
                expect($($lis.get(0)).text().trim()).toBe('Wayne Quinlivan');
                expect($($lis.get(1)).text()).toBe('wayne1.quinlivan');
            });

            it('should display no error message if input field is focused and empty', function () {
                simulateTyping('some other @wayne1.quinlivan text @user');
                simulateTyping('');
                expect($input.hasClass('ng-invalid')).toBe(false);
                expect($directiveEl.find('.alert-warning').is(':visible')).toBe(false);
            });
        });
    });
});