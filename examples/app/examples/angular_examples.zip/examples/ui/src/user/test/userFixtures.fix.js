angular.module('drmDashboard.fixtures').value('userFixtures', {
    query : [
        {email:'nick.lowman@ubs.com', guid:'1', name: 'Nick Lowman'},
        {email:'paul.gustafik@ubs.com', guid:'2', name: 'Paul Gustafik'},
        {email:'wayne1.quinlivan@ubs.com', guid:'3', name: 'Wayne Quinlivan'},
        {email:'wayn.quinlivan@ubs.com', guid:'4', name: 'Wayn Quinlivan'}
    ], expectedUsers: [
        {email:'requestor@ubs.com', guid:'requestor', name:'Requestor'},
        {email:'nick.lowman@ubs.com', guid:'1', name: 'Nick Lowman'},
        {email:'paul.gustafik@ubs.com', guid:'2', name: 'Paul Gustafik'},
        {email:'wayne1.quinlivan@ubs.com', guid:'3', name: 'Wayne Quinlivan'},
        {email:'wayn.quinlivan@ubs.com', guid:'4', name: 'Wayn Quinlivan'}
    ]
});
