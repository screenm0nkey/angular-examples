'use strict';

describe('userParserService', function () {
    var $httpBackend;
    var service;
    var fixtures;
    var endpoints;

    beforeEach(function () {
        module('drmDashboard.fixtures');
        module('drmDashboard.user');
        module('drmDashboard.sharedComponents');

        inject(function (_$httpBackend_, _UserParserService_, _userFixtures_, _endpoints_) {
            service = _UserParserService_;
            $httpBackend = _$httpBackend_;
            fixtures = _userFixtures_;
            endpoints = _endpoints_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });


    describe('extractGuids method', function () {
        it('should extract GUIDS from comment and return object containing original comment and guid list', function () {
            var comment = '@nick.lowman commentText @wayne1.quinlivan and @paul.gustafik @requestor @requestor';
            var expectedResponseData = {
                comment : comment,
                user_ids : ['1','3', '2', 'requestor']
            };

            $httpBackend.expect('GET', endpoints.users).respond(fixtures.query);
            var extractedGuids = service.extractGuids(comment);
            $httpBackend.flush();

            extractedGuids.then(function (guids) {
                expect(guids).toEqual(expectedResponseData);

            });
        });
    });

    describe('wrapUserHTML method', function () {
        it('should wrap a user by tags with proper class', function () {
            var comment = '@nick.lowman commentText @requestor';
            var expectedHTML = '<span>@nick.lowman</span> commentText <span>@requestor</span>';

            expect(service.wrapUserHTML(comment, 'span')).toBe(expectedHTML);
        });

        it('should wrap a user by tags with proper class', function () {
            var comment = '@nick.lowman commentText @requestor';
            var expectedHTML = '<span class="userClass">@nick.lowman</span> commentText <span class="userClass">@requestor</span>';

            expect(service.wrapUserHTML(comment, 'span', 'userClass')).toBe(expectedHTML);
        });
    });

});