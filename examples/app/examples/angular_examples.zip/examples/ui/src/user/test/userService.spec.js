'use strict';

describe('UserService', function () {
    var $httpBackend;
    var service;
    var fixtures;
    var endpoints;

    beforeEach(function () {
        module('drmDashboard.fixtures');
        module('drmDashboard.user');
        module('drmDashboard.sharedComponents');

        inject(function (_$httpBackend_, _UserService_, _userFixtures_, _endpoints_) {
            service = _UserService_;
            $httpBackend = _$httpBackend_;
            fixtures = _userFixtures_;
            endpoints = _endpoints_;
        });
    });

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('query() method', function () {
        it('should call correct api endpoint', function () {
            var promise = service.query();
            var data;

            $httpBackend.expect('GET', endpoints.users).respond(200, fixtures.query);
            promise.then(function (resp) {
                data = resp;
            });

            $httpBackend.flush();
            expect(data).toEqual(fixtures.expectedUsers);
        });
    });
});