'use strict';

var UserService = function ($http, $q, endpoints) {
    var query = function () {
        var deferred = $q.defer();

        $http({
            method: 'GET',
            url: endpoints.users,
            cache : true
        }).success(function (users) {
            // add a requester user to the start of the array. it's used in the comment directive
            users.unshift({email:'requestor@ubs.com', guid:'requestor', name:'Requestor'});
            deferred.resolve(users);
        }).error(function(resp){
            deferred.reject(resp);
        });

        return deferred.promise;
    };

    return {
        query : query
    };
};

module.exports = ['$http', '$q', 'endpoints',  UserService];
