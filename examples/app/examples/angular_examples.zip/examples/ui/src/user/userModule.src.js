var UserService = require('./userService.src.js');
var UserParserService = require('./userParserService.src.js');

angular.module('drmDashboard.user', [])
    .factory('UserParserService', UserParserService)
    .factory('UserService', UserService);