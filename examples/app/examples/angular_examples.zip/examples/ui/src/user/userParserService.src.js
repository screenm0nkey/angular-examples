'use strict';

var UserParserService = function (UserService, $q) {

    var extractGuids = function (str) {
        var userList = UserService.query();
        var guidArray = [];
        var deferred = $q.defer();

        userList.then(function (users) {
            var regex = /@([^\s][^\s]*)(\s|$)/g;
            var match = regex.exec(str);

            while (match) {
                var matchingUsers = _.where(users, {email: match[1] + '@ubs.com'});
                if (matchingUsers.length) {
                    guidArray.push(matchingUsers[0].guid);
                }
                match = regex.exec(str);
            }

            deferred.resolve({
                comment : str,
                user_ids : _.unique(guidArray)
            });
        });

        return deferred.promise;
    };

    var wrapUserHTML = function (str, tag, className) {
        var htmlClass ='';

        if(className) {
            htmlClass = ' class="' + className + '"';
        }

        str = str.replace(/@([^\s][^\s]*)/g, function (user) {
            return '<' + tag + htmlClass + '>' + user + '</' + tag + '>';
        });

        return str;
    };

    return {
        extractGuids : extractGuids,
        wrapUserHTML : wrapUserHTML
    };
};

module.exports = ['UserService', '$q', UserParserService];