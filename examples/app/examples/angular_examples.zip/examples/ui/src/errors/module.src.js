var ErrorController = require('./controller.src.js');
var InterceptorService = require('./interceptorService.src.js');

angular.module('drmDashboard.errors', [])
    .controller('ErrorController', ErrorController)
    .factory('ErrorInterceptorService', InterceptorService);