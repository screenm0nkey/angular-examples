'use strict';

var InterceptorService = function ($location, $q) {
    return {
        responseError: function (rejection) {
            if (rejection.status !== 404) {
                $location.path('/error/'+ rejection.status);
            }
            return $q.reject(rejection);
        }
    };
};

module.exports = ['$location', '$q', InterceptorService];
