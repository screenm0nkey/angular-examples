'use strict';

describe('reportingService', function () {
    var $httpBackend;
    var service;
    var pathSpy = sinon.spy();

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('$location', {
                path : pathSpy
            });
        });
    });

    beforeEach(function () {
        module('drmDashboard.errors');
        pathSpy.reset();

        inject(function (_$httpBackend_, _ErrorInterceptorService_) {
            service = _ErrorInterceptorService_;
            $httpBackend = _$httpBackend_;
        });
    });


    describe('HTTP Error Interceptor', function () {
        it('should redirect on a 401 to the correct error page', function () {
            service.responseError({status:401});
            expect(pathSpy.called).toBeTruthy();
            expect(pathSpy.getCall(0).args[0]).toEqual('/error/401');
        });

        it('should NOT redirect on a 404 error', function () {
            service.responseError({status:404});
            expect(pathSpy.called).toBeFalsy();
//            expect(pathSpy.getCall(0).args[0]).toEqual('/error/404');
        });
    });

});