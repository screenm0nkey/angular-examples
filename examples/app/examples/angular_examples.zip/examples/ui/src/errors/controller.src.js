'use strict';

var ErrorController = function ($scope, $routeParams) {
    $scope.errorCode = $routeParams.id;
};

module.exports = ['$scope','$routeParams', ErrorController];