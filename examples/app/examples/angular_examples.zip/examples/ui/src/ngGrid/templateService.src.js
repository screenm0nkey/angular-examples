'use strict';

var NgGridTemplateService = function(){
    return {
        groupStatusCell:  function (i) {
            var cellTemplate = '<div class="grid--approval ngCellText" ng-class="col.colIndex()">';
            cellTemplate += '<span class="glyphicon"';
            cellTemplate += ' ng-class=' + 'row.getProperty("approvals_summary[' + i + '].approvalClass")/>';
            cellTemplate += '</div>';
            return cellTemplate;
        }
    };
};

module.exports = NgGridTemplateService;