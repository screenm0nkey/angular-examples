'use strict';
// this ngGrid module serves to combine shared app logic when implementing the ngGrid directive.
// It's NOT the ngGrid library
var TemplateService = require('./templateService.src.js');

var DrmGridResizeDirective = require('./drmGridResizeDirective.src.js');


angular.module('drmDashboard.ngGrid', [])
    .factory('ngGridTemplateService', TemplateService)
    .directive('drmGridResize', DrmGridResizeDirective)
    .factory('ngGridDefaults', function() {
        return function(options) {
            return  angular.extend({
                // TODO : move tasks out of this definition as it's not a generic default
                data: 'tasks',
                columnDefs: 'columnDefs',
                height:'auto',
                headerRowHeight: 50,
                enableColumnResize : true,
                rowHeight: 24,
                showColumnMenu: true,
                showFilter: true,
                pagingOptions: {
                    pageSizes: [2, 500, 1000],
                    pageSize: 2,
                    totalServerItems: 0,
                    currentPage: 1
                }
            }, options || {});
        };
    });











