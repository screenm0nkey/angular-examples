'use strict';

var DrmGridResizeDirective = function () {
    var defaults = {
        viewport : '.ngViewport',
        canvas : '.ngCanvas'
    };

    return {
        restrict: 'A',
        priority : -1,
        scope : true,
        link: function(scope, element) {
            var $viewport = element.find(defaults.viewport);
            var $canvas = element.find(defaults.canvas);
            var origViewportStyleFunc;
            // stops grid defaulting to min height
            element.addClass('no-min');

            scope.$watchCollection('renderedRows', function (rowData) {
                if (!$viewport[0] || !$canvas[0]) {
                    $viewport = element.find(defaults.viewport);
                    $canvas = element.find(defaults.canvas);
                }
                // ng-grid adds the viewportStyle() method after initialisation so we have to wait for it to be available
                // before we override it. We check to make sure we haven't already overridden it.
                if (_.isFunction(scope.viewportStyle) && !origViewportStyleFunc) {
                    origViewportStyleFunc = scope.viewportStyle;

                    scope.viewportStyle = function () {
                        var scrollBarHeight  = $canvas.width() > $viewport.width() ? 18 :0;
                        var style = origViewportStyleFunc();
                        style.height = (rowData.length * scope.rowHeight) + scrollBarHeight + 'px';
                        return style;
                    };
                }
            });
        }
    };
};

module.exports = ['$window', DrmGridResizeDirective];