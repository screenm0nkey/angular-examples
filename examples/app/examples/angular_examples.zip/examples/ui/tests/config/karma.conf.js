'use strict';
/*
 NOTE:
 You need to set the "usePolling : true" property to make karma run properly on Ubuntu.
 Also, if you are using sublime to edit your files then you have to set ""atomic_save": false"
 unless Karma will not update properly.s
 */

module.exports = function(config) {
    config.set({
        basePath:'../',

        frameworks: ['jasmine'],

        files: [
            '../../public/js/lib/jquery/jquery-2.0.3.min.js',
            '../../public/js/lib/lo-dash.min.js',
            '../../public/js/lib/angular/angular.js',
            '../../public/js/lib/angular/angular-mocks.js',
            '../../public/js/lib/angular/angular-route.js',
            '../../public/js/lib/angular/angular-sanitize.js',
            '../../public/js/lib/angularFileUpload/angular-file-upload.js',
            '../../public/js/lib/angularFileUpload/angular-file-upload-shim.js',
            '../../public/templates/**/*.html',
            '../../public/js/app.js',
            'lib/*.js',
            '../src/*.fix.js',
            '../src/**/*.fix.js',
            '../src/**/*.spec.js'
        ],
        exclude: [],

        reporters: ['progress'],

        port: 9876,

        runnerPort: 9100,

        colors: true,

        logLevel: config.LOG_ERROR,

        autoWatch: true,

        usePolling : true,

        browsers: ['Chrome'],

        captureTimeout: 60000,

        singleRun: false,

        plugins: [
            'karma-chrome-launcher',
            'karma-jasmine',
            'karma-phantomjs-launcher',
            'karma-ng-html2js-preprocessor'
        ],

        // the html templates are converted to JS files and stored in the angular template cache. the path of the
        // template is used as the key and the template is the value. the key value has to
        // match the template paths used in the app. so we convert it here to match the app templates.
        ngHtml2JsPreprocessor: {
            cacheIdFromPath: function(filepath) {
                var replaceString =  __dirname.toString().replace('/ui/tests/config', '') + '/public';
                var newPath =  filepath.replace(replaceString, '');
                console.log('ng-html2js:converted template', newPath);
                return newPath;
            }
        },

        preprocessors: {
            '../../public/templates/**/*.html': 'ng-html2js'
        }
    });
};